package com.hvisions.eam.consts;

/**
 * <p>Title: MaintainConsts</p>
 * <p>Description: 常量池</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/12/7</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
public interface MaintainConsts {
    String NA = "N/A";
}

    
    
    
    