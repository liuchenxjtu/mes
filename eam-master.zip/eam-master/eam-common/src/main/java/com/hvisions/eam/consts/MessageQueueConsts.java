package com.hvisions.eam.consts;

/**
 * <p>Title: MessageQueueConsts</p>
 * <p>Description: 消息队列相关对象</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/9/28</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
public interface MessageQueueConsts {
    String PROCESS_INSTANCE_COMPLETE_EXCHANGE = "h-visions.process.instance.finish.exchange";
}









