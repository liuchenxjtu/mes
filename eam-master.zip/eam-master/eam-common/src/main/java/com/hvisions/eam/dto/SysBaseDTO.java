package com.hvisions.eam.dto;

import com.hvisions.common.annotation.ExcelAnnotation;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: SysBaseDTO</p>
 * <p>Description: Dto尽量继承，可以做出自己的更改</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2018/11/09</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Data
public class SysBaseDTO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    @ExcelAnnotation(ignore = true)
    protected Integer id;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间", readOnly = true)
    @ExcelAnnotation(ignore = true)
    protected Date createTime;

    /**
     * 修改时间
     */
    @ApiModelProperty(value = "更新时间", readOnly = true)
    @ExcelAnnotation(ignore = true)
    protected Date updateTime;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建用户Id", readOnly = true)
    @ExcelAnnotation(ignore = true)
    protected Integer creatorId;

    /**
     * 修改人
     */
    @ApiModelProperty(value = "更新用户Id", readOnly = true)
    @ExcelAnnotation(ignore = true)
    protected Integer updaterId;

    @ExcelAnnotation(ignore = true)
    protected String siteNum;


}
