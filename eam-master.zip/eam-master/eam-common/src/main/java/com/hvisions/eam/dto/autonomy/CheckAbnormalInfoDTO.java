package com.hvisions.eam.dto.autonomy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**

 * @author: xiehao
2021/6/28
 * @version: 1.0
 */
@Data
public class CheckAbnormalInfoDTO {

    @ApiModelProperty(value = "检查计划名称")
    private String taskName;//检查计划名称

    @ApiModelProperty(value = "开始时间")
    private String startTime;

    @ApiModelProperty(value = "结束时间")
    private String endTime;

    @ApiModelProperty(value = "责任人")
    private String personLiable;//责任人

    @ApiModelProperty(value = "责任组")
    private String responsibilityGroup;//责任组

}
