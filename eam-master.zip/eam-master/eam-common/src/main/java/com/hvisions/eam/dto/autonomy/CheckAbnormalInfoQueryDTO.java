package com.hvisions.eam.dto.autonomy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author: xiehao
 * @version: 1.0
 */
@Data
public class CheckAbnormalInfoQueryDTO {

    @ApiModelProperty(value = "主表关联IDList")
    private List<Integer> idList;
}
