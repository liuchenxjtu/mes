package com.hvisions.eam.dto.autonomy;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author: xiehao
 * @version: 1.0
 */
@Getter
@Setter
@ToString
public class Data {

    private int id;

    private String userName;
}
