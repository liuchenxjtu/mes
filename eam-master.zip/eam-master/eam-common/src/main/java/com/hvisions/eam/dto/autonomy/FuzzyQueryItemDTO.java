package com.hvisions.eam.dto.autonomy;

import lombok.Data;

/**
 * @author: xiehao
 * @version: 1.0
 */
@Data
public class FuzzyQueryItemDTO {

    private String keyword;
}
