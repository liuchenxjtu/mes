package com.hvisions.eam.dto.autonomy;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author: xiehao
 * @version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "检查计划DTO")
public class InspectionPlanDTO extends SysBaseDTO {

    /**
     * 检查计划编码
     */
    @ApiModelProperty(value = "检查计划编码")
    private String number;

    /**
     * 检查计划名称
     */
    @ApiModelProperty(value = "检查计划名称")
    private String name;

    /**
     * 责任类型;0-责任人,1-责任组
     */
    @ApiModelProperty(value = "责任类型;0-责任人,1-责任组")
    private String typesOfLiability;

    /**
     * 责任人
     */
    @ApiModelProperty(value = "责任人",required = true)
    private String personLiable;

    /**
     * 责任组
     */
    @ApiModelProperty(value = "责任组",required = true)
    private String responsibilityGroup;

    /**
     * 验证人员
     */
    @ApiModelProperty(value = "验证人员")
    private String verifier;

    /**
     * 班组长
     */
    @ApiModelProperty(value = "班组长")
    private String foreman;

    /**
     * 主管领导
     */
    @ApiModelProperty(value = "主管领导")
    private String leader;

    /**
     * timerId
     */
    @ApiModelProperty(value = "timerId")
    private Integer timerId;

    /**
     * 检查项目ID_list
     */
    @ApiModelProperty(value = "projectIdList")
    List<InspectionProjectDTO> projectIdList;

}
