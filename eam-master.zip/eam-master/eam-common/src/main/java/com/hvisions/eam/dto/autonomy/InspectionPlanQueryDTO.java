package com.hvisions.eam.dto.autonomy;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author: xiehao
 * @version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "检查计划-分页查询")
public class InspectionPlanQueryDTO extends PageInfo {

    /**
     * 检查计划编码
     */
    @ApiModelProperty(value = "检查计划编码")
    private String number;

    /**
     * 检查计划名称
     */
    @ApiModelProperty(value = "检查计划名称")
    private String name;

}
