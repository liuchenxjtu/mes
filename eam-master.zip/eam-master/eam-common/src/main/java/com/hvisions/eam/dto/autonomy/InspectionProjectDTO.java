package com.hvisions.eam.dto.autonomy;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author: xiehao
 * @version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "检查项目DTO")
public class InspectionProjectDTO extends SysBaseDTO {

    /**
     * 检查项目编号
     */
    @ApiModelProperty(value = "检查项目编号")
    private String number;

    /**
     * 检查项目名称
     */
    @ApiModelProperty(value = "检查项目名称")
    private String name;

    /**
     * 检测内容
     */
    @ApiModelProperty(value = "检测内容")
    private String testContent;

    /**
     * 检测周期
     */
    @ApiModelProperty(value = "检测周期")
    private String testCycle;

    /**
     * 检测方法
     */
    @ApiModelProperty(value = "检测方法")
    private String testMethod;

    /**
     * 启用标志;0-启用,1-未启用
     */
    @ApiModelProperty(value = "启用标志;0-启用,1-未启用")
    private String enableFlag;

    /**
     * 连续异常次数
     */
    @ApiModelProperty(value = "连续异常次数")
    private Integer abnormalTimes;

    /**
     * 组ID
     */
    @ApiModelProperty(value = "组ID")
    private Integer groupId;

    /**
     * 组名称
     */
    @ApiModelProperty(value = "组名称")
    private String groupName;

}
