package com.hvisions.eam.dto.autonomy;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author: xiehao
 * @version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "检查项目-分页查询")
public class InspectionProjectQueryDTO extends PageInfo {

    /**
     * 检查项目编号
     */
    @ApiModelProperty(value = "检查项目编号")
    private String number;

    /**
     * 检查项目名称
     */
    @ApiModelProperty(value = "检查项目名称")
    private String name;

    /**
     * 检测周期
     */
    @ApiModelProperty(value = "检测周期")
    private String testCycle;

    /**
     * 组ID
     */
    @ApiModelProperty(value = "组ID")
    private Integer groupId;

    /**
     * 组ID S
     */
    @ApiModelProperty(value = "组ID",hidden = true)
    private List<String> groupIds;

}
