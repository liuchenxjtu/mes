package com.hvisions.eam.dto.autonomy;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @author: xiehao
 * @version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "计划执行信息DTO")
public class MaintenanceProcessDataDTO extends SysBaseDTO {

    @ApiModelProperty(value = "检查计划编码")
    private String number;//检查计划编码

    @ApiModelProperty(value = "检查计划名称")
    private String taskName;//检查计划名称

    @ApiModelProperty(value = "timerId")
    private Integer timerId;//timerId

    @ApiModelProperty(value = "timerIdDes")
    private String timerIdDes;//timerIdDes

    @ApiModelProperty(value = "完成状态  0 - 未完成，1 - 完成")
    private String completionStatus;//完成状态  0 - 未完成，1 - 完成

    @ApiModelProperty(value = "开始时间")
    private Date startTime;

    @ApiModelProperty(value = "结束时间")
    private Date endTime;

    @ApiModelProperty(value = "确认状态   0 - 否，1 - 是")
    private String confirmStatus;//确认状态   0 - 否，1 - 是

    @ApiModelProperty(value = "是否存在问题    0 - 否，1 - 是")
    private String hasError;//是否存在问题    0 - 否，1 - 是

    @ApiModelProperty(value = "执行人")
    private String executor;//执行人

    @ApiModelProperty(value = "验证人")
    private String verifier;//验证人

    @ApiModelProperty(value = "开始人id", hidden = true)
    private String startUserId;

    @ApiModelProperty(value = "责任人", hidden = true)
    private String personLiable;

    /**
     * 检查项目itemList
     */
    @ApiModelProperty(value = "itemList")
    List<MaintenanceProcessItemDTO> itemList;
}
