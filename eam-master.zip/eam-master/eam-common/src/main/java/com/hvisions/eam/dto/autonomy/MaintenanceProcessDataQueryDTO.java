package com.hvisions.eam.dto.autonomy;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author: xiehao
 * @version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "计划执行信息-分页查询")
public class MaintenanceProcessDataQueryDTO extends PageInfo {

    @ApiModelProperty(value = "开始时间")
    private String startTime;

    @ApiModelProperty(value = "结束时间")
    private String endTime;

    @ApiModelProperty(value = "是否存在问题    0 - 否，1 - 是")
    private String hasError;//是否存在问题    0 - 否，1 - 是

}
