package com.hvisions.eam.dto.autonomy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**

 * @author: xiehao
2021/6/28
 * @version: 1.0
 */
@Data
public class MaintenanceProcessItemDTO {

    @ApiModelProperty(value = "项目编号")
    private String number;

    @ApiModelProperty(value = "项目名称")
    private String name;

    @ApiModelProperty(value = "项目分组ID")
    private Integer groupId;

    @ApiModelProperty(value = "项目分组名称")
    private String groupName;

    @ApiModelProperty(value = "检测内容")
    private String testContent;

    @ApiModelProperty(value = "检测周期")
    private String testCycle;

    @ApiModelProperty(value = "检测方法")
    private String testMethod;

    @ApiModelProperty(value = "总检测数")
    private Integer count;

    @ApiModelProperty(value = "异常-总检测数")
    private Integer errCount;

    @ApiModelProperty(value = "合格-总检测数")
    private Integer qualifiedCount;

    @ApiModelProperty(value = "最大连续异常")
    private Integer maxErr;

    @ApiModelProperty(value = "主表关联IDList")
    private List<Integer> idList;

}
