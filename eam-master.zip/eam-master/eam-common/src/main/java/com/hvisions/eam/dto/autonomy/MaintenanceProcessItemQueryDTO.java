package com.hvisions.eam.dto.autonomy;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author xiehao
 * @version 1.0
 */
@Data
@ApiModel(description = "检查项目统计-分页查询")
public class MaintenanceProcessItemQueryDTO extends PageInfo {

    @ApiModelProperty(value = "开始时间")
    private String startTime;

    @ApiModelProperty(value = "结束时间")
    private String endTime;

    @ApiModelProperty(value = "项目编号")
    private String number;

    @ApiModelProperty(value = "时间内的计划表id", hidden = true)
    private List<Integer> ids;

}
