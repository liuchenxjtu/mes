package com.hvisions.eam.dto.autonomy;

import lombok.Data;

import java.util.List;

/**

 * @author: xiehao
2021/6/24
 * @version: 1.0
 */
@Data
public class MessageCreateDTO {

    private Boolean allUser;
    private String content;
    private String createTime;
    private Integer creatorId;
    private String data;
    private List<Integer> departmentIds;
    private Boolean handled;
    private Integer id;
    private List<Integer> roleIds;
    private String siteNum;
    private String title;
    private String updateTime;
    private Integer updaterId;
    private String url;
    private List<Integer> userIds;

}
