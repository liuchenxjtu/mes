package com.hvisions.eam.dto.autonomy;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**

 * @author: xiehao
2021/6/17
 * @version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "项目组-新增或修改")
public class ProjectGroupCreateOrUpdateDTO extends SysBaseDTO {

    /**
     * 组名称
     */
    @ApiModelProperty(value = "组名称",required = true)
    private String name;

    /**
     * 父级ID
     */
    @ApiModelProperty(value = "父级ID,新增时：当为根节点时不用传；修改时：不用传")
    private Integer parentId;
}
