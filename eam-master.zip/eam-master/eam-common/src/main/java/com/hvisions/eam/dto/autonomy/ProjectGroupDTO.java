package com.hvisions.eam.dto.autonomy;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author: xiehao
 * @version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "项目组DTO")
public class ProjectGroupDTO extends SysBaseDTO {

    /**
     * 组名称
     */
    @ApiModelProperty(value = "组名称")
    private String name;

    /**
     * 父级ID
     */
    @ApiModelProperty(value = "父级ID")
    private Integer parentId;

    /**
     * 子节点数据
     */
    @ApiModelProperty(value = "子节点数据")
    private List<ProjectGroupDTO> childNode;
    
}
