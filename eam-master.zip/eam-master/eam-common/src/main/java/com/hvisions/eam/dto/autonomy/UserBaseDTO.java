package com.hvisions.eam.dto.autonomy;

import lombok.Data;

/**

 * @author: xiehao
2021/7/5
 * @version: 1.0
 */
@Data
public class UserBaseDTO {

    private Integer id;
    private String userName;
}
