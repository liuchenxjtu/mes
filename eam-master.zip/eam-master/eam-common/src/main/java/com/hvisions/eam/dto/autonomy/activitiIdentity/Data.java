package com.hvisions.eam.dto.autonomy.activitiIdentity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**

 * @author: xiehao
2021/7/6
 * @version: 1.0
 */
@Getter
@Setter
@ToString
public class Data {

    private List<Content> content;
}
