package com.hvisions.eam.dto.autonomy.activitiIdentity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**

 * @author: xiehao
2021/7/6
 * @version: 1.0
 */
@Getter
@Setter
@ToString
public class JsonGetGroup {

    private Data data;
    private int code;
    private String message;
}
