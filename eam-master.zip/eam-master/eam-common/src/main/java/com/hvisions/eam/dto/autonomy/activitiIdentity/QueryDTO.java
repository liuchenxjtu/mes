package com.hvisions.eam.dto.autonomy.activitiIdentity;

import com.hvisions.common.dto.PageInfo;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**

 * @author: xiehao
2021/7/6
 * @version: 1.0
 */
@Getter
@Setter
@ToString
public class QueryDTO extends PageInfo {

    private String id;
    private String name;
    private String type;
}
