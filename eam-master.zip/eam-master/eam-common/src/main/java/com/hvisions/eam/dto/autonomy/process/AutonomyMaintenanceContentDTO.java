package com.hvisions.eam.dto.autonomy.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author: xiehao
 * @version: 1.0
 */
@Getter
@Setter
@ToString
public class AutonomyMaintenanceContentDTO {

    private String number;
    private String name;
    private String testContent;
    private String testCycle;
    private String testMethod;
    private String enableFlag;
    private Integer abnormalTimes;
    private Integer groupId;
    private String groupName;
    private String hasError;// 0 - 否，1 - 是
    private String remark;

}