/**
  * Copyright 2020 bejson.com 
  */
package com.hvisions.eam.dto.autonomy.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Auto-generated: 2020-10-14 14:23:48
 *
 * @author leiming
 */
@Getter
@Setter
@ToString
public class JsonRootBean {

    private Data data;
    private int code;
    private String message;

}