/**
 * Copyright 2020 bejson.com
 */
package com.hvisions.eam.dto.autonomy.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Auto-generated: 2020-10-14 14:23:48
 *
 * @author leiming
 */
@Setter
@Getter
@ToString
public class ProcessInstanceVariables {

    private String number;//检查计划编码
    private String taskName;//检查计划名称
    private String typesOfLiability;//责任类型;0-责任人,1-责任组
    private String personLiable;//责任人
    private String responsibilityGroup;//责任组
    private String verifier;//验证人员
    private String foreman;//班组长
    private String leader;//主管领导
    private String descr;//描述
    private Integer timerId;//timerId

    private List<AutonomyMaintenanceContentDTO> projectDTOList;

}