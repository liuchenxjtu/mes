/**
  * Copyright 2020 json.cn 
  */
package com.hvisions.eam.dto.autonomy.repair.process;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * Auto-generated: 2020-11-06 8:51:23
 *
 * @author json.cn (i@json.cn)
 */
@Getter
@Setter
@ToString
public class Data {
    private String processInstanceId;
    private String processDefinitionId;
    private String processDefinitionName;
    private String processDefinitionKey;
    private Integer processDefinitionVersion;
    private String deploymentId;
    private String businessKey;
    private String tenantId;
    private String name;
    private String description;
    private String localizedName;
    private String localizedDescription;
    private Date startTime;
    private Date endTime;
    private String startUserId;
    private ProcessInstanceVariables processInstanceVariables;
}