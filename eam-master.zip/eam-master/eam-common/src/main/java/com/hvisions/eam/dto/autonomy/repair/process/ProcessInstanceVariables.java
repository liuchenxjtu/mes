/**
 * Copyright 2020 json.cn
 */
package com.hvisions.eam.dto.autonomy.repair.process;

import com.hvisions.eam.dto.autonomy.process.AutonomyMaintenanceContentDTO;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Auto-generated: 2020-11-06 8:51:23
 *
 * @author json.cn (i@json.cn)
 */
@Setter
@Getter
@ToString
public class ProcessInstanceVariables {

    private String number;//检查计划编码
    private String taskName;//检查计划名称
    private String personLiable;//责任人
    private String responsibilityGroup;//责任组
    private String verifier;//验证人员
    private String foreman;//班组长
    private String leader;//主管领导

    private List<AutonomyMaintenanceContentDTO> autonomyList;

}