package com.hvisions.eam.dto.fault;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.ObjectTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: FaultClassDTO</p >
 * <p>Description: 设备故障类DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/26</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@lombok.EqualsAndHashCode(callSuper = true)
@ApiModel(value = "设备故障类DTO")
@Data
public class FaultClassDTO extends SysBaseDTO implements IObjectType {

    public FaultClassDTO() {
        if (parentId == null) {
            parentId = 0;
        }
    }

    /**
     * 设备故障类别
     */
    @ApiModelProperty(value = "故障类别名称,非空", required = true)
    private String faultClassName;

    /**
     * 故障父类
     */
    @ApiModelProperty(value = "父类id" ,example = "0")
    private Integer parentId;

    /**
     * 设备类型id
     */
    @ApiModelProperty(value = "设备类型id")
    private Integer equipmentClassId;


    /**
     * 对象类型编码
     *
     * @return 对象类型编码
     */
    @Override
    public Integer getObjectType() {
        return ObjectTypeEnum.FAULT_Class_DTO.getCode();
    }
}