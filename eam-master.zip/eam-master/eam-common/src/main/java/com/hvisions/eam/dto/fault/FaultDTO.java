package com.hvisions.eam.dto.fault;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.ObjectTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: FaultDTO</p >
 * <p>Description: 设备故障DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/26</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@lombok.EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "设备故障DTO")
public class FaultDTO extends SysBaseDTO implements IObjectType {

    /**
     * 故障代码
     */
    @ApiModelProperty(value = "故障代码", required = true)
    private String faultCode;

    /**
     * 故障名称
     */
    @ApiModelProperty(value = "故障名称,非空", required = true)
    private String faultName;

    /**
     * 故障现象
     */
    @ApiModelProperty(value = "故障现象")
    private String description;

    /**
     * 故障类别
     */
    @ApiModelProperty(value = "故障类别id")
    private Integer faultClassId;

    /**
     * 故障类别名称
     */
    private String faultClassName;

    /**
     * 对象类型编码
     *
     * @return 对象类型编码
     */
    @Override
    public Integer getObjectType() {
        return ObjectTypeEnum.FAULT_DTO.getCode();
    }
}
