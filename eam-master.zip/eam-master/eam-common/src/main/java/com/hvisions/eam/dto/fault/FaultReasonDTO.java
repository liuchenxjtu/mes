package com.hvisions.eam.dto.fault;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.ObjectTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>Title: FaultReasonDTO</p >
 * <p>Description: 故障原因DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/27</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "故障原因DTO")
public class FaultReasonDTO extends SysBaseDTO implements IObjectType {
    /**
     * 故障原因编码
     */
    @ApiModelProperty(value = "故障原因编码", required = true)
    private String reasonCode;
    /**
     * 故障原因
     */
    @ApiModelProperty(value = "故障原因")
    private String reason;
    /**
     * 故障id
     */
    @ApiModelProperty(value = "故障id")
    private Integer faultId;

    /**
     * 故障名称
     */
    @ApiModelProperty(value = "故障名称")
    private String faultName;

    /**
     * 对象类型编码
     *
     * @return 对象类型编码
     */
    @Override
    public Integer getObjectType() {
        return ObjectTypeEnum.FAULT_REASON_DTO.getCode();
    }
}