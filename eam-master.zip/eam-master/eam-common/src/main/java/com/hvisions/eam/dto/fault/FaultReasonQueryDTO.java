package com.hvisions.eam.dto.fault;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>Title: FaultReasonQueryDTO</p >
 * <p>Description: 故障查询故障原因DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/2</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "故障查询故障原因DTO")
public class FaultReasonQueryDTO extends PageInfo {
    /**
     * 故障id
     */
    @ApiModelProperty(value = "故障id")
    private Integer faultId;
}