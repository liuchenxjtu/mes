package com.hvisions.eam.dto.fault;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.ObjectTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: FaultSolutionDTO</p >
 * <p>Description: 设备故障解决方案DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/26</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@lombok.EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "设备故障解决方案DTO")
public class FaultSolutionDTO extends SysBaseDTO implements IObjectType {

    /**
     * 解决方案编码
     */
    @ApiModelProperty(value = "解决方案编码", required = true)
    private String solutionCode;
    /**
     * 解决方案名称
     */
    @ApiModelProperty(value = "解决方案名称")
    private String solutionName;
    /**
     * 解决步骤
     */
    @ApiModelProperty(value = "解决步骤")
    private String solution;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 故障原因id
     */
    @ApiModelProperty(value = "故障原因id")
    private Integer reasonId;

    /**
     * 故障原因Name
     */
    @ApiModelProperty(value = "故障原因Name")
    private String reasonName;

    /**
     * 对象类型编码
     *
     * @return 对象类型编码
     */
    @Override
    public Integer getObjectType() {
        return ObjectTypeEnum.FAULT_SOLUTION_DTO.getCode();
    }
}