package com.hvisions.eam.dto.inspect.content;

import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.dto.inspect.item.InspectItemDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>Title: InspectContentDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/27</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "点检内容DTO")
public class InspectContentDTO extends SysBaseDTO {
    /**
     * 点检内容code
     */
    @ApiModelProperty(value = "r点检内容名称code,必传")
    private String inspectContentCode;
    /**
     * 点检内容名称
     */
    @ApiModelProperty(value = "点检内容名称,必传")
    private String inspectContentName;
    /**
     * 设备型号id
     */
    @ApiModelProperty(value = "设备型号id")
    private Integer equipmentTypeId;
    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用")
    private Boolean startUsing;

    /**
     * 是否需要停机
     * @return 是否需要停机
     */
    @SuppressWarnings("Duplicates")
    @ApiModelProperty(value = "是否需要停机")
    public Boolean getShutDown() {
        boolean result = false;
        if (inspectItemDTOList != null && !inspectItemDTOList.isEmpty()) {
            List<Boolean> collect = inspectItemDTOList.stream().map(InspectItemDTO::getShutDown).collect(Collectors.toList());
            for (Boolean b : collect) {
                if (b != null && b.equals(true)) {
                    result = true;
                    break;
                }
            }
        }
        return result;
    }

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 点检项目id集合
     */
    @ApiModelProperty(value = "点检项目id集合")
    private List<Integer> inspectItemIdList;
    /**
     * 点检项目DTO集合
     */
    @ApiModelProperty(value = "点检项目DTO集合,不用传递")
    private List<InspectItemDTO> inspectItemDTOList;

}