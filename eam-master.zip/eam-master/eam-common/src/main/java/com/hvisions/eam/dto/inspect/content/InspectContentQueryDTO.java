package com.hvisions.eam.dto.inspect.content;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>Title: InspectContentQueryDTO</p >
 * <p>Description: 点检内容分页查询条件</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/13</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "点检内容查询条件")
@Data
public class InspectContentQueryDTO extends PageInfo {
    /**
     * 点检内容名称
     */
    @ApiModelProperty(value = "点检内容名称")
    private String inspectContentName;
    /**
     * 设备型号id
     */
    @ApiModelProperty(value = "设备型号id")
    private Integer equipmentTypeId;
    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用")
    private Boolean startUsing;
}