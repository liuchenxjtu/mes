package com.hvisions.eam.dto.inspect.content;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: TaskExportDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/25</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class TaskExportDTO {
    @ApiModelProperty("任务名称")
    private String name;
    @ApiModelProperty("描述")
    private String description;
    @ApiModelProperty("紧急度")
    private String priorityName;
    @ApiModelProperty("执行人")
    private String assigneeName;
    @ApiModelProperty(value = "任务编码")
    private String id;
    @ApiModelProperty(value = "创建时间")
    private Date createTime;
}
