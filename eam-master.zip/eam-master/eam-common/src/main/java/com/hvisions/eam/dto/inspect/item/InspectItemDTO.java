package com.hvisions.eam.dto.inspect.item;

import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.dto.inspect.utils.Common;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * <p>Title: InspectItemDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/23</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@ApiModel(description = "点检项目DTO")
public class InspectItemDTO extends SysBaseDTO {
    /**
     * 保养项目编号
     */
    @ApiModelProperty(value = "保养项目编号", readOnly = true)
    private String inspectItemCode;
    /**
     * 保养项目名称
     */
    @ApiModelProperty(value = "保养项目名称", required = true)
    private String inspectItemName;

    /**
     * 保养内容
     */
    @ApiModelProperty(value = "保养内容", required = true)
    private String inspectWork;
    /**
     * 是否需要停机
     */
    @ApiModelProperty(value = "是否需要停机", required = true)
    private Boolean shutDown;
    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用", required = true)
    private Boolean startUsing;


    /**
     * 零部件
     */
    @ApiModelProperty(value = "零部件")
    private String parts;


    /**
     * 推荐周期
     */
    @ApiModelProperty(value = "推荐周期")
    private String cycle;
    /**
     * 所需工时
     */
    @ApiModelProperty(value = "工时")
    private Float manHour;
    /**
     * 所需工时
     * @return 工时字符串
     */
    @ApiModelProperty(value = "工时字符串",readOnly = true)
    public String getManHourString(){
        return Common.getTimeString(manHour);
    }

    /**
     * 文件IDList
     */
    @ApiModelProperty(value = "文件idList")
    private List<Integer> fileIds;

    /**
     * 关联的设备信息
     */
    @ApiModelProperty(value = "关联的设备信息")
    private List<EquipmentInfo> equipmentInfos;

    /**
     * 关联的设备类型信息
     */
    @ApiModelProperty(value = "关联的设备类型信息")
    private List<EquipmentTypeInfo> equipmentTypeInfos;

}