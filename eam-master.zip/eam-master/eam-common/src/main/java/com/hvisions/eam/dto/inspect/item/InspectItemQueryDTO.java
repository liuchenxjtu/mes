package com.hvisions.eam.dto.inspect.item;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * <p>Title: InspectItemQueryDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/23</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@ApiModel(description = "点检项目查询条件")
@Data
@EqualsAndHashCode(callSuper = true)
public class InspectItemQueryDTO extends PageInfo {
    /**
     * 关键词
     */
    @ApiModelProperty(value = "关键词")
    private String keyword;
    /**
     * 保养项目编号
     */
    @ApiModelProperty(value = "保养项目编号", readOnly = true)
    private String inspectItemCode;
    /**
     * 保养项目名称
     */
    @ApiModelProperty(value = "保养项目名称", required = true)
    private String inspectItemName;

    /**
     * 保养内容
     */
    @ApiModelProperty(value = "保养内容", required = true)
    private String inspectWork;

    /**
     * 周期
     */
    @ApiModelProperty(value = "周期")
    private String cycle;
    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用")
    private Boolean startUsing;
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
     * 设备类型id列表
     */
    @ApiModelProperty(value = "设备类型id列表")
    private List<Integer> equipmentTypeIds;




}