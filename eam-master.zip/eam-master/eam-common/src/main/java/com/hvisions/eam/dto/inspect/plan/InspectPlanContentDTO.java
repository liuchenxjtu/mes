package com.hvisions.eam.dto.inspect.plan;

import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.dto.inspect.item.InspectItemDTO;
import com.hvisions.eam.dto.inspect.utils.Common;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * <p>Title: InspectPlanContentDTO</p >
 * <p>Description: 点巡检计划和内容设备顺序关系DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/16</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "点巡检计划和内容设备顺序关系DTO")
public class InspectPlanContentDTO extends SysBaseDTO {
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
     * 巡检顺序号
     */
    @ApiModelProperty(value = "巡检顺序号，优先级")
    private Integer priority;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称", readOnly = true)
    private String equipmentName;
    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码", readOnly = true)
    private String equipmentCode;
    /**
     * 点巡检项目List
     */
    @ApiModelProperty(value = "点巡检项目List")
    private List<InspectItemDTO> itemDTOList;

    /**
     * 所需工时
     *
     * @return 工时
     */
    @ApiModelProperty(value = "所需工时")
    public Float getManHour() {
        if (itemDTOList == null || itemDTOList.size() == 0) {
            return 0f;
        }
        List<InspectItemDTO> list = new ArrayList<>();
        for (InspectItemDTO itemDTO : itemDTOList) {
            if (itemDTO.getStartUsing()) {
                list.add(itemDTO);
            }
        }
        return itemDTOList.stream()
            .map(t -> Optional.ofNullable(t.getManHour()).orElse(0f))
            .reduce((f1, f2) -> f1 + f2)
            .orElse(0f);
    }

    /**
     * 所需工时
     *
     * @return 工时
     */
    @ApiModelProperty(value = "所需工时",readOnly = true)
    public String getManHourString() {
        return Common.getTimeString(getManHour());
    }
}