package com.hvisions.eam.dto.inspect.plan;

import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.dto.inspect.utils.Common;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>Title: InspectPlanDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/28</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "点检计划DTO")
public class InspectPlanDTO extends SysBaseDTO {
    public InspectPlanDTO() {
        this.inspectPlanContentDTOList = new ArrayList<>();
    }

    /**
     * 点检计划编号
     */
    @ApiModelProperty(value = "点检计划编号", readOnly = true)
    private String inspectPlanNum;
    /**
     * 点检计划名称
     */
    @ApiModelProperty(value = "点检计划名称")
    private String inspectPlanName;
    /**
     * 点检计划状态id
     */
    @ApiModelProperty(value = "点检计划状态id", readOnly = true)
    private Integer inspectPlanConditionId;
    /**
     * 点检计划审批状态名称
     */
    @ApiModelProperty(value = "点检计划审批状态名称", readOnly = true)
    private String inspectPlanConditionName;
    /**
     * 任务完成期限
     */
    @ApiModelProperty(value = "任务完成期限,单位，天")
    private Integer deadline;
    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用")
    private Boolean startUsing;
    /**
     * 点巡检计划与设备，内容，顺序关系DTOList
     */
    @ApiModelProperty(value = "点巡检计划与设备，内容，顺序关系DTOList")
    private List<InspectPlanContentDTO> inspectPlanContentDTOList;

    /**
     * 执行人姓名
     */
    @ApiModelProperty(value = "执行人姓名")
    private String transactorName;
    /**
     * 执行人id
     */
    @ApiModelProperty(value = "执行人id")
    private Integer transactorId;
    /**
     * 审核人id
     */
    @ApiModelProperty(value = "审核人id")
    private Integer checkerId;
    /**
     * 审核人姓名
     */
    @ApiModelProperty(value = "审核人姓名")
    private String checkerName;
    /**
     * 文件信息
     */
    @ApiModelProperty(value = "文件信息")
    private List<FileInfo> files;
    /**
     * 候选人列表
     */
    private List<String> candidateUsers;

    @ApiModelProperty(value = "候选人列表")
    public List<String> getCandidateUsers() {
        if (candidateUsers == null) {
            return new ArrayList<>();
        }
        return candidateUsers;
    }

    /**
     * 候选组列表
     */
    private List<String> candidateGroups;

    @ApiModelProperty(value = "候选组列表")
    public List<String> getCandidateGroups() {
        if (candidateGroups == null) {
            return new ArrayList<>();
        }
        return candidateGroups;
    }

    /**
     * timer周期id
     */
    @ApiModelProperty(value = "timer周期id")
    private Integer timerId;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 点巡检项目数量
     */
    @ApiModelProperty(value = "点巡检项目数量")
    private Long itemCount;
    /**
    *   设备名称信息
    */
    @ApiModelProperty(value = "设备名称信息")
    private String equipmentNames;

    /**
     * 计划所需工时
     *
     * @return 工时
     */
    @ApiModelProperty(value = "计划所需工时")
    public String getManHourString() {
        float result = 0F;
        for (InspectPlanContentDTO planContentDTO : inspectPlanContentDTOList) {
            float manHour = planContentDTO.getManHour();
            result += manHour;
        }
        return Common.getTimeString(result);
    }

    /**
     * 驳回原因
     */
    @ApiModelProperty(value = "驳回原因")
    private String rejectReason;
    /**
     * timer信息
     */
    @ApiModelProperty(value = "timer信息", readOnly = true)
    private String timerDescription;

}