package com.hvisions.eam.dto.inspect.plan;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * <p>Title: InspectPlanItemDTO</p >
 * <p>Description: 点巡检计划 设备 保养项目DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2020/12/7</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@Data
public class InspectPlanItemDTO {
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id",required = true)
    private Integer equipmentId;

    /**
     * 点检内容id
     */
    @ApiModelProperty(value = "点巡检项目ids",required = true)
    private List<Integer> inspectItemIds;

    /**
     * 巡检顺序号
     */
    @ApiModelProperty(value = "巡检顺序号，优先级",required = true)
    private Integer priority;
}