package com.hvisions.eam.dto.inspect.plan;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * <p>Title: InspectPlanQueryDTO</p >
 * <p>Description: 点检计划查询条件</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/13</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "点检计划查询条件")
@Data
public class InspectPlanQueryDTO extends PageInfo {
    /**
     * 点检计划名称
     */
    @ApiModelProperty(value = "点检计划名称")
    private String inspectPlanName;
    /**
     * 点检计划状态id
     */
    @ApiModelProperty(value = "点检计划状态id")
    private Integer inspectPlanConditionId;
    /**
    *   设备id
    */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
    *   周期id
    */
    @ApiModelProperty(value = "周期id")
    private Integer timerId;
    /**
    *   创建时间开始
    */
    @ApiModelProperty(value = "创建时间开始")
    private Date createTimeBegin;
    /**
    *   创建时间结束
    */
    @ApiModelProperty(value = "创建时间结束")
    private Date createTimeEnd;
}