package com.hvisions.eam.dto.inspect.plan;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: InspectPlanRejectDTO</p >
 * <p>Description:计划驳回DTO </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/18</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@ApiModel(description = "计划驳回DTO")
@Data
public class InspectPlanRejectDTO {
    /**
     * 任务id
     */
    @ApiModelProperty(value = "任务id", required = true)
    private String taskId;
    /**
     * 驳回原因
     */
    @ApiModelProperty(value = "驳回原因", required = true)
    private String rejectReason;

}
