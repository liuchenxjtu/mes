package com.hvisions.eam.dto.inspect.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * Auto-generated: 2021-01-12 9:37:25
 *
 * @author leiming
 */

@Getter
@Setter
@ToString
public class Data {
    private String processInstanceId;
    private String processDefinitionId;
    private String processDefinitionName;
    private String processDefinitionKey;
    private String processDefinitionVersion;
    private String deploymentId;
    private String businessKey;
    private String tenantId;
    private String name;
    private String description;
    private String localizedName;
    private String localizedDescription;
    private Date startTime;
    private Date endTime;
    private Integer startUserId;
    private VariableList processInstanceVariables;
}