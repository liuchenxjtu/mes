/**
 * Copyright 2021 json.cn
 */
package com.hvisions.eam.dto.inspect.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Auto-generated: 2021-01-12 9:37:25
 *
 * @author leiming
 */

@Getter
@Setter
@ToString
public class InspectPlanContentDTO {
    private Integer id;
    private Integer inspectPlanId;
    private Integer equipmentId;
    private Integer inspectContentId;
    private String inspectContentCode;
    private String inspectContentName;
    private Integer priority;
    private String equipmentName;
    private String equipmentCode;
    private String factory;
    private String workShop;
    private String line;
    private List<ItemDTO> itemDTOList;
    private String equipmentTypeId;
    private Boolean shutDown;
    private String manHourString;
    private Integer manHour;
}