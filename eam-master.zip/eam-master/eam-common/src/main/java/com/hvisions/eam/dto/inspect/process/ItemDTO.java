package com.hvisions.eam.dto.inspect.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.List;

/**
 * Auto-generated: 2021-01-12 9:37:25
 *
 * @author leiming
 */

@Getter
@Setter
@ToString
public class ItemDTO {
    private Integer id;
    private Date createTime;
    private String updateTime;
    private String creatorId;
    private String updaterId;
    private String siteNum;
    private String inspectItemName;
    private String inspectItemCode;
    private Integer equipmentTypeId;
    private String inspectPosition;
    private String inspectWork;
    private String inspectTheoreticalValue;
    private Boolean startUsing;
    private Integer manHour;
    private Boolean shutDown;
    private List<String> fileIds;
    private String done;
    private String remark;
    private String parts;
    private String inspectionMethod;
    private String cycle;
    private String personInCharge;
    private String manHourString;

}