package com.hvisions.eam.dto.inspect.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.List;

/**
 * Auto-generated: 2021-01-12 9:37:25
 *
 * @author leiming
 */

@Getter
@Setter
@ToString
public class VariableList {
    private List<InspectPlanContentDTO> inspectPlanContentDTOList;
    private String executorName;
    private String manHourString;
    private Integer checkerId;
    private String checkerName;
    private String taskName;
    private String equipmentName;
    private String category;
    private String taskNum;
    private String hvisionsTaskState;
    private Integer executor_id;
    private Date taskEndTime;

}