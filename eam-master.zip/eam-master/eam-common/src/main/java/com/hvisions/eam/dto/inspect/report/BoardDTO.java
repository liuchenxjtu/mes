package com.hvisions.eam.dto.inspect.report;

/**
 * <p>Title: BoardDTO</p>
 * <p>Description: 点巡检看板信息</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/15</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@ToString
public class BoardDTO {
    /**
     * 巡检总次数
     */
    @ApiModelProperty(value = "巡检总次数")
    private Integer totalInspectNumber;
    /**
     * 巡检项总数
     */
    @ApiModelProperty(value = "巡检项总数")
    private Integer totalInspectItemNumber;
    /**
     * 今天巡检次数
     */
    @ApiModelProperty(value = "今天巡检次数")
    private Integer todayInspectNumber;
    /**
     * 今天巡检项数量
     */
    @ApiModelProperty(value = "今天巡检项数量")
    private Integer todayInspectItemNumber;
    /**
     * 当月巡检次数
     */
    @ApiModelProperty(value = "当月巡检次数")
    private Integer monthInspectNumber;
    /**
     * 当月巡检项数量
     */
    @ApiModelProperty(value = "当月巡检项数量")
    private Integer monthInspectItemNumber;
    /**
     * 本年巡检次数
     */
    @ApiModelProperty(value = "本年巡检次数")
    private Integer yearInspectNumber;
    /**
     * 本年巡检项
     */
    @ApiModelProperty(value = "本年巡检项")
    private Integer yearInspectItemNumber;

    /**
     * 今日巡检项完成数量
     */
    @ApiModelProperty(value = "今日巡检项完成数量")
    private Integer todayFinishedInspectItemNumber;

    /**
     * 最近完成的巡检时间
     */
    @JsonFormat( pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    @ApiModelProperty(value = "最近完成的巡检时间", notes = "可能为空，前端显示--:--")
    private LocalDateTime lastInspectFinishTime;

    /**
     * 本周巡检信息统计
     */
    @ApiModelProperty(value = "本周巡检信息统计")
    private Integer[][] weekInspectInfo;

    /**
     * 巡检任务完成度占比
     */
    @ApiModelProperty(value = "巡检任务完成度占比")
    private Map<Integer, Integer> taskFinishInfo;

    /**
     * 本周合格率信息
     */
    @ApiModelProperty(value = "本周合格率信息")
    private List<PassRate> passRateList;


    /**
     * 当月巡检项不合格Top10
     */
    @ApiModelProperty(value = "当月巡检项不合格Top10")
    private List<ItemInfo> failItemInfoList;

    /**
     * 当月人员检查项统计
     */
    @ApiModelProperty(value = "当月人员检查项统计")
    private List<PersonInfo> userInspectItem;


}









