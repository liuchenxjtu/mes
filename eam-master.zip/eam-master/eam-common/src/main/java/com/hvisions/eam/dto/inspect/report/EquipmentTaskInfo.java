package com.hvisions.eam.dto.inspect.report;

/**
 * <p>Title: EquipmentTaskInfo</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2022/6/23</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hvisions.activiti.dto.task.TaskWithVariableDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Getter
@Setter
@ToString
@Slf4j
public class EquipmentTaskInfo {
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;
    /**
     * 地图上的横坐标
     */
    @ApiModelProperty(value = "地图上的横坐标")
    private BigDecimal xAxis;
    /**
     * 地图上的纵坐标
     */
    @ApiModelProperty(value = "地图上的纵坐标")
    private BigDecimal yAxis;

    /**
     * 任务数量
     */
    @ApiModelProperty(value = "任务数量")
    public Integer getTaskNum() {
        return Optional.ofNullable(taskInfo)
            .map(List::size)
            .orElse(0);
    }

    /**
     * 内部字段
     */
    @JsonIgnore
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * 任务状态
     */
    @ApiModelProperty(value = "任务状态", notes = "1：没任务,2:有任务并且都没有过期，3：有过期任务")
    public Integer getTaskState() {
        if (CollectionUtils.isEmpty(taskInfo)) {
            return 1;
        }
        for (TaskWithVariableDTO taskInstanceDTO : taskInfo) {
            Map<String, Object> variableList = taskInstanceDTO.getVariableList();
            if (variableList != null) {
                Object time = variableList.get("taskEndTime");
                Date date;
                try {
                    date = simpleDateFormat.parse((String) time);
                } catch (ParseException e) {
                    log.info("时间转换错误，请检查任务的结束时间设置");
                    continue;
                }
                if (new Date().after(date)) {
                    return 3;
                }
            }
        }
        return 2;
    }

    /**
     * 任务详情
     */
    @ApiModelProperty(value = "任务详情")
    private List<TaskWithVariableDTO> taskInfo;
}









