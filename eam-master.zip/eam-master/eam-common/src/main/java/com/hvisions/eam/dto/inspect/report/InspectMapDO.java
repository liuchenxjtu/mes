package com.hvisions.eam.dto.inspect.report;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * <p>Title: InspectMapDO</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2022/6/23</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@Slf4j
public class InspectMapDO {
    /**
     * 地图id
     */
    @ApiModelProperty(value = "地图id")
    private Integer id;
    /**
     * 地图名称
     */
    @ApiModelProperty(value = "地图名称")
    private String mapName;
    /**
     * 地图描述
     */
    @ApiModelProperty(value = "地图描述")
    private String mapDesc;
    /**
     * 地图文件
     */
    @ApiModelProperty(value = "地图文件")
    private Integer mapFileId;

    /**
     * 是否有任务
     */
    @ApiModelProperty(value = "是否有任务")
    public Boolean hasTask() {
        return equipmentTaskInfoList.stream()
            .anyMatch(t -> !CollectionUtils.isEmpty(t.getTaskInfo()));
    }

    /**
     * 设备列表
     */
    @ApiModelProperty(value = "设备列表")
    private List<EquipmentTaskInfo> equipmentTaskInfoList;


}









