package com.hvisions.eam.dto.inspect.report;

/**
 * <p>Title: ItemFinishFail</p>
 * <p>Description: 失败情况</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/19</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
public class ItemFinishFail {
    /**
     * 完成时间
     */
    @ApiModelProperty(value = "完成时间")
    private LocalDateTime finishTime;

    /**
     * 是否失败
     */
    @ApiModelProperty(value = "是否失败")
    private Integer fail;
}









