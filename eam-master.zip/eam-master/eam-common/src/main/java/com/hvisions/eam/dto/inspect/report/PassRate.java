package com.hvisions.eam.dto.inspect.report;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

/**
 * <p>Title: PassRate</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/15</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
public class PassRate {
    /**
     * 日期
     */
    @ApiModelProperty(value = "日期")
    private LocalDate date;
    /**
     * 合格数量
     */
    @ApiModelProperty(value = "合格数量")
    private Integer passNumber;
    /**
     * 不合格数量
     */
    @ApiModelProperty(value = "不合格数量")
    private Integer failNumber;

    /**
     * 合格率
     */
    @ApiModelProperty(value = "合格率")
    public Integer getRate() {
        if (passNumber + failNumber == 0) {
            return 100;
        }
        return passNumber * 100 / (passNumber + failNumber);
    }
}









