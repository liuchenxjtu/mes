package com.hvisions.eam.dto.inspect.report;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * <p>Title: ItemInfo</p>
 * <p>Description: 巡检人员以及完成项目数量</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/19</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
public class PersonInfo {
    /**
     * 巡检项名称
     */
    @ApiModelProperty(value = "巡检项名称")
    private String personName;
    /**
     * 发生次数
     */
    @ApiModelProperty(value = "发生次数")
    private Integer completeCount;
}









