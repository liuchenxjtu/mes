package com.hvisions.eam.dto.inspect.report;

/**
 * <p>Title: ProcessInfo</p>
 * <p>Description: 点巡检流程实例信息</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/19</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import com.hvisions.eam.enums.ProcessFinishTypeEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
public class ProcessInfoDTO {
    /**
     * 流程实例id
     */
    @ApiModelProperty(value = "流程实例id")
    private String processInstanceId;

    /**
     * 时长限制
     */
    @ApiModelProperty(value = "时长限制")
    private Integer period;

    /**
     * 是否超时
     */
    @ApiModelProperty(value = "是否超时")
    public ProcessFinishTypeEnum getFinishType() {
        if (isFinished()) {
            if (finishTime.compareTo(getTargetFinishTime()) > 0) {
                return ProcessFinishTypeEnum.DELAY;
            } else {
                return ProcessFinishTypeEnum.FINISH;
            }
        } else {
            if (createTime.plusHours(period).compareTo(LocalDateTime.now()) > 0) {
                return ProcessFinishTypeEnum.NO_TASK;
            } else {
                return ProcessFinishTypeEnum.MISS;
            }
        }
    }


    /**
     * 是否完成
     */
    @ApiModelProperty(value = "是否完成")
    private Boolean isFinished() {
        return finishTime != null;
    }

    /**
     * 预期完成时间
     */
    @ApiModelProperty(value = "预期完成时间")
    private LocalDateTime getTargetFinishTime() {
        //如果没设置超时时间，默认为一天
        if (period == null) {
            return createTime.plusHours(24);
        }
        return createTime.plusHours(period);
    }

    /**
     * 周几
     */
    @ApiModelProperty(value = "周几")
    public int dayOfWeek() {
        return getTargetFinishTime().getDayOfWeek().getValue();
    }

    /**
     * 几点
     */
    @ApiModelProperty(value = "几点")
    public int hourOfDay() {
        return getTargetFinishTime().getHour();
    }

    /**
     * 任务创建时间
     */
    @ApiModelProperty(value = "任务创建时间")
    private LocalDateTime createTime;
    /**
     * 实际完成时间
     */
    @ApiModelProperty(value = "实际完成时间")
    private LocalDateTime finishTime;
}









