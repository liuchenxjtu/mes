package com.hvisions.eam.dto.inspect.statistical;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * <p>Title: InspectHistoryQueryDTO</p >
 * <p>Description: InspectHistoryQueryDTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/24</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@ApiModel(description = "根据设备id查历史查询条件")
@Data
@EqualsAndHashCode(callSuper = true)
public class InspectHistoryQueryDTO extends PageInfo {
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;

    /**
     * 开始时间
     */
    @ApiModelProperty(value = " 开始时间 ")
    private Date beginTime;

    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private Date endTime;

    /**
     * 业务主键ID
     */
    @ApiModelProperty("业务主键ID")
    String businessKey;
}