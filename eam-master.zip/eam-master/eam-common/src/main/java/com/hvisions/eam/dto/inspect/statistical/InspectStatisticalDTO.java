package com.hvisions.eam.dto.inspect.statistical;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>Title: InspectStatisticalDTO</p >
 * <p>Description: 点检统计DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/8</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@ApiModel(description = "点检统计DTO")
@EqualsAndHashCode(callSuper = true)
public class InspectStatisticalDTO extends SysBaseDTO {
    /**
     * 流程id
     */
    @ApiModelProperty(value = "流程id")
    private String processInstanceId;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;

    /**
     * 工厂
     */
    @ApiModelProperty(value = "工厂")
    private String factory;
    /**
     * 车间
     */
    @ApiModelProperty(value = "车间")
    private String workShop;
    /**
     * 设备所在产线
     */
    @ApiModelProperty(value = "设备所在产线")
    private String line;
    /**
     * 点检总次数
     */
    @ApiModelProperty(value = "点检总次数")
    private Integer inspectCount;

    /**
     * 点检总工时
     *
     * @return 点检
     */
    @ApiModelProperty(value = "点检总工时")
    public String getManHourString() {
        Float result = 0F;
        if (inspectItemDTOList != null && !inspectItemDTOList.isEmpty()) {
            List<InspectStatisticalItemDTO> list = inspectItemDTOList;
            List<Float> collect = list.stream().map(InspectStatisticalItemDTO::getManHour).collect(Collectors.toList());
            for (Float f : collect) {
                result = result + f;
            }
        }
        if (result < 60) {
            return String.format("%.0f分钟", result);
        } else {
            float hour1 = result / 60;
            BigDecimal hour2 = new BigDecimal(hour1);
            float hour3 = hour2.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
            double hour = Math.floor(hour3);
            double minute = (result - hour * 60);
            String hourString = String.format("%.0f小时", hour);
            String minuteString = String.format("%.0f分钟", minute);
            return hourString + minuteString;
        }
    }

    /**
     * 点检项目List
     */
    @ApiModelProperty(value = "点检项目List")
    private List<InspectStatisticalItemDTO> inspectItemDTOList = new ArrayList<>();
}