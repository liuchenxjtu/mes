package com.hvisions.eam.dto.inspect.statistical;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>Title: InspectStatisticalItemDTO</p >
 * <p>Description: 点检报表子项DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/8</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@ApiModel(description = "点检统计子项DTO")
public class InspectStatisticalItemDTO {
    /**
     * 流程id
     */
    @ApiModelProperty(value = "流程id")
    private String processInstanceId;
    /**
     * 检查部位
     */
    @ApiModelProperty(value = "检查部位")
    private String inspectPosition;
    /**
     * 检查工作
     */
    @ApiModelProperty(value = "检查工作")
    private String inspectWork;
    /**
     * 检查点理论值
     */
    @ApiModelProperty(value = "检查点理论值")
    private String inspectTheoreticalValue;
    /**
     * 所需工时
     */
    @ApiModelProperty(value = "所需工时")
    private Float manHour;

    /**
     * 工时字符串
     *
     * @return 工时
     */
    @ApiModelProperty(value = "工时字符串")
    public String getManHourString() {
        if (manHour >= 60) {
            float hour1 = manHour / 60;
            BigDecimal hour2 = new BigDecimal(hour1);
            float hour3 = hour2.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
            double hour = Math.floor(hour3);
            double minute = (manHour - hour * 60);
            String hourString = String.format("%.0f小时", hour);
            String minuteString = String.format("%.0f分钟", minute);
            return hourString + minuteString;
        } else {
            return String.format("%.0f分钟", manHour);
        }
    }

    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    private Date startTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private Date endTime;


}