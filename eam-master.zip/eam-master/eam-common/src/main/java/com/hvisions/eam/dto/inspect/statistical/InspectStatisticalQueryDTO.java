package com.hvisions.eam.dto.inspect.statistical;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: InspectStatisticalQueryDTO</p >
 * <p>Description: 点检统计查询条件DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/8</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@ApiModel(description = "点检统计查询条件DTO")
public class InspectStatisticalQueryDTO {
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName = "";

    /**
     * 设备所在产线
     */
    @ApiModelProperty(value = "设备所在产线")
    private String line = "";
    /**
     * 点检时间查询开始
     */
    @ApiModelProperty(value = "点检时间查询开始")
    private Date finishedBefore;
    /**
     * 点检时间查询结束
     */
    @ApiModelProperty(value = "点检时间查询结束")
    private Date finishedAfter;
}