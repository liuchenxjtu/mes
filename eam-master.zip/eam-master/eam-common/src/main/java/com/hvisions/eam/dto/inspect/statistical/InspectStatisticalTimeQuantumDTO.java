package com.hvisions.eam.dto.inspect.statistical;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: InspectStatisticalTimeQuantumDTO</p >
 * <p>Description: 时间段查询DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/9</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@ApiModel(description = "时间段查询点检次数DTO")
public class InspectStatisticalTimeQuantumDTO {
    /**
     * 时间
     */
    @ApiModelProperty(value = "时间")
    private Date time;
    /**
     * 次数
     */
    @ApiModelProperty(value = "次数")
    private Integer count;
}