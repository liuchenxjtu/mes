package com.hvisions.eam.dto.inspect.table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDate;

/**
 * <p>Title: InspectContentQueryDTO</p >
 * <p>Description: 点检流程内容查询条件</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/15</p >
 *
 * @author :czh
 * @version :1.0.0
 */
@ApiModel(description = "点检项查询条件")
@Data
public class InspectProcessQueryDTO  {
    /**
     * 点检内容名称
     */
    @ApiModelProperty(value = "点检项名称")
    private String inspectContentName;
    /**
     * 开始日期
     */
    @ApiModelProperty(value = "开始日期")
    private LocalDate endDate;
    /**
     * 开始日期
     */
    @ApiModelProperty(value = "结束日期")
    private LocalDate startDate;
    /**
     * 是否有图
     */
    @ApiModelProperty(value = "是否有图，0无1有")
    private Integer withPic;
    /**
     * 执行结果
     */
    @ApiModelProperty(value = "执行结果，1未完成2完成")
    private Integer done;
}