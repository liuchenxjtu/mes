package com.hvisions.eam.dto.inspect.table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>Title: InspectContentQueryDTO</p >
 * <p>Description: 点检流程内容查询条件</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/15</p >
 *
 * @author :czh
 * @version :1.0.0
 */
@ApiModel(description = "点检项查询结果")
@Data
public class InspectProcessResultDTO {
    /**
     * 点检内容名称
     */
    @ApiModelProperty(value = "点检内容名称")
    private String inspectContentName;
    /**
     * 执行人
     */
    @ApiModelProperty(value = "执行人")
    private String checker;
    /**
     * 所属计划
     */
    @ApiModelProperty(value = "所属计划")
    private String inspectPlanName;
    /**
     * 所属任务
     */
    @ApiModelProperty(value = "所属任务")
    private String taskName;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String description;

    /**
     * 日期
     */
    @ApiModelProperty(value = "日期")
    private LocalDate startDate;
    /**
     * 执行日期
     */
    @ApiModelProperty(value = "执行日期")
    private LocalDateTime executeDate;

    /**
     * 是否有图
     */
    @ApiModelProperty(value = "是否有图")
    private Integer withPic;
    /**
     * 执行结果
     */
    @ApiModelProperty(value = "执行结果")
    private Integer shutDown;

    /**
     * 图片id
     */
    @ApiModelProperty(value = "图片id")
    private Integer picId;
}