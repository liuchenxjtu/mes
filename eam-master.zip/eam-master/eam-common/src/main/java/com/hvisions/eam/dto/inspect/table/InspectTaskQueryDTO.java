package com.hvisions.eam.dto.inspect.table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDate;

/**
 * <p>Title: InspectContentQueryDTO</p >
 * <p>Description: 点检流程内容查询条件</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/15</p >
 *
 * @author :czh
 * @version :1.0.0
 */
@ApiModel(description = "点检任务查询条件")
@Data
public class InspectTaskQueryDTO {
    /**
     * 点检任务
     */
    @ApiModelProperty(value = "点检任务")
    private String taskName;
    /**
     * 开始日期
     */
    @ApiModelProperty(value = "开始日期")
    private LocalDate endDate;
    /**
     * 开始日期
     */
    @ApiModelProperty(value = "结束日期")
    private LocalDate startDate;
    /**
     * 执行人id
     */
    @ApiModelProperty(value = "执行人id")
    private Integer checkerId;
}