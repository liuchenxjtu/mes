package com.hvisions.eam.dto.inspect.table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>Title: InspectContentQueryDTO</p >
 * <p>Description: 点检流程内容查询条件</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/15</p >
 *
 * @author :czh
 * @version :1.0.0
 */
@ApiModel(description = "点检任务查询结果")
@Data
public class InspectTaskResultDTO {
    /**
     * 点检任务
     */
    @ApiModelProperty(value = "点检任务")
    private String taskName;
    /**
     * 点检编号
     */
    @ApiModelProperty(value = "点检编号")
    private String taskCode;
    /**
     * 执行人
     */
    @ApiModelProperty(value = "执行人")
    private String checker;
    /**
     * 紧急度
     */
    @ApiModelProperty(value = "紧急度")
    private String priority;

    /**
     * 所需时间
     */
    @ApiModelProperty(value = "所需时间")
    private Integer manHour;
    /**
     * 实际执行时间
     */
    @ApiModelProperty(value = "实际执行时间")
    private Integer duration;
    /**
     * 日期
     */
    @ApiModelProperty(value = "日期")
    private LocalDate startDate;
    /**
     * 执行日期
     */
    @ApiModelProperty(value = "执行日期")
    private LocalDateTime executeDate;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 任务描述
     */
    @ApiModelProperty(value = "任务描述")
    private String inspectWork;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String description;

}