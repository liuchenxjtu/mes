package com.hvisions.eam.dto.inspect.table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: InspectContentQueryDTO</p >
 * <p>Description: 点检任务统计</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/15</p >
 *
 * @author :czh
 * @version :1.0.0
 */
@ApiModel(description = "点检任务统计")
@Data
public class InspectTaskStaDTO {
    /**
     * 点检任务
     */
    @ApiModelProperty(value = "点检任务")
    private String taskName;
    /**
     * 执行人
     */
    @ApiModelProperty(value = "执行人")
    private String checker;

    /**
     * 实际执行时间
     */
    @ApiModelProperty(value = "实际执行时间")
    private Integer duration;

    /**
     * 延迟时间
     */
    @ApiModelProperty(value = "延迟时间")
    private Integer delay;
    /**
     * 日期
     */
    @ApiModelProperty(value = "日期")
    private String startDate;
    /**
     * 完成巡检任务数
     */
    @ApiModelProperty(value = "完成巡检任务数")
    private Integer num;

}