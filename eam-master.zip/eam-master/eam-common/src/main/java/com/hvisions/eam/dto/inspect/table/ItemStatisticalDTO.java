package com.hvisions.eam.dto.inspect.table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: InspectContentQueryDTO</p >
 * <p>Description: 点检项统计结果</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/15</p >
 *
 * @author :czh
 * @version :1.0.0
 */
@ApiModel(description = "点检项统计结果")
@Data
public class ItemStatisticalDTO {
    /**
     * 巡检项名称
     */
    @ApiModelProperty(value = "巡检项名称")
    private String inspectItemName;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 日期
     */
    @ApiModelProperty(value = "日期")
    private String startDate;
    /**
     * 数量
     */
    @ApiModelProperty(value = "数量")
    private Integer num;
}