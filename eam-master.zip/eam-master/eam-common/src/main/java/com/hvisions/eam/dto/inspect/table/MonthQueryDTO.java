package com.hvisions.eam.dto.inspect.table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: MonthQueryDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/4</p >
 *
 * @author : czh
 * @version :1.0.0
 */
@Data
@ApiModel(description = "周转率查询条件")
public class MonthQueryDTO {

    @ApiModelProperty(value = "年份")
    private Integer yearTime;
    @ApiModelProperty(value = "月份")
    private Integer monthTime;


}