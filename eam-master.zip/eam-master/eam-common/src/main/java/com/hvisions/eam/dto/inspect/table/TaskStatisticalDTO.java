package com.hvisions.eam.dto.inspect.table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: InspectContentQueryDTO</p >
 * <p>Description: 点检项统计结果</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/15</p >
 *
 * @author :czh
 * @version :1.0.0
 */
@ApiModel(description = "点检项统计结果")
@Data
public class TaskStatisticalDTO {
    /**
     * 执行人数
     */
    @ApiModelProperty(value = "执行人数")
    private Integer checkerNum;
    /**
     * 完成巡检任务
     */
    @ApiModelProperty(value = "完成巡检任务")
    private Integer num;
    /**
     * 巡检总耗时
     */
    @ApiModelProperty(value = "巡检总耗时")
    private Float duration;
    /**
     * 完成巡检任务
     */
    @ApiModelProperty(value = "人均耗时")
    private Float perChecker;
    /**
     * 执行人数
     */
    @ApiModelProperty(value = "平均完成时间")
    private Float perTask;
}