package com.hvisions.eam.dto.lub;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title:SpareExtendDTO</p>
 * <p>Description:导出用模板</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/21</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
public class LubExtendDTO {

    /**
     * 油品编码
     */
    @ApiModelProperty(value = "油品编码")
    private String lubCode;

    /**
     * 油品名称
     */
    @ApiModelProperty(value = "油品名称")
    private String lubName;

    /**
     * 单价
     */
    @ApiModelProperty(value = " 单价 ")
    private BigDecimal unitPrice;

    /**
     * 最大库存
     */
    @ApiModelProperty(value = " 最大库存 ")
    private BigDecimal cargoMax;

    /**
     * 最小库存
     */
    @ApiModelProperty(value = " 最小库存 ")
    private BigDecimal cargoMin;

    /**
     * 备注
     */
    @ApiModelProperty(value = " 备注 ")
    private String remarks;

    /**
     * 供应商
     */
    @ApiModelProperty(value = " 供应商 ")
    private String supplier;

    //---------------------------- 备件单位字段 ------------------------
    /**
     * 单位名称
     */
    @ApiModelProperty(value = " 单位名称 ")
    private String unitName;

    //---------------------------- 备件类型字段 ------------------------
    /**
     * 油品类型名称
     */
    @ApiModelProperty(value = " 油品类型名称 ")
    private String typeName;

    /**
     * DTO内部验证
     *
     * @return a
     */
    public Integer validation() {
        BigDecimal bigDecimal = new BigDecimal("0");
        if (this.getCargoMin() == null) {
            this.setCargoMin(bigDecimal);
        }
        if (this.getCargoMax() == null) {
            this.setCargoMax(bigDecimal);
        }
        if (this.unitPrice == null) {
            this.unitPrice = new BigDecimal(0);
        }
        //当两个库存数量都为空时 不进行验证
        //最小库存大于0
        if (this.getCargoMin().compareTo(bigDecimal) <= -1) {
            return -1;
            //最大库存大于最小库存
        } else if (this.getCargoMax().compareTo(this.getCargoMin()) <= -1) {
            return -1;

        }

        return 1;
    }
}
