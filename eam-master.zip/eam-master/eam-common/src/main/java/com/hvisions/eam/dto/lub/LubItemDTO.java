package com.hvisions.eam.dto.lub;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.StoreExceptionEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * <p>Title:Item</p>
 * <p>Description:油品申请项</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/4/9</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "油品申请DTO")
public class LubItemDTO extends SysBaseDTO implements IObjectType {

    /**
     * 备件ID
     */
    @ApiModelProperty(value = " 备件ID （必填）")
    Integer lubId;

    /**
     * 库位ID
     */
    @ApiModelProperty(value = " 库位ID （必填）")
    Integer shelveId;

    /**
     * 批次号
     */
    @ApiModelProperty(value = " 批次号 （必填）")
    String batchNumber;

    /**
     * 备件数量
     */
    @ApiModelProperty(value = " 备件数量 ")
    BigDecimal number;

    @Override
    public Integer getObjectType() {
        return StoreExceptionEnum.IN_USE.getCode();
    }
}
