package com.hvisions.eam.dto.lub;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * <p>Title:SpareToShelveDTO</p>
 * <p>Description:油品库位关系表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = " 油品库位关系DTO")
public class LubToShelveDTO extends SysBaseDTO {

    public LubToShelveDTO(){
        if (showNumberZero == null){
            showNumberZero = false;
        }
    }

    /**
     * 库位ID
     */
    @ApiModelProperty(value = " 库位ID (必填)")
    private Integer shelveId;

    /**
     * 备件ID
     */
    @ApiModelProperty(value = " 油品ID (必填)")
    private Integer lubId;

    /**
     * 油品code
     */
    @ApiModelProperty(value = " 油品code ")
    private String lubCode;

    /**
     * 备件库存数量
     */
    @ApiModelProperty(value = " 油品库存数量 (必填)")
    private BigDecimal number;

    /**
     * 批次号
     */
    @ApiModelProperty(value = "批次号 (必填)")
    private String batchNumber;

    /**
     * 图片
     */
    @ApiModelProperty(value = " 图片 ")
    private Integer img;

    /**
     * 油品名称
     */
    @ApiModelProperty(value = " 油品名称 ")
    private String lubName;

    /**
     * 油品code
     */
    @ApiModelProperty(value = " 油品类型code ")
    private String typeCode;

    /**
     * 油品code
     */
    @ApiModelProperty(value = " 油品名称 ")
    private String typeName;

    /**
     * 库位名称
     */
    @ApiModelProperty(value = " 库位名称 ")
    private String shelveName;

    /**
     * 展示数量为空的数据 默认不展示
     */
    @ApiModelProperty(value = " 展示数量为空的数据 默认不展示 ",example = "false")
    private Boolean showNumberZero;

    /**
     * 库存数量状态 0 数据错误或为填写最大最小值  1 库存不足 2 库存超限
     */
    @ApiModelProperty(value = " 库存数量状态 ")
    private Integer inventoryQuantityStatus;

}