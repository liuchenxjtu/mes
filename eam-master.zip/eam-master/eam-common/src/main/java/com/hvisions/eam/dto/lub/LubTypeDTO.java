package com.hvisions.eam.dto.lub;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.StoreExceptionEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>Title:SpareTypeDTO</p>
 * <p>Description:油品型号</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/19</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "油品型号")
public class LubTypeDTO extends SysBaseDTO implements IObjectType {

    /**
     * 类型编码
     */
    @ApiModelProperty(value = " 类型编码 (必填)")
    private String typeCode;

    /**
     * 类型名称
     */
    @ApiModelProperty(value = " 类型名称 ")
    private String typeName;

    /**
     * 父级ID
     */
    @ApiModelProperty(value = " 父级ID ")
    private Integer parentId;

    /**
     * 是否内置
     */
    @ApiModelProperty(value = " 是否内置 ")
    private Integer isBuiltIn;

    @Override
    public Integer getObjectType() {
        return StoreExceptionEnum.IN_USE.getCode();
    }
}