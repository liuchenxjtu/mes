package com.hvisions.eam.dto.lub;

import com.hvisions.common.exception.BaseKnownException;
import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.StoreExceptionEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>Title:LubricatingDTO</p>
 * <p>Description:油品</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/4/15</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "油品 DTO")
public class LubricatingDTO extends SysBaseDTO implements IObjectType {

    public LubricatingDTO(){
        if (unitPrice == null){
            this.unitPrice = new BigDecimal(0);
        }
    }

    /**
     * 油品编码
     */
    @ApiModelProperty(value = "油品编码 (必填)")
    private String lubCode;

    /**
     * 油品名称
     */
    @ApiModelProperty(value = "油品名称 (必填)")
    private String lubName;

    /**
     * 油品型号ID
     */
    @ApiModelProperty(value = "油品型号ID (必填)")
    private Integer lubTypeId;

    /**
     * 单位id
     */
    @ApiModelProperty(value = "油品单位id (必填)")
    private Integer unitId;

    /**
     * 单价
     */
    @ApiModelProperty(value = " 单价 ")
    private BigDecimal unitPrice;

    /**
     * 最大库存
     */
    @ApiModelProperty(value = " 最大库存 ")
    private BigDecimal cargoMax;

    /**
     * 最小库存
     */
    @ApiModelProperty(value = " 最小库存 ")
    private BigDecimal cargoMin;

    /**
     * 备注
     */
    @ApiModelProperty(value = " 备注 ")
    private String remarks;

    /**
     * 供应商
     */
    @ApiModelProperty(value = " 供应商 ")
    private String supplier;

    /**
     * 图片
     */
    @ApiModelProperty(value = " 图片 ")
    private Integer img;

    //---------------------------- 备件单位字段 ------------------------
    /**
     * 单位名称
     */
    @ApiModelProperty(value = " 单位名称 ")
    private String unitName;

    /**
     * 单位符号
     */
    @ApiModelProperty(value = " 单位符号 ")
    private String unitSymbol;

    //---------------------------- 备件类型字段 ------------------------
    /**
     * 油品类型名称
     */
    @ApiModelProperty(value = " 油品类型名称 ")
    private String typeName;

    /**
     * 油品ID带层级结构的ID
     */
    @ApiModelProperty(value = " 油品类型ID带层级结构的数组 ")
    private List<Integer> typeIds;

    /**
     * DTO内部验证
     */
    public void validation() {
        BigDecimal bigDecimal = new BigDecimal("0");

        //当两个库存数量都为空时 不进行验证
        if (!(this.getCargoMin() == null && this.getCargoMax() == null)) {
            //最小库存大于0
            if (this.getCargoMin().compareTo(bigDecimal) <= -1) {
                throw new BaseKnownException(StoreExceptionEnum.SHELVE_NUMBER_EXCEPTION);
                //最大库存大于最小库存
            } else if (this.getCargoMax().compareTo(this.getCargoMin()) <= -1) {
                throw new BaseKnownException(StoreExceptionEnum.SHELVE_NUMBER_EXCEPTION);
            }
        }
        if (this.unitPrice == null){
            this.unitPrice = new BigDecimal(0);
        }
    }

    @Override
    public Integer getObjectType() {
        return StoreExceptionEnum.IN_USE.getCode();
    }
}