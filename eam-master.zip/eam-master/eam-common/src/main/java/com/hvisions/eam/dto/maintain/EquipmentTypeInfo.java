package com.hvisions.eam.dto.maintain;

/**
 * <p>Title: EquipmentTypeInfo</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2022/5/7</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EquipmentTypeInfo {
    /**
     * 设备类型id
     */
    @ApiModelProperty(value = "设备类型id")
    private Integer equipmentTypeId;
    /**
     * 设备类型编码
     */
    @ApiModelProperty(value = "设备类型编码")
    private String equipmentTypeCode;
    /**
     * 设备类型名称
     */
    @ApiModelProperty(value = "设备类型名称")
    private String equipmentTypeName;
}









