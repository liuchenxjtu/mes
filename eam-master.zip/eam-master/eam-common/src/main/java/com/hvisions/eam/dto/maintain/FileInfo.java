package com.hvisions.eam.dto.maintain;

/**
 * <p>Title: FileInfo</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2022/5/18</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FileInfo {
    /**
     * 文件id
     */
    @ApiModelProperty(value = "文件id")
    private Integer fileId;
    /**
     * 文件描述
     */
    @ApiModelProperty(value = "文件描述")
    private String description;
}









