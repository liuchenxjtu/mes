package com.hvisions.eam.dto.maintain;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: HiTaskDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2022/2/9</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class HiTaskDTO {

    @ApiModelProperty("任务id")
    private String taskId;

    @ApiModelProperty("任务描述")
    private String taskDesc;

    @ApiModelProperty("任务开始时间")
    private Date taskStartTime;

    @ApiModelProperty("任务结束时间")
    private Date taskEndTime;

    @ApiModelProperty(value = "任务类型", notes = "1: 维修任务;2: 保养任务")
    private Integer taskType;

    @ApiModelProperty("任务状态")
    private Integer taskStatus;

    @ApiModelProperty("任务状态")
    private String state;

    @ApiModelProperty("任务流程key")
    private String defKey;
    @ApiModelProperty(value = "预计结束时间")
    private String endTime;


}