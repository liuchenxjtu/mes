package com.hvisions.eam.dto.maintain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title: LubDTO</p >
 * <p>Description: 保养项目-油品关系DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/9</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@ApiModel(description = "保养项目-油品关系DTO")
public class LubDTO {
    /**
     * 油品id
     */
    @ApiModelProperty(value = "油品id")
    private Integer lubId;
    /**
     * 油品名称
     */
    @ApiModelProperty(value = "油品名称，不用传递")
    private String lubName;
    /**
     * 油品数量
     */
    @ApiModelProperty(value = "油品数量")
    private BigDecimal lubNum;
    /**
     * 油品编码
     */
    @ApiModelProperty(value = "油品编码")
    private String lubCode;
    /**
     * 油品单位
     */
    @ApiModelProperty(value = "油品单位")
    private String lubUnit;
    /**
     * 油品供应商
     */
    @ApiModelProperty(value = "油品供应商")
    private String lubSupplier;

}