package com.hvisions.eam.dto.maintain;

import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.utils.Common;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>Title: MaintainContentDTO</p >
 * <p>Description: 保养内容DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/18</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "保养内容DTO")
public class MaintainContentDTO extends SysBaseDTO {
    /**
     * 设备型号id
     */
    @ApiModelProperty(value = "设备型号id", required = true)
    private Integer equipmentTypeId;
    /**
     * 保养内容编码
     */
    @ApiModelProperty(value = "保养内容编码", readOnly = true)
    private String maintainContentCode;
    /**
     * 保养内容名称
     */
    @ApiModelProperty(value = "保养内容名称", required = true)
    private String maintainContentName;

    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用", required = true)
    private Boolean startUsing = true;

    /**
     * 是否停机
     *
     * @return 是否停机
     */
    @ApiModelProperty(value = "是否需要停机", readOnly = true)
    public Boolean getShutDown() {
        boolean result = false;
        if (maintainItemDTOList != null && !maintainItemDTOList.isEmpty()) {
            List<Boolean> collect = maintainItemDTOList.stream().map(MaintainItemDTO::getShutDown).collect(Collectors.toList());
            for (Boolean b : collect) {
                if (b != null && b.equals(true)) {
                    result = true;
                    break;
                }
            }
        }
        return result;
    }

    /**
     * 所需工时
     *
     * @return 工时
     */
    @ApiModelProperty(value = "所需工时", readOnly = true)
    public String getManHourString() {
        Float result = 0F;
        if (maintainItemDTOList == null || maintainItemDTOList.isEmpty()) {
            return "0分钟";
        }
        List<MaintainItemDTO> list = new ArrayList<>();
        for (MaintainItemDTO itemDTO : maintainItemDTOList) {
            if (itemDTO.getStartUsing()) {
                list.add(itemDTO);
            }
        }
        List<Float> collect = list.stream().map(MaintainItemDTO::getManHour).collect(Collectors.toList());
        for (Float f : collect) {
            result = result + f;
        }
        return Common.getTimeString(result);
    }

    /**
     * 保养项目List
     */
    @ApiModelProperty(value = "保养项目idList集合")
    private List<Integer> maintainItemIdList = new ArrayList<>();

    /**
     * 保养项目List
     */
    @ApiModelProperty(value = "保养项目DTO集合", readOnly = true)
    private List<MaintainItemDTO> maintainItemDTOList = new ArrayList<>();
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 保养内容来源
     */
    @ApiModelProperty(value = "保养内容来源", readOnly = true)
    private String flag = "manual";

}
