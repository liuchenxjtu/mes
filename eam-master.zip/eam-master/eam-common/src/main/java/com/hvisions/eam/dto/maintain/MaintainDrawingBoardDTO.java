package com.hvisions.eam.dto.maintain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title:MaintainDrawingBoardDTO</p>
 * <p>Description:保养润滑看板DTO</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2020/4/8</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
@ApiModel(description = "保养统计DTO")
public class MaintainDrawingBoardDTO {
    /**
     * 保养数量
     */
    @ApiModelProperty(value = "保养数量")
    public Integer maintainNum;

    /**
     * 润滑数量
     */
    @ApiModelProperty(value = "润滑数量")
    public Integer lubricateNum;

}
