package com.hvisions.eam.dto.maintain;

import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.utils.Common;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * <p>Title: MaintainItemDTO</p >
 * <p>Description: 保养项目DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/18</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "保养项目DTO")
public class MaintainItemDTO extends SysBaseDTO {
    /**
     * 保养项目编号
     */
    @ApiModelProperty(value = "保养项目编号", readOnly = true)
    private String maintainItemCode;
    /**
     * 保养项目名称
     */
    @ApiModelProperty(value = "保养项目名称", required = true)
    private String maintainItemName;

    /**
     * 保养内容
     */
    @ApiModelProperty(value = "保养内容", required = true)
    private String maintainWork;
    /**
     * 是否需要停机
     */
    @ApiModelProperty(value = "是否需要停机", required = true)
    private Boolean shutDown;
    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用", required = true)
    private Boolean startUsing;


    /**
     * 零部件
     */
    @ApiModelProperty(value = "零部件")
    private String parts;


    /**
     * 周期
     */
    @ApiModelProperty(value = "周期")
    private String cycle;
    /**
     * 所需工时
     */
    @ApiModelProperty(value = "工时")
    private Float manHour;

    /**
     * 工时字符串
     */
    @ApiModelProperty(value = "工时字符串", readOnly = true)
    public String getManHourString() {
        return Common.getTimeString(manHour);
    }

    /**
     * 文件IDList
     */
    @ApiModelProperty(value = "文件idList")
    private List<Integer> fileIds;

    /**
     * 项目-备件
     */
    @ApiModelProperty(value = "保养项目-备件关系")
    private List<SparesInfo> itemSparePartDTOList;
    /**
     * 项目-油品关系
     */
    @ApiModelProperty(value = "项目—油品关系")
    private List<LubDTO> itemLubDTOList;

    /**
     * 关联的设备信息
     */
    @ApiModelProperty(value = "关联的设备信息")
    private List<EquipmentInfo> equipmentInfos;

    /**
     * 关联的设备类型信息
     */
    @ApiModelProperty(value = "关联的设备类型信息")
    private List<EquipmentTypeInfo> equipmentTypeInfos;

}
