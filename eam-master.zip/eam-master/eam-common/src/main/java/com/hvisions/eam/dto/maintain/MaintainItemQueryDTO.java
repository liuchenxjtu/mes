package com.hvisions.eam.dto.maintain;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * <p>Title: MaintainItemQueryDTO</p >
 * <p>Description: 保养项目查询条件DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/18</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "保养项目查询对象")
@Data
public class MaintainItemQueryDTO extends PageInfo {
    /**
     * 关键词
     */
    @ApiModelProperty(value = "关键词")
    private String keyword;
    /**
     * 保养项目编号
     */
    @ApiModelProperty(value = "保养项目编号", readOnly = true)
    private String maintainItemCode;
    /**
     * 保养项目名称
     */
    @ApiModelProperty(value = "保养项目名称", required = true)
    private String maintainItemName;

    /**
     * 保养内容
     */
    @ApiModelProperty(value = "保养内容", required = true)
    private String maintainWork;

    /**
     * 周期
     */
    @ApiModelProperty(value = "周期")
    private String cycle;

    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用")
    private Boolean startUsing;

    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
     * 设备类型id列表
     */
    @ApiModelProperty(value = "设备类型id列表")
    private List<Integer> equipmentTypeIds;
}
