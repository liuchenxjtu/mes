package com.hvisions.eam.dto.maintain;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>Title: MaintainPlanDTO</p >
 * <p>Description: 保养计划DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/18</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "保养计划DTO")
public class MaintainPlanCreateOrUpdateDTO extends SysBaseDTO {
    public MaintainPlanCreateOrUpdateDTO() {
        this.deadline = 0;
        this.startUsing = true;
        this.autoSpare = false;
        this.autoLub = false;
        this.planItemDTOS = new ArrayList<>();

    }

    /**
     * 保养计划名称
     */
    @ApiModelProperty(value = "保养计划名称", required = true)
    private String maintainPlanName;

    /**
     * 任务完成期限
     */
    @ApiModelProperty(value = "任务完成期限，单位，天")
    private Integer deadline;

    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用", required = true)
    private Boolean startUsing;

    /**
     * 周期timerId
     */
    @ApiModelProperty(value = "周期timerId")
    private Integer timerId;


    /**
     * 设备类型id
     */
    @ApiModelProperty(value = "设备类型id，必传")
    private Integer equipmentTypeId;

    /**
     * 执行人id
     */
    @ApiModelProperty(value = "执行人id",required = true)
    private Integer transactorId;

    /**
     * 审核人id
     */
    @ApiModelProperty(value = "审核人id")
    private Integer checkerId;

    /**
     * 是否自动申请备件
     */
    @ApiModelProperty(value = "是否自动申请备件")
    private Boolean autoSpare;
    /**
     * 是否自动申请油品
     */
    @ApiModelProperty(value = "是否自动申请油品")
    private Boolean autoLub;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 设备保养项集合
     */
    @ApiModelProperty(value = "设备保养项集合")
    private List<MaintainPlanItemDTO> planItemDTOS ;

    /**
     * 驳回原因
     */
    @ApiModelProperty(value = "驳回原因")
    private String rejectReason;

}
