package com.hvisions.eam.dto.maintain;

import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.utils.Common;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * <p>Title: MaintainPlanDTO</p >
 * <p>Description: 保养计划DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/18</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "保养计划DTO")
public class MaintainPlanDTO extends SysBaseDTO {

    /**
     * 保养计划编号
     */
    @ApiModelProperty(value = "保养计划编号", readOnly = true)
    private String maintainPlanNum;

    /**
     * 保养计划名称
     */
    @ApiModelProperty(value = "保养计划名称", required = true)
    private String maintainPlanName;

    /**
     * 任务完成期限
     */
    @ApiModelProperty(value = "任务完成期限,非空，单位，天")
    private Integer deadline;
    /**
     * 保养计划审批状态名称
     */
    @ApiModelProperty(value = "保养计划审批状态", readOnly = true)
    private String maintainPlanConditionName;
    /**
     * 保养计划审批状态id
     */
    @ApiModelProperty(value = "保养计划审批状态id", readOnly = true)
    private Integer maintainPlanConditionId;
    /**
     * 是否启用
     */
    @ApiModelProperty(value = "是否启用", required = true)
    private Boolean startUsing;

    /**
     * 周期timerId
     */
    @ApiModelProperty(value = "周期timerId")
    private Integer timerId;

    /**
     * 执行人id
     */
    @ApiModelProperty(value = "执行人id")
    private Integer transactorId;
    /**
     * 执行人姓名
     */
    @ApiModelProperty(value = "执行人姓名", readOnly = true)
    private String transactorName;
    /**
     * 审核人id
     */
    @ApiModelProperty(value = "审核人id")
    private Integer checkerId;
    /**
     * 审核人姓名
     */
    @ApiModelProperty(value = "审核人姓名", readOnly = true)
    private String checkerName;


    /**
     * 是否自动申请备件
     */
    @ApiModelProperty(value = "是否自动申请备件")
    private Boolean autoSpare;
    /**
     * 是否自动申请油品
     */
    @ApiModelProperty(value = "是否自动申请油品")
    private Boolean autoLub;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 驳回原因
     */
    @ApiModelProperty(value = "驳回原因", readOnly = true)
    private String rejectReason;

    /**
    *   设备名称列表
    */
    @ApiModelProperty(value = "设备名称列表",readOnly = true)
    private String equipmentNames;

    /**
     * 候选人列表
     */
    @ApiModelProperty(value = "候选人列表")
    private List<String> candidateUsers;

    @ApiModelProperty(hidden = true)
    public List<String> getCandidateUsers() {
        if (candidateUsers == null) {
            return new ArrayList<>();
        }
        return candidateUsers;
    }

    @ApiModelProperty(hidden = true)
    public String getCandidateUsersString() {
        return String.join("#", getCandidateUsers());
    }

    /**
     * 候选人组列表
     */
    @ApiModelProperty(value = "候选人组列表")
    private List<String> candidateGroups;

    @ApiModelProperty(hidden = true)
    public List<String> getCandidateGroups() {
        if (candidateGroups == null) {
            return new ArrayList<>();
        }
        return candidateGroups;
    }

    @ApiModelProperty(hidden = true)
    public String getCandidateGroupsString() {
        return String.join("#", getCandidateGroups());
    }

    /**
     * 保养项目信息
     */
    @ApiModelProperty(value = "保养项目信息")
    private List<MaintainPlanItemDTO> planItems;
    /**
     * 文件信息
     */
    @ApiModelProperty(value = "文件信息")
    private List<FileInfo> files;

    /**
     * timer描述
     */
    @ApiModelProperty(value = "timer描述", readOnly = true)
    private String timerDescription;

    /**
     * 保养项目数量
     */
    @ApiModelProperty(value = "保养项目数量", readOnly = true)
    private Long itemCount;


    /**
     * 获取所有的备件信息
     */
    @ApiModelProperty(value = "获取所有的备件信息", readOnly = true)
    public List<SparesInfo> getAllItemSpareInfo(Integer equipmentId) {
        if (planItems == null) {
            return Collections.emptyList();
        }
        List<SparesInfo> result = new ArrayList<>();
        for (MaintainPlanItemDTO planItem : planItems) {
            if (equipmentId != null) {
                if (!planItem.getEquipmentId().equals(equipmentId)) {
                    continue;
                }
            }
            if (planItem.getSparesInfos() != null) {
                List<SparesInfo> planSpares = planItem.getSparesInfos();
                addToSpareList(result, planSpares);
            }
            if (planItem.getMaintainItems() == null) {
                continue;
            }
            for (MaintainItemDTO item : planItem.getMaintainItems()) {
                List<SparesInfo> itemSpares = item.getItemSparePartDTOList();
                addToSpareList(result, itemSpares);
            }
        }
        return result;
    }

    /**
     * 获取所有的备件信息
     */
    @ApiModelProperty(value = "获取所有的备件信息", readOnly = true)
    public List<SparesInfo> getAllItemSpareInfo() {
        return getAllItemSpareInfo(null);
    }

    private void addToSpareList(List<SparesInfo> result, List<SparesInfo> itemSpares) {
        for (SparesInfo itemSpare : itemSpares) {
            SparesInfo exists = result.stream()
                .filter(t -> t.getSparePartId().equals(itemSpare.getSparePartId()))
                .findFirst().orElse(null);
            if (exists == null) {
                result.add(itemSpare);
            } else {
                exists.setSparePartNum(exists.getSparePartNum().add(itemSpare.getSparePartNum()));
            }
        }
    }

    /**
     * 获取所有的润滑信息
     */
    @ApiModelProperty(value = "获取所有的润滑信息", readOnly = true)
    public List<LubDTO> getAllItemLubs(Integer equipmentId) {
        if (planItems == null) {
            return Collections.emptyList();
        }
        List<LubDTO> result = new ArrayList<>();
        for (MaintainPlanItemDTO planItem : planItems) {
            if (equipmentId != null) {
                if (!planItem.getEquipmentId().equals(equipmentId)) {
                    continue;
                }
            }
            if (planItem.getLubDTOList() != null) {
                List<LubDTO> planSpares = planItem.getLubDTOList();
                addToLubList(result, planSpares);
            }
            if (planItem.getMaintainItems() == null) {
                continue;
            }
            for (MaintainItemDTO item : planItem.getMaintainItems()) {
                List<LubDTO> itemSpares = item.getItemLubDTOList();
                addToLubList(result, itemSpares);
            }
        }
        return result;
    }

    /**
     * 获取所有的备件信息
     */
    @ApiModelProperty(value = "获取所有的备件信息", readOnly = true)
    public List<LubDTO> getAllItemLubs() {
        return getAllItemLubs(null);
    }

    private void addToLubList(List<LubDTO> result, List<LubDTO> itemSpares) {
        for (LubDTO itemSpare : itemSpares) {
            LubDTO exists = result.stream()
                .filter(t -> t.getLubId().equals(itemSpare.getLubId()))
                .findFirst().orElse(null);
            if (exists == null) {
                result.add(itemSpare);
            } else {
                exists.setLubNum(exists.getLubNum().add(itemSpare.getLubNum()));
            }
        }
    }


    /**
     * 消耗的总工时
     */
    @ApiModelProperty(value = "消耗的总工时", readOnly = true)
    public String getManHourString() {
        Float time = 0f;
        if (planItems != null) {
            for (MaintainPlanItemDTO planItem : planItems) {
                if (planItem.getMaintainItems() == null) {
                    continue;
                }
                for (MaintainItemDTO maintainItem : planItem.getMaintainItems()) {
                    time += Optional.ofNullable(maintainItem.getManHour()).orElse(0f);
                }
            }
        }
        return Common.getTimeString(time);
    }


}
