package com.hvisions.eam.dto.maintain;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: MaintainPlanImportDTO</p >
 * <p>Description: 保养计划导入模板</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/6/29</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
public class MaintainPlanImportDTO {
    /**
     * 保养计划编号
     */
    @ApiModelProperty(value = "保养计划编号")
    private String maintainPlanNum;

    /**
     * 保养计划名称
     */
    @ApiModelProperty(value = "保养计划名称")
    private String maintainPlanName;

    /**
     * 设备code
     */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;
    /**
     * 保养项目编码
     */
    @ApiModelProperty(value = "保养项目编码")
    private String maintainItemCode;
    /**
     * 执行人账号
     */
    @ApiModelProperty(value = "执行人账号")
    private String account;
    /**
     * 是否自动申请备件
     */
    @ApiModelProperty(value = "自动申请备件,是：true，否：不填或false")
    private Boolean autoSpare = false;
    /**
     * 是否自动申请油品
     */
    @ApiModelProperty(value = "自动申请油品，是：true，否：不填或false")
    private Boolean autoLub = false;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 完成期限（天）
     */
    @ApiModelProperty(value = "完成期限（天）")
    private Integer deadline;


}