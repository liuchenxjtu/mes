package com.hvisions.eam.dto.maintain;

/**
 * <p>Title: MaintainPlanItemDTO</p>
 * <p>Description: 保养计划的明细</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/12/4</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@ApiModel(description = "保养计划的明细")
public class MaintainPlanItemDTO {
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
    *   设备名称
    */
    @ApiModelProperty(value = "设备名称",readOnly = true)
    private String equipmentName;
    /**
    *   设备类型id
    */
    @ApiModelProperty(value = "设备类型id",readOnly = true)
    private Integer equipmentTypeId;

    /**
    *   设备编码
    */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;

    /**
     * 保养备件油品信息
     */
    @ApiModelProperty(value = "保养备件油品信息")
    private List<SparesInfo> sparesInfos;
    /**
     * 项目-油品关系
     */
    @ApiModelProperty(value = "项目—油品关系")
    private List<LubDTO> lubDTOList;
    /**
     * 保养项目id
     */
    @ApiModelProperty(value = "保养项目")
    private List<MaintainItemDTO> maintainItems;
}









