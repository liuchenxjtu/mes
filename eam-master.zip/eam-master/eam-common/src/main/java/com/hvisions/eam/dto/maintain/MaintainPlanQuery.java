package com.hvisions.eam.dto.maintain;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * <p>Title: MaintainPlanQuery</p >
 * <p>Description:保养计划查询条件 </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/18</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "保养计划查询对象")
@Data
public class MaintainPlanQuery extends PageInfo {
    /**
     * 保养计划名称
     */
    @ApiModelProperty(value = "保养计划名称")
    private String maintainPlanName;
    /**
     * 保养计划状态id
     */
    @ApiModelProperty(value = "保养计划状态id")
    private Integer maintainPlanConditionId;

    /**
    *   设备id
    */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
     *   周期id
     */
    @ApiModelProperty(value = "周期id")
    private Integer timerId;
    /**
     *   创建时间开始
     */
    @ApiModelProperty(value = "创建时间开始")
    private Date createTimeBegin;
    /**
     *   创建时间结束
     */
    @ApiModelProperty(value = "创建时间结束")
    private Date createTimeEnd;

}
