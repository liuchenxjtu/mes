package com.hvisions.eam.dto.maintain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>Title: MaintainStatisticalDTO</p >
 * <p>Description: 保养统计DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/4</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@ApiModel(description = "保养统计DTO")
public class MaintainStatisticalDTO {
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;
    /**
     * 保养总次数
     */
    @ApiModelProperty(value = "保养总次数")
    private Integer maintainCount;
    /**
     * 计划备件总数量
     */
    @ApiModelProperty(value = "计划备件总数")
    private BigDecimal sparePartPlanCount;


    /**
     * 实际备件总数
     */
    @ApiModelProperty(value = "实际备件总数")
    private BigDecimal sparePartCount;

    /**
     * 计划油品总数量
     */
    @ApiModelProperty(value = "计划油品总数")
    private BigDecimal lubPlanCount;
    /**
     * 实际油品总数
     */
    @ApiModelProperty(value = "实际油品总数")
    private BigDecimal lubCount;
    /**
     * 备件总价格
     */
    @ApiModelProperty(value = "备件总价格")
    private BigDecimal sparePrice;
    /**
     * 油品总价格
     */
    @ApiModelProperty(value = "油品总价格")
    private BigDecimal lubPrice;

    /**
     * 保养总工时
     * @return 保养总工时
     */
    @ApiModelProperty(value = "保养总工时")
    public String getManHourString() {
        Float result = 0F;
        if (statisticalItemDTOList != null && !statisticalItemDTOList.isEmpty()) {
            List<MaintainStatisticalItemDTO> list = statisticalItemDTOList;
            List<Float> collect = list.stream().map(MaintainStatisticalItemDTO::getManHour).collect(Collectors.toList());
            for (Float f : collect) {
                result = result + f;
            }
        }
        if (result < 60) {
            return String.format("%.0f分钟", result);
        } else {
            float hour1 = result / 60;
            BigDecimal hour2 = new BigDecimal(hour1);
            float hour3 = hour2.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
            double hour = Math.floor(hour3);
            double minute = (result - hour * 60);
            String hourString = String.format("%.0f小时", hour);
            String minuteString = String.format("%.0f分钟", minute);
            return hourString + minuteString;
        }
    }


    /**
     * 保养子项DTO
     */
    @ApiModelProperty(value = "保养子项DTO")
    private List<MaintainStatisticalItemDTO> statisticalItemDTOList = new ArrayList<>();


}