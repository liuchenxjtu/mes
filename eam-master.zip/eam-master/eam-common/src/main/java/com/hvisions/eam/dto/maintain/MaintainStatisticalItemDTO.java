package com.hvisions.eam.dto.maintain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>Title: MaintainStatisticalItemDTO</p >
 * <p>Description: 保养统计子项DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/4</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@ApiModel(description = "保养统计子项DTO")
public class MaintainStatisticalItemDTO {
    /**
     * 保养部位
     */
    @ApiModelProperty(value = "保养部位")
    private String maintainPosition;
    /**
     * 保养工作
     */
    @ApiModelProperty(value = "保养工作")
    private String maintainWork;
    /**
     * 工时
     */
    @ApiModelProperty(value = "工时")
    private Float manHour;
    /**
     * 工时字符串
     *
     * @return 工时字符串
     */
    @ApiModelProperty(value = "工时字符串")
    public String getManHourString() {
        if (manHour >= 60) {
            float hour1 = manHour / 60;
            BigDecimal hour2 = new BigDecimal(hour1);
            float hour3 = hour2.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
            double hour = Math.floor(hour3);
            double minute = (manHour - hour * 60);
            String hourString = String.format("%.0f小时", hour);
            String minuteString = String.format("%.0f分钟", minute);
            return hourString + minuteString;
        } else {
            return String.format("%.0f分钟", manHour);
        }
    }
    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    private Date beginTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private Date endTime;



}