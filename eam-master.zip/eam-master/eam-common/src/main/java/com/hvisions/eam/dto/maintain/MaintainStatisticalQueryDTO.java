package com.hvisions.eam.dto.maintain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: MaintainStatisticalQueryDTO</p >
 * <p>Description: 保养统计查询条件</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/4</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@ApiModel(description = "保养统计查询条件DTO")
public class MaintainStatisticalQueryDTO {
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName = "";
    /**
     * 保养时间查询开始
     */
    @ApiModelProperty(value = "保养时间查询开始")
    private Date finishedBefore;
    /**
     * 保养时间查询结束
     */
    @ApiModelProperty(value = "保养时间查询结束")
    private Date finishedAfter;
}