package com.hvisions.eam.dto.maintain;

import com.hvisions.eam.enums.RepairMaintainEnum;
import com.hvisions.eam.enums.TaskTypeEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * <p>Title: RepairMaintainCalendarCard</p >
 * <p>Description: 维修保养日历卡片</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2022/2/7</p >
 *
 * @author : x.l
 * @version :1.0.0
 */
@Data
public class RepairMaintainCalendarCard {

    @ApiModelProperty("维修保养时间")
    private LocalDate cardDate;

    @ApiModelProperty("任务详情数据")
    private List<RepairMaintainTaskDetail> taskDetails;

    /**
     * 获取维修任务个数
     *
     * @return 任务个数
     */
    public long getRepairTaskCount() {
        return Optional.ofNullable(taskDetails)
                .map(t -> t.stream().filter(task -> TaskTypeEnum.REPAIR_TASK.getCode().equals(task.getTaskType())).count())
                .orElse(0L);
    }

    /**
     * 获取保养任务个数
     *
     * @return 任务个数
     */
    public long getMaintainTaskCount() {
        return Optional.ofNullable(taskDetails)
                .map(t -> t.stream().filter(task -> TaskTypeEnum.MAINTAIN_TASK.getCode().equals(task.getTaskType())).count())
                .orElse(0L);
    }

    /**
     * 获取任务总个数
     *
     * @return 任务总个数
     */
    public Integer getTaskCount() {
        return Optional.ofNullable(taskDetails).map(List::size).orElse(0);
    }

    /**
     * 分组统计不同任务个数
     *
     * @return 任务数据
     */
    public Map<Integer, Long> getTaskStateGroupCount() {
        Map<Integer, Long> taskGroupCount = new HashMap<>();
        for (RepairMaintainEnum repairMaintainEnum : RepairMaintainEnum.values()) {
            long taskCount = Optional.ofNullable(taskDetails)
                    .map(t -> t.stream().filter(task -> repairMaintainEnum.getCode().equals(task.getTaskStatus())).count())
                    .orElse(0L);
            taskGroupCount.put(repairMaintainEnum.getCode(), taskCount);
        }
        return taskGroupCount;
    }

}
