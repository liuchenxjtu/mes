package com.hvisions.eam.dto.maintain;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * <p>Title: RepairMaintainTaskDetail</p >
 * <p>Description: 维修保养任务详情</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2022/2/7</p >
 *
 * @author : x.l
 * @version :1.0.0
 */
@Data
public class RepairMaintainTaskDetail {

    @ApiModelProperty("任务id")
    private String taskId;

    @ApiModelProperty("任务描述")
    private String taskDesc;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("任务开始时间")
    private LocalDateTime taskStartTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("任务结束时间")
    private LocalDateTime taskEndTime;


    @ApiModelProperty(value = "任务类型", notes = "1: 维修任务;2: 保养任务")
    private Integer taskType;

    @ApiModelProperty("任务状态")
    private Integer taskStatus;

}
