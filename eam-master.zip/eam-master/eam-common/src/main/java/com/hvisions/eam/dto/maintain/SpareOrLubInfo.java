package com.hvisions.eam.dto.maintain;

/**
 * <p>Title: SpareOrLubInfo</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/9/23</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
public class SpareOrLubInfo {
    private String type;
    private Integer itemId;
    private String code;
    private String name;
    private BigDecimal quantity;
    private Integer id;
}









