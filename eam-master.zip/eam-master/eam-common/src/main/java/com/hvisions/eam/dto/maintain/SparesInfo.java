package com.hvisions.eam.dto.maintain;

/**
 * <p>Title: SparesInfo</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/9/23</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
public class SparesInfo {

    /**
     * 备件id
     */
    @ApiModelProperty(value = "备件id")
    private Integer sparePartId;
    /**
     * 备件名称
     */
    @ApiModelProperty(value = "备件名称")
    private String sparePartName;
    /**
     * 备件数量
     */
    @ApiModelProperty(value = "备件数量")
    private BigDecimal sparePartNum;
    /**
     * 备件编码
     */
    @ApiModelProperty(value = "备件编码")
    private String sparePartCode;
    /**
     * 备件单位
     */
    @ApiModelProperty(value = "备件单位")
    private String sparePartUnit;
    /**
     * 备件供应商
     */
    @ApiModelProperty(value = "备件供应商")
    private String sparePartSupplier;
    /**
    *   备件类型名称
    */
    @ApiModelProperty(value = "备件类型名称")
    private String sparePartTypeName;
    /**
     * 品牌
     */
    @ApiModelProperty(value = " 品牌 ")
    private String sparePartBrand;


    /**
     * 规格
     */
    @ApiModelProperty(value = " 规格 ")
    private String sparePartSpecifications;
}









