package com.hvisions.eam.dto.maintain;

/**
 * <p>Title: TaskSummaryDTO</p>
 * <p>Description: 任务数量汇总</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/9/27</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TaskSummaryDTO {
    private String definitionKey;
    private Integer finishedCount;
    private Integer totalCount;
}









