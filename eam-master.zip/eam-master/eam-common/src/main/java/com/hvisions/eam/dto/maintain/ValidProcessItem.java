package com.hvisions.eam.dto.maintain;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * <p>Title: ValidProcessItem</p>
 * <p>Description: 审批流中的数据</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/12/7</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Getter
@Setter
@ToString
@ApiModel(description = "验证流程中的对象")
public class ValidProcessItem {
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    Integer equipmentId;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    String equipmentName;
    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码")
    String equipmentCode;
    /**
     * 设备类型名称
     */
    @ApiModelProperty(value = "设备类型名称")
    String equipmentTypeName;
    /**
     * 保养项目
     */
    @ApiModelProperty(value = "保养项目")
    List<MaintainItemDTO> items;
}









