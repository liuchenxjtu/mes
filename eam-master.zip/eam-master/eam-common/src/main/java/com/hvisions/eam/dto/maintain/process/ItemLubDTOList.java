package com.hvisions.eam.dto.maintain.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * <p>Title: ItemLubDTOList</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/10/14</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Getter
@Setter
@ToString
public class ItemLubDTOList {

    private int id;
    private String createTime;
    private String updateTime;
    private String creatorId;
    private String updaterId;
    private String siteNum;
    private int maintainItemId;
    private int lubId;
    private String lubName;
    private int lubNum;
    private String lubCode;
    private String lubUnit;
    private String lubSupplier;
}









