/**
  * Copyright 2020 bejson.com 
  */
package com.hvisions.eam.dto.maintain.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Auto-generated: 2020-10-14 14:23:48
 *
 * @author leiming
 */
@Getter
@Setter
@ToString
public class ItemSparePartDTOList {
    private int maintainItemId;
    private int sparePartId;
    private String sparePartName;
    private int sparePartNum;
    private String sparePartCode;
    private String sparePartUnit;
    private String sparePartSupplier;
}