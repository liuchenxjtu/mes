/**
  * Copyright 2020 bejson.com 
  */
package com.hvisions.eam.dto.maintain.process;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Auto-generated: 2020-10-14 14:23:48
 *
 * @author leiming
 */
@Getter
@Setter
@ToString
public class MaintainContentDTO {
    private int equipmentTypeId;
    private String maintainContentCode;
    private String maintainContentName;
    private boolean startUsing;
    private List<String> maintainItemIdList;
    private List<MaintainItemDTOList> maintainItemDTOList;
    private String remark;
    private String flag;
    private String manHourString;
    private boolean shutDown;
}