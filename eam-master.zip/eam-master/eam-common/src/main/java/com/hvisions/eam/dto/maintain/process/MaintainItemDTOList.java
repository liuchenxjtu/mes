/**
  * Copyright 2020 bejson.com 
  */
package com.hvisions.eam.dto.maintain.process;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.List;

/**
 * Auto-generated: 2020-10-14 14:23:48
 *
 * @author leiming
 */
@Getter
@Setter
@ToString
public class MaintainItemDTOList {
    private int id;
    private Date createTime;
    private Date updateTime;
    private String creatorId;
    private String updaterId;
    private String siteNum;
    private String maintainItemName;
    private String maintainItemCode;
    private int equipmentTypeId;
    private String maintainPosition;
    private String maintainWork;
    private boolean shutDown;
    private boolean startUsing;
    private int manHour;
    private List<String> fileIds;
    private List<ItemSparePartDTOList> itemSparePartDTOList;
    private List<ItemLubDTOList> itemLubDTOList;
    private String remark;
    private String done;
    private String manHourString;
}