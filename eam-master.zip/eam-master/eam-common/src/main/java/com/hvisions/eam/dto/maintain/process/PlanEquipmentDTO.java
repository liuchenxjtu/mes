package com.hvisions.eam.dto.maintain.process;

import lombok.Data;

/**
 * <p>Title: PlanEquipmentDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2022/3/11</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class PlanEquipmentDTO {

    private Integer planId;

    private Integer equipmentId;

    private String equipmentName;

}