/**
 * Copyright 2020 bejson.com
 */
package com.hvisions.eam.dto.maintain.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * Auto-generated: 2020-10-14 14:23:48
 *
 * @author leiming
 */
@Setter
@Getter
@ToString
public class ProcessInstanceVariables {

    private String equipmentCode;
    private String line;
    private String lineId;
    private String remark;
    private int equipmentId;
    private String equipmentName;
    private String lubApplyState;
    private String taskNum;
    private String hvisionsTaskState;
    private String sparePartApplyState;
    private String factory;
    private String manHour;
    private MaintainContentDTO maintainContentDTO;
    private boolean shutDown;
    private String workShop;
    private String businessKey;
    private int checkerId;
    private String checkerName;
    private String taskName;
    private int executor_id;
    private Date taskEndTime;

}