package com.hvisions.eam.dto.publicstore;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 * <p>Title:ActualUseDTO</p>
 * <p>Description:备件实际使用</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/20</p>
 *
 * @author :yu
 * @version : 1.0.0 li's
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = " 备件实际使用 ")
public class ActualUseDTO extends SysBaseDTO {

    public ActualUseDTO() {

    }

    public ActualUseDTO(Integer spareId, Integer shelveId, String batchNumber, BigDecimal applyNumber, String processInstanceId, String identifierKey) {
        this.spareId = spareId;
        this.shelveId = shelveId;
        this.batchNumber = batchNumber;
        this.applyNumber = applyNumber;
        this.processInstanceId = processInstanceId;
        this.identifierKey = identifierKey;
    }
    // -------= 备件信息 =--------
    /**
     * 备件ID
     */
    @ApiModelProperty(value = " 备件ID ")
    Integer spareId;

    /**
     * 批次号
     */
    @ApiModelProperty(value = " 批次号 ")
    String batchNumber;

    /**
     * 库房号
     */
    @ApiModelProperty(value = " 库房号 ")
    Integer shelveId;

    /**
     * 数量
     */
    @ApiModelProperty(value = " 数量 ")
    BigDecimal number;

    /**
     * 数量
     */
    @ApiModelProperty(value = " 申请数量 ")
    BigDecimal applyNumber;

    /**
     * 类型 1备件 2油品
     */
    @ApiModelProperty(value = " 类型 1备件 2油品 ")
    Integer type;

    // -------= 关系 =-----------
    /**
     * 流程实例Id
     */
    @ApiModelProperty(value = " 流程实例Id ")
    String processInstanceId;

    /**
     * 标识符 用于与部位向关联
     */
    @ApiModelProperty(value = " 标识符 用于与部位向关联 ")
    String identifierKey;

    /**
     * 出库表id
     */
    @ApiModelProperty(value = " 出库表id ")
    Integer headerId;

    // ------------------------------- 备件相关信息 -----------------------------
    /**
     * 图片
     */
    @ApiModelProperty(value = " 图片 ")
    private Integer img;

    /**
     * 备件名称
     */
    @ApiModelProperty(value = " 备件名称 ")
    String spareName;

    /**
     * 价格
     */
    @ApiModelProperty(value = " 价格 ")
    BigDecimal unitPrice;

    /**
     * 库房名称
     */
    @ApiModelProperty(value = " 库房名称 ")
    String shelveName;

    @ApiModelProperty(value = "单位")
    UnitDTO unitDTO;

}
