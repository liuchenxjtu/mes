package com.hvisions.eam.dto.publicstore;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.dto.spare.SpareItemDTO;
import com.hvisions.eam.enums.StoreExceptionEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * <p>Title:ApplyDTO</p>
 * <p>Description:申请</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/4/9</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "申请DTO")
public class ApplyDTO extends SysBaseDTO implements IObjectType {

    /**
     * 出入库单号
     */
    @ApiModelProperty(value = "出入库单号 调生成单号接口")
    private String receiptNumber;

    /**
     * 申请人ID
     */
    @ApiModelProperty(value = " 申请人ID 开启任务时申请人必须与当前层级存入值 ")
    private Integer applyUserId;

    /**
     * 申请人名称  1
     */
    @ApiModelProperty(value = " 申请人名称  ")
    private String applyUserName;

    /**
     * 审批人ID
     */
    @ApiModelProperty(value = " 审批人ID 开启任务时审批人必须与当前层级存入值 ")
    private Integer shelveUserId;

    /**
     * 状态 1 中 2 通过 3 驳回 默认填1 中 （必填）
     */
    @ApiModelProperty(value = " 状态 1 中 (默认) 2 通过 3 驳回 默认填1 中 （必填）")
    private Integer isPass;

    /**
     * 状态
     */
    @ApiModelProperty(value = " 状态 ")
    private String examinationType;

    /**
     * 标题 （必填）
     */
    @ApiModelProperty(value = " 标题 （必填）")
    private String title;

    /**
     * 出入库类型 如 保养出库 润滑出库 维修出库 由用户手动输入 （必填）
     */
    @ApiModelProperty(value = " 出入库类型 如 保养出库 润滑出库 维修出库 由用户手动输入 （必填） ")
    private String accessType;

    /**
     * 判断当前操作为 出/入库 1 入库 2 出库  （必填）
     */
    @ApiModelProperty(value = " 判断当前操作为 出/入库 1 入库 2 出库  （必填） ")
    private Integer inOut;

    /**
     * 备注
     */
    @ApiModelProperty(value = " 备注  ")
    private String remarks;

    /**
     * 申请项集合
     */
    @ApiModelProperty(value = " 申请项集合 ")
    private List<SpareItemDTO> items;
    /**
     * 是否被驳回
     */
    @ApiModelProperty(value = "是否被驳回", notes = "1:驳回，其他：正常", readOnly = true)
    private Integer reject;

    /**
     * 驳回原因
     */
    @ApiModelProperty(value = "驳回原因", readOnly = true)
    private String rejectReason;

    @Override
    public Integer getObjectType() {
        return StoreExceptionEnum.IN_USE.getCode();
    }
}