package com.hvisions.eam.dto.publicstore;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * <p>Title:HeaderDTO</p>
 * <p>Description:头表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/7/31</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "申请DTO")
public class HeaderDTO extends SysBaseDTO {

    /**
     * 单号
     */
    @ApiModelProperty(value = " 单号 ")
    private String receiptNumber;

    /**
     * 标题
     */
    @ApiModelProperty(value = " 标题 ")
    private String title;

    /**
     * 流程id
     */
    @ApiModelProperty(value = " 流程id ")
    private String processInstanceId;

    /**
     * 内容项
     */
    @ApiModelProperty(value = " 行表(内容项) ")
    private List<LineDTO> lineDTOS;

    /**
     * 来源
     */
    @ApiModelProperty(value = "来源", example = "保养,润滑,维修")
    private String source;

    /**
     * 区别备件油品 备件1 油品2
     */
    @ApiModelProperty(value = "区别备件油品", example = "1 备件 2 油品")
    private Integer typeClass;

    /**
     * 是否完成出入库操作
     */
    @ApiModelProperty(value = " 是否完成出入库操作 ")
    private Boolean complete;

    /**
     * 出库/入库 1入库 2出库
     */
    @ApiModelProperty(value = " 出库/入库 1入库 2出库 ")
    private Integer inOut;

    @ApiModelProperty(value = "创建入库申请人")
    private String creatorName;

    /**
     * 是否被驳回
     */
    @ApiModelProperty(value = "是否被驳回", notes = "1:驳回，其他：正常", readOnly = true)
    private Integer reject;

    /**
     * 驳回原因
     */
    @ApiModelProperty(value = "驳回原因", readOnly = true)
    private String rejectReason;
}
