package com.hvisions.eam.dto.publicstore;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * <p>Title:LineDTO</p>
 * <p>Description:行表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/7/31</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "申请DTO")
public class LineDTO extends SysBaseDTO {
    /**
     * 头表id
     */
    @ApiModelProperty(value = " ")
    private Integer headerId;

    /**
     * 备件id
     */
    @ApiModelProperty(value = " ")
    private Integer spareId;

    /**
     * 备件名称
     */
    @ApiModelProperty(value = " 备件名称 ")
    private String spareName;

    /**
     * 库房id
     */
    @ApiModelProperty(value = " 库房id ")
    private Integer shelveId;

    /**
     * 库房名称
     */
    @ApiModelProperty(value = " 库房名称 ")
    private String shelveName;

    /**
     * 数量
     */
    @ApiModelProperty(value = " 数量 ")
    private BigDecimal number;

    /**
     * 批次号
     */
    @ApiModelProperty(value = " 批次号 ")
    private String batchNumber;

    /**
     * 出库入库 1 入库 2 出库
     */
    @ApiModelProperty(value = " 出库入库 1 入库 2 出库 ")
    private Integer inOut;

    /**
     * 是否完成出入库操作
     */
    @ApiModelProperty(value = " 是否完成出入库操作 ")
    private Boolean complete;

    /**
     * 类型名称
     */
    @ApiModelProperty(value = "备件类型名称")
    private String typeName;

    /**
     * 供应商
     */
    @ApiModelProperty(value = "供应商")
    private String supplier;

    /**
     * 品牌
     */
    @ApiModelProperty(value = "品牌")
    private String brand;
    /**
     * 规格
     */
    @ApiModelProperty(value = "规格")
    private String specifications;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        LineDTO lineDTO = (LineDTO) o;
        return Objects.equals(headerId, lineDTO.headerId) &&
                Objects.equals(spareId, lineDTO.spareId) &&
                Objects.equals(shelveId, lineDTO.shelveId) &&
                Objects.equals(batchNumber, lineDTO.batchNumber) &&
                Objects.equals(inOut, lineDTO.inOut) &&
                Objects.equals(complete, lineDTO.complete);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), headerId, spareId, shelveId, batchNumber, inOut, complete);
    }
}
