package com.hvisions.eam.dto.publicstore;

import com.hvisions.common.exception.BaseKnownException;
import com.hvisions.eam.enums.StoreExceptionEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title:MatchingDTO</p>
 * <p>Description:匹配规则</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/21</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
@ApiModel(description = " 匹配规则DTO ")
public class MatchingDTO {

    /**
     * 匹配类型 1.位置匹配
     */
    public static final String LOCATION = "1";

    /**
     * 匹配类型 2.正则匹配
     */
    public static final String REG_EX = "2";

    /**
     * id
     */
    @ApiModelProperty(value = " id ")
    public Integer id;

    /**
     * 索引开始位置
     */
    @ApiModelProperty(value = " 开始位置 ")
    public Integer start;

    /**
     * 索引结束位置
     */
    @ApiModelProperty(value = " 结束位置 ")
    public Integer end;

    /**
     * 正则表达式
     */
    @ApiModelProperty(value = " 正则表达式 ")
    public String regEx;

    /**
     * 服务名
     */
    @ApiModelProperty(value = " 服务名 ")
    public String service;

    /**
     * 匹配方式 1.位置匹配  2.正则匹配  默认为1.位置匹配
     */
    @ApiModelProperty(value = " 匹配方式 1.位置匹配  2.正则匹配 ", example = "1")
    public Integer type;


    /**
     * DTO内部验证 位置
     */
    public void validationTypeLocation() {
        validation();
        //数据验证 开始 大于 1 结束 大于 开始
        if (this.getStart() < 1 || this.getEnd() < this.getStart()) {
            throw new BaseKnownException(StoreExceptionEnum.DATE_ERROR_EXCEPTION);
        }
        if (this.regEx == null) {
            this.regEx = "";
        }

    }

    /**
     * DTO内部验证 正则
     */
    public void validationTypeRegEx() {
        validation();
        final String regex = ".*?<code>.*";
        //------------- 正则表单式验证 -------------
        if (this.getRegEx() == null) {
            throw new BaseKnownException(StoreExceptionEnum.REG_EX_EXCEPTION);
        }
        if (!this.getRegEx().matches(regex)) {
            throw new BaseKnownException(StoreExceptionEnum.REG_EX_EXCEPTION);
        }
        //------------- 正则表单式验证 -------------
        if (this.start == null) {
            this.start = 0;
        }
        if (this.end == null) {
            this.end = this.start + 1;
        }
    }

    /**
     * DTO内部验证
     */
    private void validation() {
        //如果传入的类型不存在 则给默认值
        if (!(LOCATION.equals(this.getType() + "") || REG_EX.equals(this.getType() + ""))) {
            this.setType(1);
        }
    }
}
