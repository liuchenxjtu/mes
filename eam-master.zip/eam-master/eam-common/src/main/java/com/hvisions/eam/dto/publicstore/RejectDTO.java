package com.hvisions.eam.dto.publicstore;

/**
 * <p>Title: RejectDTO</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/9/16</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RejectDTO {
    /**
    *   入库单id
    */
    @ApiModelProperty(value = "入库单id")
    private Integer headerId;
    /**
    *   驳回原因
    */
    @ApiModelProperty(value = "驳回原因")
    private String reason;
}









