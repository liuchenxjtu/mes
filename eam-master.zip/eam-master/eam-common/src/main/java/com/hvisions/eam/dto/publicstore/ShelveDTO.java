package com.hvisions.eam.dto.publicstore;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.StoreExceptionEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>Title:ShelveDTO</p>
 * <p>Description:库房DTO</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/19</p>
 *
 * @author :yu
 * @version :  1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = " 库房DTO ")
public class ShelveDTO extends SysBaseDTO implements IObjectType {

    /**
     * id
     */
    @ApiModelProperty(value = " id ")
    private Integer id;

    /**
     * 库房编码
     */
    @ApiModelProperty(value = " 库房编码 (必填)")
    private String shelveCode;

    /**
     * 库房名称
     */
    @ApiModelProperty(value = " 库房名称 ")
    private String shelveName;

    /**
     * 库房地点
     */
    @ApiModelProperty(value = " 库房地点 ")
    private String shelvePlace;

    /**
     * 库房人员ID
     */
    @ApiModelProperty(value = " 库房人员ID ")
    private Integer shelveUserId;

    //----------------- 人员 ------------------------------
    /**
     * 库房人员姓名
     */
    @ApiModelProperty(value = " 库房人员姓名 ")
    private String shelveUserName;

    @Override
    public Integer getObjectType() {
        return StoreExceptionEnum.IN_USE.getCode();
    }
}