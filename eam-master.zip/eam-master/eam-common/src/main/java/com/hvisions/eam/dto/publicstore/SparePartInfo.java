package com.hvisions.eam.dto.publicstore;

/**
 * <p>Title: SparePartInfo</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2022/5/16</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@ToString
public class SparePartInfo {
    /**
     * 备件主键
     */
    @ApiModelProperty(value = "备件主键")
    private Integer sparePartId;
    /**
     * 备件编码
     */
    @ApiModelProperty(value = "备件编码")
    private String sparePartCode;
    /**
     * 备件名称
     */
    @ApiModelProperty(value = "备件名称")
    private String sparePartName;
    /**
     * 备件单价
     */
    @ApiModelProperty(value = "备件单价")
    private BigDecimal sparePartPrice;
    /**
     * 备件单位
     */
    @ApiModelProperty(value = "备件单位")
    private String sparePartUnit;
    /**
     * 备件个数
     */
    @ApiModelProperty(value = "备件个数")
    private BigDecimal count;
    /**
    *   使用时间
    */
    @ApiModelProperty(value = "使用时间")
    private Date createTime;

    /**
     * 备件总价
     */
    @ApiModelProperty(value = "备件总价")
    public BigDecimal getTotal() {
        return sparePartPrice.multiply(count);
    }
}









