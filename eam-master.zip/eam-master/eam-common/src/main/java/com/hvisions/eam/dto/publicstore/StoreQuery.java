package com.hvisions.eam.dto.publicstore;

/**
 * <p>Title: StoreQuery</p>
 * <p>Description: 库存查询对象</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/3/1</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class StoreQuery {
    /**
     * 流程实例id
     */
    @ApiModelProperty(value = "流程实例id")
    private String processInstanceId;
    /**
     * 是否结束
     */
    @ApiModelProperty(value = "是否结束")
    private Boolean isComplete;
    /**
     * 类型，1：备件，2：油品
     */
    @ApiModelProperty(value = "类型，1：备件，2：油品")
    private Integer type;
    /**
     * 出库还是入库
     */
    @ApiModelProperty(value = "出库还是入库")
    private Integer inOrOut;
}









