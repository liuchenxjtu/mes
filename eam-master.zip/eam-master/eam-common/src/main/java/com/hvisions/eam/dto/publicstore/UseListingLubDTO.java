package com.hvisions.eam.dto.publicstore;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title:UseListingSpareDTO</p>
 * <p>Description:油品使用清单</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
@ApiModel(description = " 油品使用清单 ")
public class UseListingLubDTO {

    /**
     * id
     */
    @ApiModelProperty(value = " id ")
    Integer id;
    /**
     * 备件ID
     */
    @ApiModelProperty(value = " 油品ID ")
    @JsonProperty("lubId")
    Integer spareId;

    /**
     * 使用数量
     */
    @ApiModelProperty(value = " 实际使用数量 ")
    BigDecimal number;

    /**
     * 类型 1备件 2油品
     */
    @ApiModelProperty(value = " 类型 1备件 2油品 ")
    Integer type;

    //------------------------ 前段展示用字段 ----------------------------------------
    /**
     * 油品名称
     */
    @ApiModelProperty(value = " 油品名称  ")
    String lubName;

    /**
     * 油品cod编码
     */
    @ApiModelProperty(value = " 油品cod编码 ")
    String lubCode;

    /**
     * 油品类型
     */
    @ApiModelProperty(value = " 油品类型  ")
    String lubTypeName;

    /**
     * processInstanceId
     */
    @ApiModelProperty(value = " processInstanceId ")
    String processInstanceId;

}
