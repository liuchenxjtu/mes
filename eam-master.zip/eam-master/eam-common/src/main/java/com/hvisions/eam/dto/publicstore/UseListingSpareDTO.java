package com.hvisions.eam.dto.publicstore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title:UseListingSpareDTO</p>
 * <p>Description:备件使用清单</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
@ApiModel(description = " 备件使用清单 ")
public class UseListingSpareDTO {

    /**
     * id
     */
    @ApiModelProperty(value = " id  ")
    Integer id;
    /**
     * 备件ID
     */
    @ApiModelProperty(value = " 备件ID ")
    Integer spareId;

    /**
     * 备件ID
     */
    @ApiModelProperty(value = " 备件ID ")
    Integer lubId;

    /**
     * 使用数量
     */
    @ApiModelProperty(value = " 实际使用数量 ")
    BigDecimal number;

    /**
     * 类型 1备件 2油品
     */
    @ApiModelProperty(value = " 类型 1备件 2油品 ")
    Integer type;

    //----------------------- 前段展示用字段 -----------------------------------------

    /**
     * 备件名称
     */
    @ApiModelProperty(value = " 备件名称  ")
    String spareName;


    /**
     * 备件cod编码
     */
    @ApiModelProperty(value = " 备件cod编码 ")
    String spareCode;


    /**
     * 备件类型
     */
    @ApiModelProperty(value = " 备件类型  ")
    String spareTypeName;

    /**
     * processInstanceId
     */
    @ApiModelProperty(value = " processInstanceId ")
    String processInstanceId;

}
