/**
 * Copyright 2020 json.cn
 */
package com.hvisions.eam.dto.repair.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Auto-generated: 2020-11-06 8:51:23
 *
 * @author json.cn (i@json.cn)
 */
@Setter
@Getter
@ToString
public class ProcessInstanceVariables {
    private String equipmentCode;
    private String warrantyPhone;
    private Integer equipmentId;
    private Integer applyUserId;
    private String failureLevel;
    private String faultClassApplyName;
    private String describeAssignee;
    private String faultAssigneeName;
    private String equipmentName;
    private String faultClassAssigneeName;
    private String state;
    private String receiptNumber;
    private String hvisionsTaskState;
    private String faultSolutionAssigneeName;
    private String describeApply;
    private Integer faultAssigneeId;
    private Integer faultReasonAssigneeId;
    private String equipmentPlace;
    private String applyUserName;
    private String faultReasonAssigneeName;
    private String faultApplyName;
    private Integer faultSolutionAssigneeId;
    private Integer faultApplyId;
    private Float faultDiagnosisTime;
    private Float waitSparePartTime;
    private Float repairReplaceTime;
    private Float startupTime;
    private Float shutdownTime;
    private List<Integer> userMessage;
}