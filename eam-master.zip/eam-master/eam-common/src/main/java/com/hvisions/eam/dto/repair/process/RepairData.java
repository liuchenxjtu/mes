/**
  * Copyright 2020 json.cn 
  */
package com.hvisions.eam.dto.repair.process;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Auto-generated: 2020-11-06 8:51:23
 *
 * @author json.cn (i@json.cn)
 */
@Setter
@Getter
@ToString
public class RepairData {
    private Data data;
    private Integer code;
    private String message;
}