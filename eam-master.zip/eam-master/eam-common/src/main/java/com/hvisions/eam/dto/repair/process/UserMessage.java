package com.hvisions.eam.dto.repair.process;

import lombok.Data;

/**
 * <p>Title: UserMessage</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/11/11</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class UserMessage {
    private Integer userId;
    private String userName;
}