package com.hvisions.eam.dto.repair.spare;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title: EquipmentFailureDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/4</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class EquipmentFailureDTO {

    /**
     * 设备编码
     */
    private Integer equipmentId;

    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;

    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;

    /**
     * 计划生产时间
     */
    @ApiModelProperty(value = "计划生产时间")
    private BigDecimal planWorkTime;

    /**
     * 故障时间
     */
    @ApiModelProperty(value = "故障时间")
    private BigDecimal failureTime;

    /**
     * 单机故障率
     */
    @ApiModelProperty(value = "单机故障率")
    private BigDecimal singleFailureRate;


    /**
     * 故障次数
     */
    @ApiModelProperty(value = "故障次数")
    private BigDecimal failureNum;

    /**
     * MTBF
     */
    @ApiModelProperty(value = "MTBF")
    private BigDecimal MTBF;

    /**
     * MTTR
     */
    @ApiModelProperty(value = "MTTR")
    private BigDecimal MTTR;

    /**
     * 停线时间
     */
    @ApiModelProperty(value = "停线时间")
    private BigDecimal stopCellTime;

    /**
     * 累计停线时间
     */
    @ApiModelProperty(value = "累计停线时间")
    private BigDecimal addUpStopCellTime;

    /**
     * 累计生产时间
     */
    @ApiModelProperty(value = "累计生产时间")
    private BigDecimal addUpWorkTime = new BigDecimal(240);
    /**
     * 停线率
     */
    @ApiModelProperty(value = "停线率")
    private BigDecimal stopCellRate;


    public BigDecimal getSingleFailureRate() {
        if (planWorkTime == null) {
            return new BigDecimal(0);
        }
        if (failureTime == null) {
            return new BigDecimal(0);
        }
        if (planWorkTime.compareTo(BigDecimal.ZERO) == 0) {
            return new BigDecimal(0);
        }
        return failureTime.divide(planWorkTime, 4);
    }

    public BigDecimal getMTBF() {
        if (failureNum != null) {
            if (failureNum.compareTo(BigDecimal.ZERO) == 1) {
                if (planWorkTime != null) {
                    BigDecimal divide = planWorkTime.divide(failureNum, 4);
                    return divide.divide(new BigDecimal(60), 4);
                }
            }
        }
        return new BigDecimal(0);
    }

    public BigDecimal getMTTR() {
        if (failureNum != null) {
            if (failureNum.compareTo(BigDecimal.ZERO) == 1) {
                if (failureTime != null) {
                    BigDecimal divide = failureTime.divide(failureNum, 4);
                    return divide.divide(new BigDecimal(60), 4);

                }
            }
        }
        return new BigDecimal(0);
    }

    public BigDecimal getStopCellRate() {
        if (planWorkTime != null) {
            if (planWorkTime.compareTo(BigDecimal.ZERO) == 1) {
                if (stopCellTime != null) {
                    return stopCellTime.divide(planWorkTime, 4);
                }
            }
        }
        return new BigDecimal(0);
    }

}