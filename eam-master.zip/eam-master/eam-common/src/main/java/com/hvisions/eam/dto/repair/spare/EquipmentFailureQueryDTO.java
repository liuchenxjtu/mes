package com.hvisions.eam.dto.repair.spare;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: EquipmentFailureQueryDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/4</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class EquipmentFailureQueryDTO {

    /**
     * 开始使用时间
     */
    @ApiModelProperty(value = "开始使用时间")
    private Date startTime;
    /**
     * 结束使用时间
     */
    @ApiModelProperty(value = "结束使用时间")
    private Date endTime;

    @ApiModelProperty(value = "产线")
    private Integer cellId;
}