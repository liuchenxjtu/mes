package com.hvisions.eam.dto.repair.spare;

import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title: FaultTimeDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/7</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class FaultTimeDTO {
    /**
     *
     */
    private Integer equipmentId;

    private String equipmentCode;

    private String equipmentName;

    private BigDecimal stopCellTime;

    private BigDecimal failureTime;
}