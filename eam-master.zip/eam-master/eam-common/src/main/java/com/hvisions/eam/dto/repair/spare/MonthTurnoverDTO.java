package com.hvisions.eam.dto.repair.spare;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title: TurnoverDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/4</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
@ApiModel(description = "月周转率")
public class MonthTurnoverDTO {

    /**
     * 备件编码
     */
    @ApiModelProperty(value = "备件编码")
    private String sparePartCode;

    /**
     * 备件名称
     */
    @ApiModelProperty(value = "备件名称")
    private String sparePartName;

    /**
     * 消耗量
     */
    @ApiModelProperty(value = "消耗量")
    private BigDecimal sparePartUsage = new BigDecimal(0);

    /**
     * 单价(元)
     */
    @ApiModelProperty(value = "单价(元)")
    private BigDecimal unitPrice;

    /**
     * 总价
     */
    @ApiModelProperty(value = "总价")
    private BigDecimal totalPrice;

    public BigDecimal getTotalPrice() {
        if (unitPrice != null && sparePartUsage != null) {
            return sparePartUsage.multiply(unitPrice);
        }
        return new BigDecimal(0);
    }


    /**
     * 上月月底库存
     */
    @ApiModelProperty(value = "上月月底库存")
    private BigDecimal lastMonthStock;

    /**
     * 当月月底库存
     */
    @ApiModelProperty(value = "当月月底库存")
    private BigDecimal monthStock;

    /**
     * 周转率
     */
    @ApiModelProperty(value = "周转率")
    private BigDecimal turnoverNum;

    /**
     * 月份
     */
    private Integer monthTime;

    /**
     * 上年年底库存
     */
    private BigDecimal lastYearStock = new BigDecimal(0);

    /**
     * 往月月底库存总和
     */
    private BigDecimal lastMothStockSum = new BigDecimal(0);

    //
    private BigDecimal lastSparePartUsage;


    public BigDecimal getTurnoverNum() {
        //年底库存加当月库存
        BigDecimal add = lastYearStock.add(monthStock);
        //除以2
        BigDecimal divide = add.divide(new BigDecimal(2), 4);
        //➕上月末库存
        BigDecimal add1 = divide.add(lastMothStockSum);

        //今年出库
        BigDecimal add2 = lastSparePartUsage.add(sparePartUsage);
        if (add2.compareTo(BigDecimal.ZERO) == 0) {
            return new BigDecimal(0);
        }
        BigDecimal divide1 = add2.divide(add1,4);

        return divide1.multiply(new BigDecimal(12)).setScale(2,BigDecimal.ROUND_HALF_UP);
    }
}