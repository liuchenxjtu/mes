package com.hvisions.eam.dto.repair.spare;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title: SparePartUsageDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/4</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
@ApiModel(description = "备件使用统计")
public class SparePartUsageDTO {

    /**
     * 产线名称
     */
    @ApiModelProperty(value = "产线名称")
    private String cellName;

    /**
     * 备件使用费用
     */
    @ApiModelProperty(value = "备件使用费用")
    private BigDecimal sparePartNum;
    /**
     * 备件使用数量
     */
    @ApiModelProperty(value = "备件使用数量")
    private BigDecimal spareQuantity;

}