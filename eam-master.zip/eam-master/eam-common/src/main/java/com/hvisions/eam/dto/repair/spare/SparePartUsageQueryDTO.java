package com.hvisions.eam.dto.repair.spare;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: SparePartUsageQueryDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/4</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
@ApiModel(description = "备件使用统计查询条件")
public class SparePartUsageQueryDTO {


    /**
     * 备件型号
     */
    @ApiModelProperty(value = "备件型号")
    private Integer sparePartModel;

    /**
     * 备件类型
     */
    @ApiModelProperty(value = "备件类型")
    private Integer sparePartType;
    /**
     * 备件品牌
     */
    @ApiModelProperty(value = "备件品牌")
    private String sparePartBrand;

    /**
     * 使用人员
     */
    @ApiModelProperty(value = "使用人员")
    private Integer userId;

    /**
     * 班组
     */
    @ApiModelProperty(value = "班组")
    private Integer crewId;
    /**
     * 车间
     */
    @ApiModelProperty(value = "车间")
    private Integer areaId;
    /**
     * 产线
     */
    @ApiModelProperty(value = "产线")
    private Integer cellId;
    /**
     * 开始使用时间 流程实际结束时间
     */
    @ApiModelProperty(value = "开始使用时间")
    private Date startTime;
    /**
     * 结束使用时间
     */
    @ApiModelProperty(value = "结束使用时间")
    private Date endTime;

    /**
     * 供应商
     */
    @ApiModelProperty(value = "供应商")
    private String supplier;

}