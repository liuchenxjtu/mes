package com.hvisions.eam.dto.repair.spare;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: YearTurnoverDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/4</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
@ApiModel(description = "年周转率")
public class YearTurnoverDTO {
    /**
     * 备件编码
     */
    @ApiModelProperty(value = "备件编码")
    private String sparePartCode;

    /**
     * 备件名称
     */
    @ApiModelProperty(value = "备件名称")
    private String sparePartName;

    /**
     * 消耗量
     */
    @ApiModelProperty(value = "消耗量")
    private Integer sparePartUsage;

    /**
     * 单价(元)
     */
    @ApiModelProperty(value = "单价(元)")
    private String unitPrice;

    /**
     * 总价
     */
    @ApiModelProperty(value = "总价")
    private String totalPrice;

    /**
     * 上月月底库存
     */
    @ApiModelProperty(value = "上年底库存")
    private String lastYearStock;

    /**
     * 当月月底库存
     */
    @ApiModelProperty(value = "当年库存")
    private String yearStock;

    /**
     * 周转率
     */
    @ApiModelProperty(value = "周转率")
    private String turnoverNum;
}