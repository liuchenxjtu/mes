package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class EquipmentFaultInfo {
    /**
     * 产线
     */
    @ApiModelProperty(value = "产线")
    private String productionLine;
    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 维修耗时
     */
    @ApiModelProperty(value = "维修耗时")
    private BigDecimal faultTime;
    /**
     * 故障
     */
    @ApiModelProperty(value = "故障")
    private String fault;
}
