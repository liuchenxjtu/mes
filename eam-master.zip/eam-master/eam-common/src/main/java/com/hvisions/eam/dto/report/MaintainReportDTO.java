package com.hvisions.eam.dto.report;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: MaintainReportDTO</p >
 * <p>Description: 设备维修</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/7/30</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class MaintainReportDTO extends SysBaseDTO {


    /**
     * 生产线
     */
    @ApiModelProperty(value = "生产线")
    private String cellCode;

    /**
     * 工序号
     */
    @ApiModelProperty(value = "工序号")
    private String operationCode;

    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;

    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;

    /**
     * 日期
     */
    @ApiModelProperty(value = "日期")
    private Date orderTime;

    /**
     * 故障分类
     */
    @ApiModelProperty(value = "故障分类")
    private String faultType;

    /**
     * 故障描述
     */
    @ApiModelProperty(value = "故障描述")
    private String faultDesc;

    /**
     * 检修过程
     */
    @ApiModelProperty(value = "检修过程")
    private String maintainProcess;


    /**
     * 原因分析
     */
    @ApiModelProperty(value = "原因分析")
    private String causeAnalysis;


    /**
     * 预防措施
     */
    @ApiModelProperty(value = "预防措施")
    private String precaution;

    /**
     * 报修时间
     */
    @ApiModelProperty(value = "报修时间")
    private Date repairTime;

    /**
     * 开始检修时间
     */
    @ApiModelProperty(value = "开始检修时间")
    private Date startFaultTime;


    /**
     * 检修完工时间
     */
    @ApiModelProperty(value = "检修完工时间")
    private Date endFaultTime;


    /**
     * 累计检修时间
     */
    @ApiModelProperty(value = "累计检修时间")
    private Integer sumFaultTime;


    /**
     * 累计停线时间
     */
    @ApiModelProperty(value = "累计停线时间")
    private Integer lineStopTime;


    /**
     * 恢复生产时间
     */
    @ApiModelProperty(value = "恢复生产时间")
    private Integer workTime;

    /**
     * 维修人员
     */
    @ApiModelProperty(value = "维修人员")
    private String userName;
}