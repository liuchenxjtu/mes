package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class RepairUserJobInfo {
    /**
     * 员工姓名
     */
    @ApiModelProperty(value = "员工姓名")
    private String userName;
    /**
     * 类型
     */
    @ApiModelProperty(value = "类型")
    private Integer type;
    /**
     * 总维修时间
     */
    @ApiModelProperty(value = "总维修时间")
    private BigDecimal sumRepairTime;
    /**
     * 维修次数
     */
    @ApiModelProperty(value = "维修次数")
    private Integer repairCount;
    /**
     * 平均维修时间
     */
    @ApiModelProperty(value = "平均维修时间")
    private BigDecimal avgRepairTime;
    /**
     * 总维保时间
     */
    @ApiModelProperty(value = "总维保时间")
    private BigDecimal sumMaintainTime;
    /**
     * 维保次数
     */
    @ApiModelProperty(value = "维保次数")
    private Integer maintainCount;
    /**
     * 平均维保时间
     */
    @ApiModelProperty(value = "平均维保时间")
    private BigDecimal avgMaintainTime;
    /**
     * 备件使用金额
     */
    @ApiModelProperty(value = "备件使用金额")
    private BigDecimal sparePartUseAmount;
}
