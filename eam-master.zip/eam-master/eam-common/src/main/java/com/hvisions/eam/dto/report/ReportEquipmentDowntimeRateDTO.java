package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * <p>Title: ReportEquipmentDowntimeRateDTO</p>
 * <p>Description: 设备停机率折线图的明细</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/4</p>
 *
 * @author :fengfeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@ApiModel(description = "设备停机率折线图的明细")
public class ReportEquipmentDowntimeRateDTO {
    /**
     * 星期几
     */
    @ApiModelProperty(value = "星期几")
    private Integer days;
    /**
     * 故障时间
     */
    @ApiModelProperty(value = "故障时间")
    private BigDecimal faultTime;
    /**
     * 计划生产时间
     */
    @ApiModelProperty(value = "计划生产时间")
    private BigDecimal plannedProductionTime;
    /**
     * 实际故障率
     */
    @ApiModelProperty(value = "实际故障率")
    public BigDecimal getActualFaultRate(){
        return faultTime.multiply(new BigDecimal(100)).divide(plannedProductionTime,2,BigDecimal.ROUND_HALF_UP);
    }
    /**
     * 周平均故障率
     */
    @ApiModelProperty(value = "周平均故障率")
    private BigDecimal averageWeeklyFaultRate;
}
