package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * <p>Title: ReportEquipmentDowntimeRateQuery</p>
 * <p>Description: 设备停机率折线图的查询</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/4</p>
 *
 * @author :fengfeng
 * @version :1.0.0
 */
@Getter
@Setter
@ToString
public class ReportEquipmentDowntimeRateQuery {
    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    private Date startTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private Date endTime;
}
