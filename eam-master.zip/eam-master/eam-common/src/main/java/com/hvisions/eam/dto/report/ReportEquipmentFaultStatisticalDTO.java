package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * <p>Title: ReportEquipmentFaultStatisticalDTO</p>
 * <p>Description: 设备故障统计表的明细</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/4</p>
 *
 * @author :fengfeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@ApiModel(description = "设备故障统计表的明细")
public class ReportEquipmentFaultStatisticalDTO {
    /**
     * 产线
     */
    @ApiModelProperty(value = "产线")
    private String productionLine;
    /**
     * 设备编码
     */
    @ApiModelProperty(value = "设备编码")
    private String equipmentCode;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 维修耗时
     */
    @ApiModelProperty(value = "维修耗时")
    private BigDecimal repairTime;
    /**
     * 占全线耗时比例
     */
    @ApiModelProperty(value = "占全线耗时比例")
    private BigDecimal proportionOfTotalTime;
    /**
     * 主要故障
     */
    @ApiModelProperty(value = "主要故障")
    private String mainFault;
    /**
     * 主要故障停机时间
     */
    @ApiModelProperty(value = "主要故障停机时间")
    private BigDecimal downTimeOfMainFault;
    /**
     * 主要故障所占比例
     */
    @ApiModelProperty(value = "主要故障时间占比")
    private BigDecimal proportionOfMainFaultTime;
}
