package com.hvisions.eam.dto.report;

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>Title: ReportQuery</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/7/31</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class ReportQuery extends PageInfo {

    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;

    /**
     * 设备工位号
     */
    @ApiModelProperty(value = "设备工位号")
    private String equipmentCode;

    /**
     * 生产线
     */
    @ApiModelProperty(value = "生产线")
    private String cellCode;

    /**
     * 工序号
     */
    @ApiModelProperty(value = "工序号")
    private String operationCode;

    /**
     * 区域
     */
    @ApiModelProperty(value = "区域")
    private String areaCode;

    @ApiModelProperty(value = "日期开始时间")
    private Date dateStart;

    @ApiModelProperty(value = "日期结束时间")
    private Date dateEnd;
}