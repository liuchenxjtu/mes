package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * <p>Title: ReportRepairUserJobStatisticalDTO</p>
 * <p>Description: 维修人员工作统计的明细</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/4</p>
 *
 * @author :fengfeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@ApiModel(description = "维修人员工作统计的明细")
public class ReportRepairUserJobStatisticalDTO {
    /**
     * 员工姓名
     */
    @ApiModelProperty(value = "员工姓名")
    private String userName;
    /**
     * 总维修时间
     */
    @ApiModelProperty(value = "总维修时间")
    private BigDecimal sumRepairTime;
    /**
     * 维修次数
     */
    @ApiModelProperty(value = "维修次数")
    private Integer repairCount;
    /**
     * 平均维修时间
     */
    @ApiModelProperty(value = "平均维修时间")
    private BigDecimal avgRepairTime;
    /**
     * 总维保时间
     */
    @ApiModelProperty(value = "总维保时间")
    private BigDecimal sumMaintainTime;
    /**
     * 维保次数
     */
    @ApiModelProperty(value = "维保次数")
    private Integer maintainCount;
    /**
     * 平均维保时间
     */
    @ApiModelProperty(value = "平均维保时间")
    private BigDecimal avgMaintainTime;
    /**
     * 备件使用金额
     */
    @ApiModelProperty(value = "备件使用金额")
    private BigDecimal sparePartUseAmount;
}
