package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * <p>Title: ReportUrgentRepairParetoAnalysisDTO</p>
 * <p>Description: 急维修 Pareto 分析的明细</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/4</p>
 *
 * @author :fengfeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@ApiModel(description = "急维修 Pareto 分析的明细")
public class ReportUrgentRepairParetoAnalysisDTO {
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 维修耗时
     */
    @ApiModelProperty(value = "维修耗时")
    private BigDecimal repairTime;
    /**
     * 累计百分比
     */
    @ApiModelProperty(value = "累计百分比")
    private BigDecimal cumulativePercentage;
}
