package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * <p>Title: ReportUrgentRepairParetoAnalysisQuery</p>
 * <p>Description: 急维修 Pareto 分析的查询</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/4</p>
 *
 * @author :fengfeng
 * @version :1.0.0
 */
@Getter
@Setter
@ToString
public class ReportUrgentRepairParetoAnalysisQuery {
    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    private Date startTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private Date endTime;
    /**
     * 产线编码
     */
    @ApiModelProperty(value = "产线编码")
    private Integer cellId;
}
