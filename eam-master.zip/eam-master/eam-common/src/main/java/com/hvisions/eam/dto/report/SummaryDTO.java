package com.hvisions.eam.dto.report;

/**
 * <p>Title: SummaryDTO</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/9/27</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SummaryDTO {
    /**
    *   维修流程完成数量
    */
    @ApiModelProperty(value = "维修流程完成数量")
    private Integer faultFinished;
    /**
    *   维修流程总数
    */
    @ApiModelProperty(value = "维修流程总数")
    private Integer faultTotal;
    /**
    *   保养流程完成数量
    */
    @ApiModelProperty(value = "保养流程完成数量")
    private Integer maintainFinished;
    /**
    *   保养流程总数
    */
    @ApiModelProperty(value = "保养流程总数")
    private Integer maintainTotal;
    /**
    *   点巡检流程完成数量
    */
    @ApiModelProperty(value = "点巡检流程完成数量")
    private Integer inspectFinished;
    /**
    *   点巡检流程总数
    */
    @ApiModelProperty(value = "点巡检流程总数")
    private Integer inspectTotal;
    /**
    *   自主性维护流程完成数量
    */
    @ApiModelProperty(value = "自主性维护流程完成数量")
    private Integer autoFinished;
    /**
    *   自主性维护总数
    */
    @ApiModelProperty(value = "自主性维护总数")
    private Integer autoTotal;

    /**
    *   保养计划数量
    */
    @ApiModelProperty(value = "保养计划数量")
    private Integer maintainPlanCount;
    /**
    *   点巡检计划数量
    */
    @ApiModelProperty(value = "点巡检计划数量")
    private Integer inspectPlanCount;
    /**
    *   自主性维护计划数量
    */
    @ApiModelProperty(value = "自主性维护计划数量")
    private Integer autoPlanCount;
    /**
    *   故障知识库数据
    */
    @ApiModelProperty(value = "故障知识库数据")
    private Integer knowledgeCount;



}









