package com.hvisions.eam.dto.report;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;


@Data
public class UrgentRepairParetoInfo {
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称")
    private String equipmentName;
    /**
     * 维修耗时
     */
    @ApiModelProperty(value = "维修耗时")
    private BigDecimal repairTime;
}
