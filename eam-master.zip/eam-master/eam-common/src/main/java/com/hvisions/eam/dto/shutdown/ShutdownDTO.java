package com.hvisions.eam.dto.shutdown;

/**
 * <p>Title: ShutdownDTO</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/6</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@ToString
public class ShutdownDTO extends SysBaseDTO {
    /**
     * 停机时间
     */
    @ApiModelProperty(value = "停机时间")
    private Date shutdownDate;
    /**
     * 停机持续时间
     */
    @ApiModelProperty(value = "停机持续时间")
    private Integer duration;
    /**
     * 停机原因
     */
    @ApiModelProperty(value = "停机原因")
    private String reason;
    /**
     * 停机类型
     */
    @ApiModelProperty(value = "停机类型")
    private String type;
    /**
     * 停机设备id
     */
    @ApiModelProperty(value = "停机设备id")
    private Integer equipmentId;
    /**
     * 设备名称
     */
    @ApiModelProperty(value = "设备名称", readOnly = true)
    private String equipmentName;
}









