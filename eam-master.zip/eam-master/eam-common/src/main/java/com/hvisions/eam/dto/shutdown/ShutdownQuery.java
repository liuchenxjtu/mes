package com.hvisions.eam.dto.shutdown;

/**
 * <p>Title: ShutdownQuery</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/6</p>
 *
 * @author :leiming
 * @version :1.0.0
 */

import com.hvisions.common.dto.PageInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@ToString
public class ShutdownQuery extends PageInfo {
    /**
     * 设备id
     */
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    private Date beginTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private Date endTime;

    @ApiModelProperty(value = "产线编码")
    private String cellId;
}









