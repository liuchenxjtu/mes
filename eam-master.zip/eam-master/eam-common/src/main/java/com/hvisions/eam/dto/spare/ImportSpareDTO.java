package com.hvisions.eam.dto.spare;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title: ImportSpareDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/12</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class ImportSpareDTO {

    /**
     * 备件编码
     */
    @ApiModelProperty(value = "备件编码 (必填)")
    private String spareCode;

    /**
     * 备件名称
     */
    @ApiModelProperty(value = "备件名称 (必填)")
    private String spareName;

    /**
     * 备件型号ID
     */
    @ApiModelProperty(value = "备件型号ID (必填)")
    private String spareTypeCode;

    /**
     * 单位id
     */
    @ApiModelProperty(value = "备件单位id (必填)")
    private String unitCode;

    /**
     * 单价
     */
    @ApiModelProperty(value = " 单价 ")
    private BigDecimal unitPrice;

    /**
     * 最大库存
     */
    @ApiModelProperty(value = " 最大库存 ")
    private Integer cargoMax = 0;

    /**
     * 最小库存
     */
    @ApiModelProperty(value = " 最小库存 ")
    private Integer cargoMin = 0;

    /**
     * 备注
     */
    @ApiModelProperty(value = " 备注 ")
    private String remarks;

    /**
     * 供应商
     */
    @ApiModelProperty(value = " 供应商 ")
    private String supplier;


    //---------------------------- 备件单位字段 ------------------------
    /**
     * 单位名称
     */
    @ApiModelProperty(value = " 单位名称 ")
    private String unitName;

    /**
     * 单位符号
     */
    @ApiModelProperty(value = " 单位符号 ")
    private String unitSymbol;

    //---------------------------- 备件类型字段 ------------------------
    /**
     * 备件类型名称
     */
    @ApiModelProperty(value = " 备件类型名称 ")
    private String typeName;


    //-----------------------------= 刀具 =--------------------------------
    /**
     * 预期使用数量
     */
    @ApiModelProperty(value = " 预期使用数量 ")
    private Integer expectedNumber;

    /**
     * 报警临界剩余数量
     */
    @ApiModelProperty(value = " 报警临界剩余数量 ")
    private Integer alarmRemainingNumber;


    /**
     * 品牌
     */
    @ApiModelProperty(value = " 品牌 ")
    private String brand;

    /**
     * 规格
     */
    @ApiModelProperty(value = " 规格 ")
    private String specifications;

}