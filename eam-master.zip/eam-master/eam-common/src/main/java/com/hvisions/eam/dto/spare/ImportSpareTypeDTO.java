package com.hvisions.eam.dto.spare;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: ImportSpareTypeDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/12</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class ImportSpareTypeDTO {


    /**
     * 类型编码
     */
    @ApiModelProperty(value = " 类型编码 (必填)")
    private String typeCode;

    /**
     * 类型名称
     */
    @ApiModelProperty(value = " 类型名称 (必填) ")
    private String typeName;

    /**
     * 父级ID
     */
    @ApiModelProperty(value = " 上级类型编码 ")
    private String parentCode;

    /**
     * 是否内置
     */
    @ApiModelProperty(value = " 是否内置 ")
    private Integer isBuiltIn;

    /**
     * 管理类型 是否批量管理 0 默认 统一管理 1 单个管理
     */
    @ApiModelProperty(value = " 管理类型(必填) 是否批量管理 0 默认 统一管理 1 单个管理 ")
    private Integer batchManagementOrNot;


}