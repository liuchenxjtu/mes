package com.hvisions.eam.dto.spare;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title: SpareBrandDTO</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/11</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
public class SpareBrandDTO extends SysBaseDTO {


    /**
     * 备件品牌编码
     */
    @ApiModelProperty(value = "备件品牌编码", required = true)
    private String spareBrandCode;

    /**
     * 备件品牌名称
     */
    @ApiModelProperty(value = "备件品牌名称", required = true)
    private String spareBrandName;
}