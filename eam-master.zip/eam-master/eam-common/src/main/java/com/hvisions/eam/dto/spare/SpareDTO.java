package com.hvisions.eam.dto.spare;

import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.StoreExceptionEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>Title:SpareDTO</p>
 * <p>Description:备件</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/21</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "备件 DTO")
public class SpareDTO extends SysBaseDTO implements IObjectType {
    public SpareDTO() {
        if (this.files == null) {
            this.files = new ArrayList<>();
        }
        if (this.unitPrice == null) {
            this.unitPrice = new BigDecimal(0);
        }
    }

    /**
     * 备件编码
     */
    @ApiModelProperty(value = "备件编码 (必填)")
    private String spareCode;

    /**
     * 备件名称
     */
    @ApiModelProperty(value = "备件名称 (必填)")
    private String spareName;

    /**
     * 备件型号ID
     */
    @ApiModelProperty(value = "备件型号ID (必填)")
    private Integer spareTypeId;

    /**
     * 单位id
     */
    @ApiModelProperty(value = "备件单位id (必填)")
    private Integer unitId;

    /**
     * 单价
     */
    @ApiModelProperty(value = " 单价 ")
    private BigDecimal unitPrice;

    /**
     * 最大库存
     */
    @ApiModelProperty(value = " 最大库存 ")
    private Integer cargoMax = 0;

    /**
     * 最小库存
     */
    @ApiModelProperty(value = " 最小库存 ")
    private Integer cargoMin = 0;

    /**
     * 备注
     */
    @ApiModelProperty(value = " 备注 ")
    private String remarks;

    /**
     * 供应商
     */
    @ApiModelProperty(value = " 供应商 ")
    private String supplier;


    //---------------------------- 备件单位字段 ------------------------
    /**
     * 单位名称
     */
    @ApiModelProperty(value = " 单位名称 ")
    private String unitName;

    /**
     * 单位符号
     */
    @ApiModelProperty(value = " 单位符号 ")
    private String unitSymbol;

    //---------------------------- 备件类型字段 ------------------------
    /**
     * 备件类型名称
     */
    @ApiModelProperty(value = " 备件类型名称 ")
    private String typeName;

    /**
     * 备件ID带层级结构的ID
     */
    @ApiModelProperty(value = " 备件类型ID带层级结构的数组 ")
    private List<Integer> typeIds;

    /**
     * 图片
     */
    @ApiModelProperty(value = " 图片 ")
    private Integer img;


    //-----------------------------= 刀具 =--------------------------------
    /**
     * 预期使用数量
     */
    @ApiModelProperty(value = " 预期使用数量 ")
    private Integer expectedNumber;

    /**
     * 报警临界剩余数量
     */
    @ApiModelProperty(value = " 报警临界剩余数量 ")
    private Integer alarmRemainingNumber;


    /**
     * 品牌
     */
    @ApiModelProperty(value = " 品牌 ")
    private String brand;

    @ApiModelProperty(value = " 品牌编码 ")
    private String brandCode;

    /**
     * 规格
     */
    @ApiModelProperty(value = " 规格 ")
    private String specifications;

    /**
     * 采购工程师
     */
    @ApiModelProperty(value = "采购工程师")
    private Integer purchaseUserId;

    /**
     * 技术工程师
     */
    @ApiModelProperty(value = "技术工程师")
    private Integer skillUserId;

    @ApiModelProperty(value = "采购工程师名称")
    private String skillUserName;

    @ApiModelProperty(value = "技术工程师名称")
    private String purchaseUserName;

    @ApiModelProperty(value = "创建人员名称")
    private String createName;


    /**
     * 订货号
     */
    @ApiModelProperty(value = "订货号")
    private String orderNum;

    /**
     * 机电类别
     */
    @ApiModelProperty(value = "机电类别")
    private String metype;

    /**
     * 计划单价
     */
    @ApiModelProperty(value = "计划单价")
    private BigDecimal planPrice;

    /**
     * 相关文件
     */
    @ApiModelProperty(value = " 相关文件 ")
    private List<Integer> files;

    @Override
    public Integer getObjectType() {
        return StoreExceptionEnum.IN_USE.getCode();
    }

    public void verification() {
        if (cargoMax == null || cargoMax < 0) {
            cargoMax = 0;
        }
        if (cargoMin == null || cargoMin < 0) {
            cargoMin = 0;
        }
        if (unitPrice == null) {
            unitPrice = new BigDecimal("0");
        }
    }
}
