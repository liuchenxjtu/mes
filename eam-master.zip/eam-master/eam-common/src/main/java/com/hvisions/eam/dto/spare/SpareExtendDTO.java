package com.hvisions.eam.dto.spare;

import com.hvisions.common.annotation.ExcelAnnotation;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>Title:SpareExtendDTO</p>
 * <p>Description:导出用模板</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/21</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
public class SpareExtendDTO {

    /**
     * 备件编码
     */
    @ApiModelProperty(value = "备件编码")
    private String spareCode;

    /**
     * 备件名称
     */
    @ApiModelProperty(value = "备件名称")
    private String spareName;

    /**
     * 单价
     */
    @ApiModelProperty(value = " 单价 ")
    private BigDecimal unitPrice;

    /**
     * 最大库存
     */
    @ApiModelProperty(value = " 最大库存 ")
    private Integer cargoMax;

    /**
     * 最小库存
     */
    @ApiModelProperty(value = " 最小库存 ")
    private Integer cargoMin;

    /**
     * 备注
     */
    @ApiModelProperty(value = " 备注 ")
    private String remarks;

    /**
     * 供应商
     */
    @ApiModelProperty(value = " 供应商 ")
    private String supplier;

    //---------------------------- 备件单位字段 ------------------------
    /**
     * 单位名称
     */
    @ApiModelProperty(value = " 单位名称 ")
    private String unitName;

    /**
     * 品牌
     */
    @ApiModelProperty(value = " 品牌 ")
    private String brand;

    /**
     * 规格
     */
    @ApiModelProperty(value = " 规格 ")
    private String specifications;

    /**
     * 订货号
     */
    @ApiModelProperty(value = "订货号")
    private String orderNum;

    /**
     * 计划单价
     */
    @ApiModelProperty(value = "计划单价")
    @ExcelAnnotation(ignore = true)
    private BigDecimal planPrice;


    /**
     * 采购工程师
     */
    @ApiModelProperty(value = "采购工程师")
    private String purchaseUserName;

    /**
     * 技术工程师
     */
    @ApiModelProperty(value = "技术工程师")
    private String skillUserName;

    /**
     * 机电类别
     */
    @ApiModelProperty(value = "机电类别")
    private String metype;

    /**
     * 备件类型名称
     */
    @ApiModelProperty(value = " 备件类型名称 ")
    private String typeName;

    public Integer validation() {
        //判断最大值 与 最小值
        if (this.getCargoMin() == null || this.getCargoMin() < 0) {
            this.setCargoMin(0);
        }
        if (this.getCargoMax() == null || this.getCargoMax() < 0) {
            this.setCargoMax(0);
        }
        if (this.unitPrice == null) {
            unitPrice = new BigDecimal("0");
        }
        //最大库存大于最小库存
        return this.getCargoMax().compareTo(this.getCargoMin());
    }

}
