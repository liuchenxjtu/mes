package com.hvisions.eam.dto.spare;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title:SpareFileDTO</p>
 * <p>Description:备件文件关系</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/7/17</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
public class SpareFileDTO {

    /**
     * 备件id
     */
    @ApiModelProperty(value = " 备件id ")
    private Integer spareId;
    /**
     * 文件id
     */
    @ApiModelProperty(value = " 文件id ")
    private Integer fileId;


}
