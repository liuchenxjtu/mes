package com.hvisions.eam.dto.spare;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * <p>Title:Item</p>
 * <p>Description:备件申请项</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/4/9</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "备件申请DTO")
public class SpareItemDTO extends SysBaseDTO {

    /**
     * 备件ID
     */
    @ApiModelProperty(value = " 备件,或者油品ID", required = true)
    Integer spareId;

    /**
     * 库位ID
     */
    @ApiModelProperty(value = " 库位ID", required = true)
    Integer shelveId;

    /**
     * 批次号
     */
    @ApiModelProperty(value = " 批次号", required = true)
    String batchNumber;

    /**
     * 备件数量
     */
    @ApiModelProperty(value = " 备件可用数量")
    BigDecimal number;

    /**
     * 库房名称
     */
    @ApiModelProperty(value = " 库房名称 ")
    String shelveName;

    /**
     * 备件名称
     */
    @ApiModelProperty(value = " 备件名称 ")
    String spareName;

    /**
     * 当前备件已经被使用的数量
     */
    @ApiModelProperty(value = " 当前备件已经被使用的数量")
    BigDecimal beenUsing;
    /**
     * 规格
     */
    @ApiModelProperty(value = "规格", readOnly = true)
    private String specifications;

    /**
     * 品牌
     */
    @ApiModelProperty(value = "品牌", readOnly = true)
    private String brand;
    /**
     * 供应商
     */
    @ApiModelProperty(value = "供应商")
    private String supplier;
    /**
     * 类型名称
     */
    @ApiModelProperty(value = "类型名称", readOnly = true)
    private String typeName;
}
