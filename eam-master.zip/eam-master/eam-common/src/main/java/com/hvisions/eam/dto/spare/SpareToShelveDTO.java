package com.hvisions.eam.dto.spare;

import com.hvisions.eam.dto.SysBaseDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * <p>Title:SpareToShelveDTO</p>
 * <p>Description:备件库位关系表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = " 备件库位关系DTO")
public class SpareToShelveDTO extends SysBaseDTO {

    /**
     * 库位ID
     */
    @ApiModelProperty(value = " 库位ID (必填)")
    private Integer shelveId;

    /**
     * 备件code
     */
    @ApiModelProperty(value = " 备件code ")
    private String spareCode;

    /**
     * 备件ID
     */
    @ApiModelProperty(value = " 备件ID (必填)")
    private Integer spareId;

    /**
     * 备件库存数量
     */
    @ApiModelProperty(value = " 备件库存数量 (必填)")
    private Integer number;

    /**
     * 架号 （暂时没用到此字段）
     */
    @ApiModelProperty(value = " 架号 ")
    private String rackNumber;

    /**
     * 批次号
     */
    @ApiModelProperty(value = "批次号 (必填)")
    private String batchNumber;

    /**
     * 图片
     */
    @ApiModelProperty(value = " 图片 ")
    private Integer img;

    /**
     * 备件类型名称
     */
    @ApiModelProperty(value = " 备件类型名称 ")
    private String typeName;

    /**
     * 备件类型编码
     */
    @ApiModelProperty(value = " 备件类型code ")
    private String typeCode;

    /**
     * 库房名称
     */
    @ApiModelProperty(value = " 库房名称 ")
    private String shelveName;

    /**
     * 备件定义名称
     */
    @ApiModelProperty(value = " 备件名称 ")
    private String spareName;

    /**
     * 品牌
     */
    @ApiModelProperty(value = " 品牌 ")
    private String brand;

    /**
     * 单价
     */
    @ApiModelProperty(value = " 单价 ")
    private BigDecimal planPrice;

    /**
     * 规格
     */
    @ApiModelProperty(value = " 规格 ")
    private String specifications;

    /**
     * 库存数量状态 0 数据错误或未填写最大最小值  1 库存不足 2 库存超限
     */
    @ApiModelProperty(value = " 库存数量状态 ")
    private Integer inventoryQuantityStatus;
    /**
    *   供应商
    */
    @ApiModelProperty(value = "供应商")
    private String supplier;
}
