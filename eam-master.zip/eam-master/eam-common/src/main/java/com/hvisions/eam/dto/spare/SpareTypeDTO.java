package com.hvisions.eam.dto.spare;

import com.hvisions.common.annotation.ExcelAnnotation;
import com.hvisions.common.interfaces.IObjectType;
import com.hvisions.eam.dto.SysBaseDTO;
import com.hvisions.eam.enums.StoreExceptionEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>Title:SpareTypeDTO</p>
 * <p>Description:备件型号</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/19</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
@ApiModel(description = "备件型号")
public class SpareTypeDTO extends SysBaseDTO implements IObjectType {

    public SpareTypeDTO() {
        //默认批量管理
        this.batchManagementOrNot = 0;
    }

    /**
     * 类型编码
     */
    @ApiModelProperty(value = " 类型编码(必填)", required = true)
    private String typeCode;

    /**
     * 类型名称
     */
    @ApiModelProperty(value = " 类型名称(必填)", required = true)
    private String typeName;

    /**
     * 父级ID
     */
    @ExcelAnnotation(ignore = true)
    @ApiModelProperty(value = " 父级ID")
    private Integer parentId;

    /**
     * 上级类型编码
     */
    @ApiModelProperty(value = " 上级类型编码")
    private String parentCode;

    /**
     * 是否内置
     */
    @ApiModelProperty(value = " 是否内置")
    private Integer isBuiltIn;

    @ExcelAnnotation(ignore = true)
    @ApiModelProperty(value = " 创建人名称")
    private String createUserName;

    /**
     * 管理类型 是否批量管理 0 默认 统一管理 1 单个管理
     */
    @ApiModelProperty(value = " 管理类型(必填) 是否批量管理 0 默认 统一管理 1 单个管理 ")
    private Integer batchManagementOrNot;


    @Override
    public Integer getObjectType() {
        return StoreExceptionEnum.IN_USE.getCode();
    }
}
