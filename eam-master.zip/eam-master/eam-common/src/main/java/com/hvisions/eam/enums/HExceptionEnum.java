package com.hvisions.eam.enums;

import com.hvisions.common.interfaces.BaseErrorCode;
import lombok.Getter;

/**
 * <p>Title: HExceptionEnum</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2018/9/25</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Getter
public enum HExceptionEnum implements BaseErrorCode {
    SERVER_ERROR(99999),
    //异常类型,添加枚举时，应该在i18n中添加对应的中英文转换
    DEMO_EXCEPTION_ENUM(30001),
    //参数用途
    START_PLAN_ERROR(15010),
    REFUSE_PLAN_ERROR(15020),
    DELETE_PLAN_ERROR(15030),
    UPDATE_PLAN_ERROR(15040),
    DELETE_CONTENT_ERROR(15050),
    DELETE_ITEM_ERROR(15060),
    RESULT_VO_TRANSFER_ERROR(15070),
    INSERT_CODE_ERROR(15080),
    ITEM_IS_NULL(15090),
    CHECKER_IS_NULL(15100),
    STOP_ERROR(15200),
    //开始结束时间错误
    START_END_TIME_EXCEPTION(17006),
    EQUIPMENT_TYPE_SERVER_ERROR(15210),
    EQUIPMENT_TYPE_NOT_EXIST_ERROR(15220),
    MAINTAIN_ITEM_NOT_EXIST(15230),
    DELETE_DATA_ERROR(15240),
    PROCESS_INSTANCE_START_FAILED(15250),
    PARENT_GROUP_DOES_NOT_EXIST(15260),
    DATA_IN_WRONG_FORMAT(15270),
    THE_GROUP_DOES_NOT_EXIST(15280),
    INCOMPLETE_DATA(15290),
    THE_VALUE_RANGE_OF_ENABLE_FLAG_IS_INCORRECT(15300),
    ABNORMAL_TIMES_INCORRECT_VALUE_RANGE(15310)
    ;
    private Integer code;

    HExceptionEnum(Integer code) {
        this.code = code;
    }


    @Override
    public String getMessage() {
        return this.toString();
    }
}
