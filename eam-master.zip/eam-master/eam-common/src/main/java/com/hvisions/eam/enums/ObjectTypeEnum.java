package com.hvisions.eam.enums;

import com.hvisions.common.interfaces.BaseErrorCode;
import lombok.Getter;

/**
 * <p>Title: ObjectTypeEnum</p >
 * <p>Description: 类型枚举</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/1</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@Getter
public enum ObjectTypeEnum implements BaseErrorCode {
    //故障类型
    FAULT_Class_DTO(17001),
    //故障
    FAULT_DTO(17002),
    //故障原因
    FAULT_REASON_DTO(17003),
    //故障解决方案
    FAULT_SOLUTION_DTO(17004),
    //dto转换错误
    DTO_CONVERT_MAP_EXCEPTION(17005),
    //开始结束时间错误
    START_END_TIME_EXCEPTION(17006),
    //存在子层级
    HIERARCHY_EXISTS_DELETION_FAILED(17007),
    ;

    private int code;

    ObjectTypeEnum(int code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return this.toString();
    }

    @Override
    public Integer getCode() {
        return code;
    }
}
