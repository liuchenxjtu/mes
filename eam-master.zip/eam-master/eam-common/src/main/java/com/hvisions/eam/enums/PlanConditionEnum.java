package com.hvisions.eam.enums;

import com.hvisions.common.interfaces.IKeyValueObject;

/**
 * <p>Title: PlanConditionEnum</p >
 * <p>Description: 计划状态枚举</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/19</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
public enum PlanConditionEnum implements IKeyValueObject {
    /**
     * 枚举，
     */
    TO_BE_APPROVED(1, "待审批"),
    PASSED(2, "审批通过"),
    REJECT(3, "驳回"),
    NO_APPROVE(4, "无需审批"),
    NOT_ENABLED(5, "未启用"),
    FORCED_STOP(6, "强制停用"),
    ;

    public static PlanConditionEnum valueOf(int index) {
        switch (index) {
            case 1:
                return TO_BE_APPROVED;
            case 2:
                return PASSED;
            case 3:
                return REJECT;
            case 4:
                return NO_APPROVE;
            case 5:
                return NOT_ENABLED;
            case 6:
                return FORCED_STOP;
            default:
                return NOT_ENABLED;
        }
    }

    private int code;
    private String name;

    PlanConditionEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }


    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }
}
