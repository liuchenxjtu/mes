package com.hvisions.eam.enums;

import com.hvisions.common.interfaces.IKeyValueObject;

/**
 * <p>Title: RepairMaintainEnum</p >
 * <p>Description: 维修保养日历--任务状态枚举</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2022/2/7</p >
 *
 * @author : x.l
 * @version :1.0.0
 */
public enum RepairMaintainEnum implements IKeyValueObject {
    DENY(0, "不能操作"),
    PROCESSING(1, "处理中"),
    FINISHED(2, "已完成"),
    PENDING(3, "待执行"),
    OVERDUE(4, "逾期");

    private final int code;
    private final String name;

    RepairMaintainEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    @Override
    public Integer getCode() {
        return this.code;
    }

    @Override
    public String getName() {
        return this.name;
    }
}
