package com.hvisions.eam.enums;


import com.hvisions.common.interfaces.BaseErrorCode;
import lombok.Getter;

/**
 * <p>Title: StoreExceptionEnum</p>
 * <p>Description: 备件异常枚举</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2018/9/25</p>
 *
 * @author :yu
 * @version :1.0.0
 */
@Getter
public enum StoreExceptionEnum implements BaseErrorCode {
    //异常类型
    //备件数量不为零
    ENUM_NOT_ZERO_EXCEPTION(14010),
    //被使用
    IN_USE(14020),
    //数量
    NUMBER_EXCEPTION(14030),
    //类型为null
    TYPE_IS_NULL_EXCEPTION(14040),
    // 状态异常
    TYPE_EXCEPTION(14050),
    //工作流异常
    WORK_FLOW_SERVER_ERROR(14060),
    //库存数量错误
    SHELVE_NUMBER_EXCEPTION(14070),
    //流水号参数异常
    SERIAL_NUMBER_PARAMETER_EXCEPTION(14080),
    //最大值 或 最小值 错误
    MAX_OR_MIN_NUMBER_EXCEPTION(14090),
    //服务不存在
    REGEX_IS_NULL(14100),
    //批次号与正则匹配错误
    BATCH_NUMBER_WITH_REGEX_MATCH_ERROR(14110),
    //正则错误
    REG_EX_EXCEPTION(14120),
    //XXX库存数量不足
    XXX_SHELVE_NUMBER_EXCEPTION(14130),
    //当前库房数量不为零
    SHELVE_NUMBER_IS_NOT_ZERO_EXCEPTION(14140),
    //XXX申请数量错误
    XXX_APPLY_NUMBER_EXCEPTION(14150),
    //库房信息为错误
    SHELVE_INFORMATION_EXCEPTION(14160),
    //批次号信息错误
    BATCH_NUMBER_INFORMATION_EXCEPTION(14170),
    //数据错误
    DATE_ERROR_EXCEPTION(14180),
    //维修单失效
    THE_DELIERY_ORDER_IS_INVALID_EXCEPTION(14190),
    //库房批次号未查询到当前
    SHELVE_AND_BATCH_NUMBER_NOT_SELECT_XXX(14200),
    //当前出库单无效
    CURRENT_OUTBOUND_ORDER_IS_INVALID(14210),
    //当前类型数量不可修改
    CURRENT_NUMBER_OF_TYPES_CANNOT_BE_MODIFIED(14220),
    //当前类型批次号不可修改
    CURRENT_TYPE_BATCH_NUMBER_CANNOT_BE_MODIFIED(14230),
    //超出申请数量
    BEYOND_THE_NUMBER_OF_APPLICATIONS(14240),
    //请选择操作数据
    SELECT_OPERATION_DATA(14250),
    //最大或最小库存数量错误
    MAX_OR_MIN_SHELVE_NUMBER_EXCEPTION(14260),
    //没有这个单位名称的单位
    A_UNIT_WITHOUT_THIS_UNIT_NAME(14270),
    //价格是错误的
    PRICE_IS_WRONG(14780),
    //库存数量错误
    INVENTORY_QUANTITY_ERROR(14790),
    //没有具有此类型名称的类型
    THERE_IS_NO_TYPE_WITH_THIS_TYPE_NAME(14800),
    //有子层级，不可删除
    THERE_ARE_SUBIEVEIS_THAT_CANNOT_BE_DELETED(14900),
    //不支持该数据库查询
    NOT_CURRENT_DATABASES_SUPPORTED(14910),
    //当前数据已存在,请修改对应数据
    THE_CURRENT_DATA_ALREADY_EXISTS_PLEASE_MODIFY_THE_CORRESPONDING_DATA(14920),
    //备件名称不允许修改
    SPARE_NAME_IS_NOT_ALLOWED_TO_BE_MODIFIED(14930),
    //油品不允许修改
    LUBRICATING_IS_NOT_ALLOWED_TO_BE_MODIFIED(14940),
    //出入库数据信息为空
    EMPTY_LINE(14950),
    //备件信息错误
    SPARE_PART_ERROR(14960),
    //备件品牌已被使用
    BRAND_USED(14961)
    ;
    private int code;

    StoreExceptionEnum(int code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return this.toString();
    }

    @Override
    public Integer getCode() {
        return code;
    }

}
