package com.hvisions.eam.enums;

import com.hvisions.common.interfaces.IKeyValueObject;

/**
 * <p>Title: TaskTypeEnum</p >
 * <p>Description: 任务类型枚举</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2022/2/7</p >
 *
 * @author : x.l
 * @version :1.0.0
 */
public enum TaskTypeEnum implements IKeyValueObject {
    REPAIR_TASK(1, "维修任务"),
    MAINTAIN_TASK(2, "保养任务");

    private final int code;
    private final String name;

    TaskTypeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    @Override
    public Integer getCode() {
        return this.code;
    }

    @Override
    public String getName() {
        return this.name;
    }
}
