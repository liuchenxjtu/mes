package com.hvisions.eam;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

/**
 * <p>Title: DemoApplication</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2018/11/7</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@SpringBootApplication
@EnableDiscoveryClient
@MapperScan("com.hvisions.eam.dao")
@EnableFeignClients(basePackages = {"com.hvisions.framework.client",
        "com.hvisions.eam.client",
        "com.hvisions.hiperbase.client",
        "com.hvisions.activiti.client",
        "com.hvisions.hipertools.client",})
@ComponentScan(basePackages = {"com.hvisions.eam",
        "com.hvisions.framework.client.fallback",
        "com.hvisions.activiti.client"})
public class EamApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(EamApplication.class, args);
    }

    /**
     * 可以使得项目用war包部署
     *
     * @param builder builder
     * @return builder
     */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(EamApplication.class);
    }


}
