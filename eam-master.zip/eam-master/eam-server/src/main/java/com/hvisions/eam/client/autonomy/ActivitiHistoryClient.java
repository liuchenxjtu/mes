package com.hvisions.eam.client.autonomy;

import com.hvisions.eam.dto.autonomy.process.JsonRootBean;
import com.hvisions.eam.dto.autonomy.repair.process.RepairData;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>Title: ActivitiHistoryClient</p>
 * <p>Description: 查询历史工作流数据</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/9/29</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@FeignClient(name = "activiti")
@RequestMapping("/history")
public interface ActivitiHistoryClient {
    /**
     * 查询流程实例
     *
     * @param processInstanceId 流程实例ID
     * @return 分页信息
     */
    @GetMapping(value = "/getHistoryProcessInstanceById/{processId}")
    JsonRootBean getProcessInstance(@PathVariable(value = "processId") String processInstanceId);

    /**
     * 查询流程实例
     *
     * @param pId 流程实例ID
     * @return 分页信息
     */
    @GetMapping(value = "/getHistoryProcessInstanceById/{pId}")
    RepairData getRepairProcessInstance(@PathVariable(value = "pId") String pId);
}

    
    
    
    