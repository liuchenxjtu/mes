package com.hvisions.eam.client.autonomy;

import com.hvisions.eam.dto.autonomy.JsonByUserId;
import com.hvisions.eam.dto.autonomy.MessageCreateDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@FeignClient(name = "framework")
public interface AuthClient {

    @GetMapping(value = "/baseUser/getUserByUserId/{userId}")
    JsonByUserId getUserById(@PathVariable(value = "userId") int userId);

    @PostMapping(value = "/message/createMessage")
    JsonByUserId createMessage(MessageCreateDTO dto);
}

    
    
    
    