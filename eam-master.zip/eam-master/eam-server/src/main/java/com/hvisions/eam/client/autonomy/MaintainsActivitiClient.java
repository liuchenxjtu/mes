package com.hvisions.eam.client.autonomy;

import com.hvisions.activiti.dto.process.ProcessDefinationQuery;
import com.hvisions.activiti.dto.process.ProcessDefinitionDTO;
import com.hvisions.common.vo.ResultVO;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * <p>Title: ActivitiClient</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/10</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@FeignClient(name = "activiti", fallback = MaintainsActivitiClientFallback.class,qualifier = "autonomyMaintainsActivitiClient")
public interface MaintainsActivitiClient {
    /**
     * 查询流程定义
     *
     * @param processDefinationQuery 查询条件
     * @return 分页
     */
    @ApiOperation(value = "查询流程定义")
    @PostMapping(value = "/repository/getAllProcessList")
    ResultVO<List<ProcessDefinitionDTO>> getAllProcess(@RequestBody ProcessDefinationQuery processDefinationQuery);

    /**
     * 根据流程文件发布流程
     *
     * @param file 文件
     * @return vo
     */
    @ApiOperation(value = "根据流程文件发布流程")
    @PostMapping(value = "/repository/deployByFile")
    ResultVO deployByFile(@RequestParam("file") MultipartFile file);

    /**
     * 根据文件内容发布流程
     *
     * @param resourceName 文件名
     * @param bpmnFile     文件内容
     * @return vo
     */
    @ApiOperation(value = "根据文件内容发布流程")
    @PostMapping(value = "/repository/deployByText/{resourceName}")
    ResultVO deployByText(@PathVariable(value = "resourceName") String resourceName, @RequestBody String bpmnFile);
}
