package com.hvisions.eam.client.autonomy;

import com.hvisions.activiti.dto.process.ProcessDefinationQuery;
import com.hvisions.activiti.dto.process.ProcessDefinitionDTO;
import com.hvisions.common.vo.ResultVO;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * <p>Title: ActivitiClientFallback</p >
 * <p>Description: ActivitiClientFallback</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/10</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Component(value = "autonomyMaintainsActivitiClientFallback")
public class MaintainsActivitiClientFallback implements MaintainsActivitiClient {
    @Override
    public ResultVO<List<ProcessDefinitionDTO>> getAllProcess(ProcessDefinationQuery processDefinationQuery) {
        return new ResultVO<>();
    }

    @Override
    public ResultVO deployByFile(MultipartFile file) {
        return new ResultVO<>();
    }

    @Override
    public ResultVO deployByText(String resourceName, String bpmnFile) {
        return new ResultVO<>();
    }
}