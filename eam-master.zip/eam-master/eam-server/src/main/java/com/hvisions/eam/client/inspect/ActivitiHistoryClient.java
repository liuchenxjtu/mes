package com.hvisions.eam.client.inspect;

import com.hvisions.common.vo.ResultVO;
import com.hvisions.eam.dto.inspect.process.Data;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>Title: ActivitiHistoryClient</p>
 * <p>Description: 查询历史工作流数据</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/9/29</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@FeignClient(name = "activiti")
@RequestMapping("/history")
public interface ActivitiHistoryClient {
    /**
     * 查询流程实例
     *
     * @param processInstanceId 流程实例ID
     * @return 分页信息
     */
    @GetMapping(value = "/getHistoryProcessInstanceById/{processInstanceId}")
    ResultVO<Data> getProcessInstance(@PathVariable(value = "processInstanceId") String processInstanceId);
}

    
    
    
    