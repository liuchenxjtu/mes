package com.hvisions.eam.client.maintain;

import com.hvisions.common.vo.ResultVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 * <p>Title: TaskController</p>
 * <p>Description: 流程任务管理，任务提醒，任务完成，创建任务</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2019/3/25</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@FeignClient(value = "activiti", path = "/task", fallbackFactory = NewTaskFallbackFactory.class)
public interface NewTaskClient {

    /**
     * 分类任务获取数量
     *
     * @param userId 用户Id
     * @return 查询所有任务分类，并且查询其数量
     */
    @GetMapping(value = "/getTaskCount")
    ResultVO<Map<String, Object>> getTaskCount(@RequestParam(value = "userId", defaultValue = "") String userId);


}









