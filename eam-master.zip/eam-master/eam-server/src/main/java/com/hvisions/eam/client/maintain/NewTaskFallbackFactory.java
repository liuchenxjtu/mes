package com.hvisions.eam.client.maintain;

import com.hvisions.common.exception.BaseFallbackFactory;
import com.hvisions.common.vo.ResultVO;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * <p>Title: TaskFallbackFactory</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2019/7/24</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Component
public class NewTaskFallbackFactory extends BaseFallbackFactory<NewTaskClient> {
    @Override
    public NewTaskClient getFallBack(ResultVO vo) {
        return new NewTaskClient() {

            /**
             * 分类任务获取数量
             *
             * @param userId 用户Id
             * @return 查询所有任务分类，并且查询其数量
             */
            @Override
            public ResultVO<Map<String, Object>> getTaskCount(String userId) {
                return vo;
            }
        };
    }
}









