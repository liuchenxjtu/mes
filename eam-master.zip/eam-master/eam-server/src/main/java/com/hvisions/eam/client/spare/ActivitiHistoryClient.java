package com.hvisions.eam.client.spare;

import com.hvisions.activiti.dto.history.HistoricTaskInstanceDTO;
import com.hvisions.activiti.dto.history.HistoryTaskQueryDTO;
import com.hvisions.common.vo.ResultVO;
import com.hvisions.eam.dto.maintain.process.JsonRootBean;
import com.hvisions.eam.dto.repair.process.RepairData;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


/**
 * <p>Title:StoreClient</p>
 * <p>Description:</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/1/1</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@FeignClient(name = "activiti", fallback = ActivitiHistoryClientFallBack.class)
public interface ActivitiHistoryClient {

    /**
     * 分页查询
     *
     * @param historyTaskQueryDTO a
     * @return a
     */
    @ApiOperation("复杂查询 查询历史记录 分页查询")
    @PostMapping({"/history/getHistoricTaskInstance"})
    ResultVO<Page<HistoricTaskInstanceDTO>> getHistoricTaskInstance(@RequestBody HistoryTaskQueryDTO historyTaskQueryDTO);

    /**
     * 查询流程实例
     *
     * @param processInstanceId 流程实例ID
     * @return 分页信息
     */
    @GetMapping(value = "/history/getHistoryProcessInstanceById/{processInstanceId}")
    JsonRootBean getProcessInstance(@PathVariable(value = "processInstanceId") String processInstanceId);

    /**
     * 查询流程实例
     *
     * @param pId 流程实例ID
     * @return 分页信息
     */
    @GetMapping(value = "/history/getHistoryProcessInstanceById/{pId}")
    RepairData getRepairProcessInstance(@PathVariable(value = "pId") String pId);
}
