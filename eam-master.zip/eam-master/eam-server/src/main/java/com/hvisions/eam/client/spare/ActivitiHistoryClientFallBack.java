package com.hvisions.eam.client.spare;

import com.hvisions.activiti.dto.history.HistoricTaskInstanceDTO;
import com.hvisions.activiti.dto.history.HistoryTaskQueryDTO;
import com.hvisions.common.vo.ResultVO;
import com.hvisions.eam.dto.maintain.process.JsonRootBean;
import com.hvisions.eam.dto.repair.process.RepairData;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

/**
 * <p>Title:StoreClientFallBack</p>
 * <p>Description:</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/1/1</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Component
public class ActivitiHistoryClientFallBack implements ActivitiHistoryClient {


    @Override
    public ResultVO<Page<HistoricTaskInstanceDTO>> getHistoricTaskInstance(HistoryTaskQueryDTO historyTaskQueryDTO) {
        return new ResultVO<>();
    }

    /**
     * 查询流程实例
     *
     * @param processInstanceId 流程实例ID
     * @return 分页信息
     */
    @Override
    public JsonRootBean getProcessInstance(String processInstanceId) {
        return null;
    }

    /**
     * 查询流程实例
     *
     * @param pId 流程实例ID
     * @return 分页信息
     */
    @Override
    public RepairData getRepairProcessInstance(String pId) {
        return null;
    }
}
