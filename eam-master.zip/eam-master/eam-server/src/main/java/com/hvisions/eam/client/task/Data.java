/**
 * Copyright 2022 json.cn
 */
package com.hvisions.eam.client.task;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * Auto-generated: 2022-07-28 17:9:6
 *
 * @author json.cn (i@json.cn)
 */

@Getter
@Setter
@ToString
public class Data {

    private String processInstanceId;
    private String taskDefinitionKey;
    private HistoryVariables historyVariables;
}