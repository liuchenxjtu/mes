package com.hvisions.eam.client.task;

import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * <p>Title: HistoryClient</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2022/7/28</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@FeignClient(
    value = "activiti",
    path = "/history"
)
public interface HistoryClient {
    @ApiOperation("复杂查询 查询历史记录 分页查询")
    @GetMapping({"/getHistoricTaskInstanceById/{taskId}"})
    JsonRootBean getHistoricTaskInstanceById(@PathVariable(value = "taskId") String taskId);
}








