/**
 * Copyright 2022 json.cn
 */
package com.hvisions.eam.client.task;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@ToString
public class HistoryVariables {

    private String processInstanceId;
    private String source;
    private String title;
    private String applyUserName;
    private String inOut;
    private int isPass;
    private List<Items> items;
    private String receiptNumber;

}