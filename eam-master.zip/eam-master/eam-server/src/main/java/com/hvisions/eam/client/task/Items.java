/**
 * Copyright 2022 json.cn
 */
package com.hvisions.eam.client.task;

/**
 * Auto-generated: 2022-07-28 17:9:6
 *
 * @author json.cn (i@json.cn)
 */

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Items {

    private Integer spareId;
    private String brand;
    private String specifications;
    private String supplier;
    private String typeName;
    private Integer lubId;
    private String lubName;
    private Integer shelveId;
    private String shelveName;
    private String batchNumber;
    private float number;

}