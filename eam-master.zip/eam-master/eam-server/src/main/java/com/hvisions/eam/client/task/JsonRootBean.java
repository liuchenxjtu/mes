/**
 * Copyright 2022 json.cn
 */
package com.hvisions.eam.client.task;

/**
 * Auto-generated: 2022-07-28 17:9:6
 *
 * @author json.cn (i@json.cn)
 */

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class JsonRootBean {

    private Data data;
    private int code;
    private String message;

}