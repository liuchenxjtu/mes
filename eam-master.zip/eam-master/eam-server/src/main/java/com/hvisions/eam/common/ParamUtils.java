package com.hvisions.eam.common;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ParamUtils {

    /**
     * 去除对象中类型为String的属性的前后空格
     * @param bean 对象
     * @throws Exception 异常
     */
    public static void beanAttributeValueTrim(Object bean) throws Exception {
        if (bean != null) {
            Field[] fields = bean.getClass().getDeclaredFields();
            for (int i = 0; i < fields.length; i++) {
                Field f = fields[i];
                if ("java.lang.String".equals(f.getType().getName())) {
                    String key = f.getName();
                    Object value = getFieldValue( bean, key );
                    if (value == null) {
                        continue;
                    }
                    setFieldValue( bean, key, value.toString().trim() );
                }
            }
        }
    }

    private static Object getFieldValue(Object bean, String fieldName) throws Exception {
        StringBuffer result = new StringBuffer();
        String methodName = result.append( "get" )
                .append( fieldName.substring( 0, 1 ).toUpperCase() )
                .append( fieldName.substring( 1 ) ).toString();
        Object rObject = null;
        Method method = null;
        Class[] classArr = new Class[0];
        method = bean.getClass().getMethod( methodName, classArr );
        rObject = method.invoke( bean, new Object[0] );
        return rObject;
    }

    private static void setFieldValue(Object bean, String fieldName, Object value) throws Exception {
        StringBuffer result = new StringBuffer();
        String methodName = result.append( "set" )
                .append( fieldName.substring( 0, 1 ).toUpperCase() )
                .append( fieldName.substring( 1 ) ).toString();
        Class[] classArr = new Class[1];
        classArr[0] = "java.lang.String".getClass();
        Method method = bean.getClass().getMethod( methodName, classArr );
        method.invoke( bean, value );
    }

}
