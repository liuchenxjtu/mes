package com.hvisions.eam.consts;

/**
 * <p>Title: DbConst</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2018/10/30</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
public interface DbConst {
    /**
     * 常量示例
     */
    String DEMO_CONST = "DEMO CONST STRING";

    /**
     * businessKey 唯一标识
     */
    String BUSINESS_KEY = "设备-维修";

    /**
     * 流程KEY
     */
    String PROCESS_DEFINITION_KEY = "equipment-maintenance";
}

