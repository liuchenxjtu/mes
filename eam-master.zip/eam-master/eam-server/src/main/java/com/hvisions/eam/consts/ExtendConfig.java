package com.hvisions.eam.consts;

import com.hvisions.common.utils.SqlFactoryUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>Title: ExtendConfig</p>
 * <p>Description: 扩展服务根据配置注入</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2018/12/24</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Configuration
public class ExtendConfig {

    /**
     * @return 获取扩展服务工厂对象
     */
    @Bean
    SqlFactoryUtil getSqlFactory() {
        return new SqlFactoryUtil();
    }

}









