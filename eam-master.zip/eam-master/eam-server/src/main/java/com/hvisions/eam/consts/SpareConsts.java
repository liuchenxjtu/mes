package com.hvisions.eam.consts;

/**
 * <p>Title:SpareConsts</p>
 * <p>Description:备件常量</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
public interface SpareConsts {

    /**
     * 备件导出表格名称
     */
    String SPARE_EXPORT_FILE_NAME = "spare.xls";

    /**
     * 油品导出表格名称
     */
    String LUB_EXPORT_FILE_NAME = "lub.xls";

    /**
     * 品牌导出excel名称
     */
    String SPARE_BRAND_FILE_NAME = "spareBrand.xls";

    /**
     * 备件类型excel名称
     */
    String SPARE_TYPE_FILE_NAME = "spareType.xls";
}
