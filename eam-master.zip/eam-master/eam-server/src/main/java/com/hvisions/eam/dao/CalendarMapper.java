package com.hvisions.eam.dao;

import com.hvisions.eam.dto.maintain.HiTaskDTO;
import com.hvisions.eam.dto.maintain.process.PlanEquipmentDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * <p>Title: CalendarMapper</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2022/2/8</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Mapper
@Component
public interface CalendarMapper {


    /**
     * 查询历史任务
     *
     * @param startTimeAfter
     * @param startTimeBefore
     * @param defKey
     * @return 历史任务
     */
    List<HiTaskDTO> getHiTask(@Param("after") Date startTimeAfter, @Param("before") Date startTimeBefore,
                              @Param("key") String defKey);

    /**
     * 查询任务
     *
     * @param startTimeAfter
     * @param startTimeBefore
     * @param defKey
     * @return 任务信息
     */
    List<HiTaskDTO> getTask(@Param("after") Date startTimeAfter, @Param("before") Date startTimeBefore,
                            @Param("key") String defKey);


    /**
     * 查询保养计划使用的time
     *
     * @return timeId列表
     */
    List<Integer> getTimeIdByPlan();


    /**
     * 根据计划id列表查询
     *
     * @param integers
     * @return
     */
    List<PlanEquipmentDTO> getPlanEquipment(@Param("ids") List<Integer> integers);
}