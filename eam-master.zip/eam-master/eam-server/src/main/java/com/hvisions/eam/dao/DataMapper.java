package com.hvisions.eam.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: DataMapper</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/12/23</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Component
@Mapper
public interface DataMapper {
    /**
     * 获取所有没有被通不过的保养流程实例id列表
     *
     * @return 保养流程实例id列表
     */
    List<String> getMaintainProcessIds();

    /**
     * 获取所有没有被同步的维修数据id列表
     *
     * @return 维修流程实例id列表
     */
    List<String> getRepairProcessIds();


    /**
     * 查询设备的产线信息
     *
     * @param equipmentId 设备id
     * @return 设备的产线信息
     */
    List<Integer> getLineIdsByEquipmentId(@Param(value = "id") Integer equipmentId);
}

    
    
    
    