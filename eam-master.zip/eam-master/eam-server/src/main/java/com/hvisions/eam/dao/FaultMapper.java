package com.hvisions.eam.dao;

import org.apache.ibatis.annotations.Mapper;

/**
 * <p>Title: FaultMapper</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/7/2</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Mapper
public interface FaultMapper {


    Integer getEquipmentCount();
}