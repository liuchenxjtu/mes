package com.hvisions.eam.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hvisions.eam.dto.autonomy.InspectionProjectDTO;
import com.hvisions.eam.dto.autonomy.InspectionProjectQueryDTO;
import com.hvisions.eam.entity.autonomy.HvAmInspectionProject;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xiehao
 * @since 2021-06-11
 */
@Repository
public interface InspectionProjectMapper extends BaseMapper<HvAmInspectionProject> {

    /**
     * 获取检测周期
     * @author xiehao
     * @return 检测周期list
     */
    List<String> getTestCycle();

    List<InspectionProjectDTO> getInspectionProjectS(@Param("dto") InspectionProjectQueryDTO inspectionProjectQueryDTO);

}
