package com.hvisions.eam.dao;

import com.hvisions.eam.dto.lub.LubToShelveDTO;
import com.hvisions.eam.query.lub.LubToShelveQueryDTO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title:lubToShelveMapper</p>
 * <p>Description:</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/8/6</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Mapper
@Component
public interface LubToShelveMapper {

    /**
     * 备件库房 分页查询 MYSQL
     *
     * @param lubToShelveQueryDTO 查询条件
     * @return 分页
     */
    List<LubToShelveDTO> getLubToShelve(LubToShelveQueryDTO lubToShelveQueryDTO);


}
