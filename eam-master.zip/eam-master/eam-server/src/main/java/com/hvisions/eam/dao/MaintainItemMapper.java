package com.hvisions.eam.dao;

import com.hvisions.eam.dto.maintain.MaintainItemDTO;
import com.hvisions.eam.dto.maintain.MaintainItemQueryDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: MaintainItemMapper</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/18</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Mapper
@Component
public interface MaintainItemMapper {

    /**
     * 查询保养项目
     *
     * @param maintainItemQueryDTO 查询条件
     * @return 保养项目信息
     */
    List<MaintainItemDTO> getMaintainItemByQuery(@Param("query") MaintainItemQueryDTO maintainItemQueryDTO);
}