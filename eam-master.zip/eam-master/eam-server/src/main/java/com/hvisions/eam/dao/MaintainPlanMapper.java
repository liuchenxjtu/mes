package com.hvisions.eam.dao;

import com.hvisions.eam.dto.maintain.SpareOrLubInfo;
import com.hvisions.eam.dto.maintain.MaintainPlanDTO;
import com.hvisions.eam.dto.maintain.MaintainPlanQuery;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: MaintainPlanMapper</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/5/21</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface MaintainPlanMapper {
    /**
     * 分页查询
     *
     * @param query 查询条件
     * @return 列表数据
     */
    List<MaintainPlanDTO> getPage(@Param(value = "query") MaintainPlanQuery query);

    /**
     * 汇总统计保养项目中的备件和油品信息
     *
     * @param maintainItemIds 保养项目id列表
     * @return 备件油品信息
     */
    List<SpareOrLubInfo> getSparesInfo(@Param("ids") List<Integer> maintainItemIds);

    /**
     * 获取计划的工时信息
     *
     * @param id 计划id
     * @return 计划工时
     */
    Float getPlanManHour(@Param("id") Integer id);
}

    
    
    
    