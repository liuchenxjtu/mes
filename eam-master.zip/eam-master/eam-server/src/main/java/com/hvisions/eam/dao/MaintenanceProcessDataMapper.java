package com.hvisions.eam.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hvisions.eam.entity.autonomy.HvAmAutonomyMaintenanceProcessData;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xiehao
 * @since 2021-06-11
 */
public interface MaintenanceProcessDataMapper extends BaseMapper<HvAmAutonomyMaintenanceProcessData> {

}
