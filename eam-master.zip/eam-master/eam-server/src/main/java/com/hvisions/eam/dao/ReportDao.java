package com.hvisions.eam.dao;

import com.hvisions.eam.dto.publicstore.SparePartInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: ReportDao</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2022/5/16</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Component
@Mapper
public interface ReportDao {
    /**
     * 获取设备用到的备件信息
     *
     * @param equipmentId 设备id
     * @return 备件信息
     */
    List<SparePartInfo> getEquipmentSparePart(@Param(value = "equipmentId") Integer equipmentId);
}

    
    
    
    