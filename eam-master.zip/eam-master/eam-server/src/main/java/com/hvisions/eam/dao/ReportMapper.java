package com.hvisions.eam.dao;

import com.hvisions.eam.dto.maintain.TaskSummaryDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>Title: ReportMapper</p>
 * <p>Description: 报告</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/9/27</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface ReportMapper {
    /**
     * 统计工作流中所有流程的完成情况
     *
     * @param start 开始时间
     * @return 流程定义以及对应的流程总数，完成的数量
     */
    List<TaskSummaryDTO> getSummary(@Param(value = "start") LocalDateTime start);

    /**
     * 获取保养计划数量
     *
     * @return 保养数量计划
     */
    Integer getMaintainPlanCount();

    /**
     * 获取点巡检计划数量
     *
     * @return 点巡检计划数量
     */
    Integer getInspectionPlanCount();

    /**
     * 获取自主性维护计划数量
     *
     * @return 自主性维护计划数量
     */
    Integer getAutoPlanCount();


    /**
     * 获取故障知识库里面的解决方案数量
     * @return 解决方案数量
     */
    Integer getFaultKnowledge();
}

    
    
    
    