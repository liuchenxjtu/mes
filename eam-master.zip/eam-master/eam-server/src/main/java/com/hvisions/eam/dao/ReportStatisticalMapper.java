package com.hvisions.eam.dao;

import com.hvisions.eam.dto.report.*;
import com.hvisions.eam.dto.report.EquipmentFaultInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: ReportStatisticalMapper</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/5</p >
 *
 * @author : fengfeng
 * @version :1.0.0
 */
@Mapper
@Component
public interface ReportStatisticalMapper {

    /**
     * 急维修 Pareto 分析
     *
     * @param reportUrgentRepairParetoAnalysisQuery 急维修 Pareto 查询条件
     * @return 急维修 Pareto 统计记录
     */
    List<UrgentRepairParetoInfo> urgentMainParetoAnalysis(@Param("dto") ReportUrgentRepairParetoAnalysisQuery reportUrgentRepairParetoAnalysisQuery);

    /**
     * 设备故障统计表
     *
     * @param reportEquipmentFaultStatisticalQuery 设备故障查询条件
     * @return 设备故障统计记录
     */
    List<EquipmentFaultInfo> equipmentFaultStatistical(@Param("dto") ReportEquipmentFaultStatisticalQuery reportEquipmentFaultStatisticalQuery);

    /**
     * 维修人员工作统计,查询维修的
     *
     * @param reportRepairUserJobStatisticalQuery 维修人员工作统计查询条件
     * @return 维修人员工作统计，查询维修的记录
     */
    List<RepairUserJobInfo> repairUserJobFromRepair(@Param("dto") ReportRepairUserJobStatisticalQuery reportRepairUserJobStatisticalQuery);

    /**
     * 维修人员工作统计，查询保养的
     *
     * @param reportRepairUserJobStatisticalQuery 维修人员工作统计查询条件
     * @return 维修人员工作统计，查询保养的记录
     */
    List<RepairUserJobInfo> repairUserJobFromMaintain(@Param("dto") ReportRepairUserJobStatisticalQuery reportRepairUserJobStatisticalQuery);

    /**
     * 设备维修查询
     * @param reportQuery 查询条件
     * @return 设备维修信息
     */
    List<MaintainReportDTO> getReportByQuery(@Param("dto") ReportQuery reportQuery);
}