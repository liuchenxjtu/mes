package com.hvisions.eam.dao;

import com.hvisions.eam.dto.shutdown.ShutdownDTO;
import com.hvisions.eam.dto.shutdown.ShutdownQuery;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: ShutDownMapper</p>
 * <p>Description: 停机信息查询</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/6</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface ShutDownMapper {
    /**
     * 获取所有的停机信息
     *
     * @param query 查询条件
     * @return 停机信息
     */
    List<ShutdownDTO> getAll(@Param(value = "query") ShutdownQuery query);
}









