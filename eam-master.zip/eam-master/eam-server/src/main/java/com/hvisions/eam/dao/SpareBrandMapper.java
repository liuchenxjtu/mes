package com.hvisions.eam.dao;

import com.hvisions.eam.dto.spare.SpareBrandDTO;
import com.hvisions.eam.dto.spare.SpareBrandQuery;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>Title: SpareBrandMapper</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/11</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Mapper
public interface SpareBrandMapper {


    /**
     * 备件品牌查询
     *
     * @param spareBrandQuery 查询条件
     * @return 备件品牌信息
     */
    List<SpareBrandDTO> getBrandByQuery(@Param("dto") SpareBrandQuery spareBrandQuery);
}