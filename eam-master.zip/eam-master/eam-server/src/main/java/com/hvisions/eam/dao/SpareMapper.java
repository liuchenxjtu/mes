package com.hvisions.eam.dao;

import com.hvisions.eam.dto.spare.SpareDTO;
import com.hvisions.eam.query.spare.SpareQueryDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>Title: SpareMapper</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/13</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Mapper
public interface SpareMapper {


    /**
     * 备件条件查询
     *
     * @param spareQuery 查询条件
     * @return 备件信息
     */
    List<SpareDTO> getSpareByQuery(@Param("dto") SpareQueryDTO spareQuery);


}