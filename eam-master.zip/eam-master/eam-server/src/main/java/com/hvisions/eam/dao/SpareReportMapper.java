package com.hvisions.eam.dao;

import com.hvisions.eam.dto.repair.spare.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>Title: SpareReportMapper</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/1/5</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Mapper
public interface SpareReportMapper {

    /**
     * 备件使用统计
     *
     * @param sparePartUsageQueryDTO 备件使用统计查询条件
     * @return 备件使用统计记录
     */
    List<SparePartUsageDTO> sparePartUsage(@Param("dto") SparePartUsageQueryDTO sparePartUsageQueryDTO);

    /**
     * 备件周转率
     *
     * @param turnoverQueryDTO 周转率查询条件
     * @return 周转率信息
     */
    List<MonthTurnoverDTO> spareTurnover(@Param("dto") TurnoverQueryDTO turnoverQueryDTO);

    /**
     * 当月故障统计报表
     *
     * @param equipmentFailureQueryDTO 查询条件
     * @return 统计记录
     */
    List<EquipmentFailureDTO> equipmentFailure(@Param("dto") EquipmentFailureQueryDTO equipmentFailureQueryDTO);

    List<FaultNumDTO> getFaultNum(@Param("dto") EquipmentFailureQueryDTO equipmentFailureQueryDTO);

    List<StoreNumDTO> getStoreNum(@Param("dto") TurnoverQueryDTO turnoverQueryDTO);
}