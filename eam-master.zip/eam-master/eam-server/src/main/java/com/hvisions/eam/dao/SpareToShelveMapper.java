package com.hvisions.eam.dao;

import com.hvisions.eam.dto.spare.SpareToShelveDTO;
import com.hvisions.eam.query.spare.SpareToShelveQueryDTO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title:SpareToShelveInfo</p>
 * <p>Description:备件库存</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/8/6</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Mapper
@Component
public interface SpareToShelveMapper {

    /**
     * 备件库房 分页查询 MYSQL
     *
     * @param spareToShelveQueryDTO 分页信息
     * @return 分页
     */
    List<SpareToShelveDTO> getSpareToShelve(SpareToShelveQueryDTO spareToShelveQueryDTO);


}
