package com.hvisions.eam.dao;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.hvisions.eam.dto.autonomy.MaintenanceProcessDataDTO;
import com.hvisions.eam.dto.autonomy.MaintenanceProcessDataQueryDTO;
import com.hvisions.eam.dto.autonomy.MaintenanceProcessItemDTO;
import com.hvisions.eam.dto.autonomy.MaintenanceProcessItemQueryDTO;
import com.hvisions.eam.entity.autonomy.HvAmAutonomyMaintenanceProcessItem;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xiehao
 * @since 2021-06-11
 */
@Repository
public interface StatisticalMapper extends BaseMapper<HvAmAutonomyMaintenanceProcessItem> {

    List<MaintenanceProcessDataDTO> getdataList(@Param("dto") MaintenanceProcessDataQueryDTO maintenanceProcessDataQueryDTO);

    List<MaintenanceProcessItemDTO> getItemList(@Param("dto") MaintenanceProcessItemQueryDTO maintenanceProcessItemQueryDTO);

    List<HvAmAutonomyMaintenanceProcessItem> fuzzyQueryItem(@Param(Constants.WRAPPER) Wrapper<HvAmAutonomyMaintenanceProcessItem> wrapper);
}
