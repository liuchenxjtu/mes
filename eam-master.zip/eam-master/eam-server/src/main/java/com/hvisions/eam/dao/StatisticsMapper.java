package com.hvisions.eam.dao;

import com.hvisions.eam.dto.report.ReportEquipmentDowntimeRateDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>Title: StatisticsMapper</p>
 * <p>Description: 统计mapper</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/6</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
public interface StatisticsMapper {
    List<ReportEquipmentDowntimeRateDTO> getDownInfo();
}









