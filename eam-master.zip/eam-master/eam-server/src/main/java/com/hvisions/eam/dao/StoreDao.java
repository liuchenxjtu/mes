package com.hvisions.eam.dao;

import com.hvisions.eam.dto.publicstore.StoreQuery;
import com.hvisions.eam.dto.spare.SpareItemDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: StoreDao</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/3/1</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface StoreDao {
    /**
     * 获取某个流程中所有已经出库的备件信息
     *
     * @param query 查询条件
     * @return 备件信息
     */
    List<SpareItemDTO> getAllSparePart(@Param(value = "query") StoreQuery query);

    /**
     * 获取某个流程中所有已经出库的油品数据
     *
     * @param query 查询条件
     * @return 油品信息
     */
    List<SpareItemDTO> getAllLub(@Param(value = "query") StoreQuery query);
}

    
    
    
    