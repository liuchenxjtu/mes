package com.hvisions.eam.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * <p>Title: UtilsMapper</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/7/2</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface UtilsMapper {
    /**
     * 获取设备对应的默认维修用户id
     *
     * @param equipmentId 设备did
     * @return 用户id
     */
    Integer getUserId(@Param("equipmentId") Integer equipmentId);
}

    
    
    
    