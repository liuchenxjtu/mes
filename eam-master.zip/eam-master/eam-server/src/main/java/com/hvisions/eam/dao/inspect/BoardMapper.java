package com.hvisions.eam.dao.inspect;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>Title: BoardMapper</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/15</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface BoardMapper {
    /**
     * 获取截止日期之前的点巡检任务数量
     *
     * @param localDate 截止时间
     * @return 点巡检任务数量
     */
    Integer getTaskCount(@Param(value = "date") LocalDate localDate);

    /**
     * 获取某个时间之后的所有检测项目数量
     *
     * @param localDate 截止时间
     * @return 检测项目数量
     */
    Integer getItemCount(@Param(value = "date") LocalDate localDate);

    /**
     * 获取某个时间之后完成的检测项目数量
     *
     * @param localDate 截止时间
     * @return 检测项目数量
     */
    Integer getFinishedItemCount(@Param(value = "date") LocalDate localDate);

    /**
     * 获取最后一次执行点巡检的时间
     *
     * @return 最后一次时间
     */
    LocalDateTime getLastInspectTime();
}









