package com.hvisions.eam.dao.inspect;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: InspectDataMapper</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/12</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface InspectDataMapper {
    /**
     * 获取没同步过的数据id列表
     *
     * @return 流程实例id列表
     */
    List<String> getProcessInstanceIds();
}

    
    
    
    