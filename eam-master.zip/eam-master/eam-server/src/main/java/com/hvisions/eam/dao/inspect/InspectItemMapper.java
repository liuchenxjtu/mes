package com.hvisions.eam.dao.inspect;

import com.hvisions.eam.dto.inspect.item.InspectItemDTO;
import com.hvisions.eam.dto.inspect.item.InspectItemQueryDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: InspectItemMapper</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/18</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Mapper
@Component
public interface InspectItemMapper {

    /**
     * 查询方式
     *
     * @param inspectItemQueryDTO 查询条件
     * @return 列表数据
     */
    List<InspectItemDTO> getInspectItemByQuery(@Param("query") InspectItemQueryDTO inspectItemQueryDTO);
}