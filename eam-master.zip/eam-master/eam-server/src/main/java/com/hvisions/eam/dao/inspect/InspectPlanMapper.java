package com.hvisions.eam.dao.inspect;

import com.hvisions.eam.dto.inspect.plan.InspectPlanDTO;
import com.hvisions.eam.dto.inspect.plan.InspectPlanQueryDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>Title: MaintainPlanMapper</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/5/21</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface InspectPlanMapper {
    /**
     * 分页查询
     *
     * @param query 查询条件
     * @return 列表数据
     */
    List<InspectPlanDTO> getPage(@Param(value = "query") InspectPlanQueryDTO query);
}

    
    
    
    