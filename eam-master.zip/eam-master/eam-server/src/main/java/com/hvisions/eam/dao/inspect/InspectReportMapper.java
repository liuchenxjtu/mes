package com.hvisions.eam.dao.inspect;

import com.hvisions.eam.dto.inspect.report.ItemFinishFail;
import com.hvisions.eam.dto.inspect.report.ItemInfo;
import com.hvisions.eam.dto.inspect.report.PersonInfo;
import com.hvisions.eam.dto.inspect.report.ProcessInfoDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

/**
 * <p>Title: InspectReportMapper</p>
 * <p>Description: 点巡检看板报表统计mapper</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/19</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Mapper
@Component
public interface InspectReportMapper {
    /**
     * 获取时间之后的流程实例信息
     *
     * @param localDate 时间
     * @return 流程实例信息
     */
    List<ProcessInfoDTO> getInspectDayInfo(@Param(value = "query") LocalDate localDate);


    /**
     * 获取巡检项合格信息
     *
     * @param localDate 时间
     * @return 巡检项合格信息
     */
    List<ItemFinishFail> getPassRate(@Param(value = "query") LocalDate localDate);

    /**
     * 获取top10的巡检项信息
     *
     * @param localDate 开始时间
     * @return 巡检项以及次数
     */
    List<ItemInfo> getTop10Items(@Param(value = "query") LocalDate localDate);

    /**
     * 获取top10的巡检项信息
     *
     * @param localDate 开始时间
     * @return 巡检项以及次数
     */
    List<PersonInfo> getTop10Worker(@Param(value = "query") LocalDate localDate);


    /**
     * 获取设备的流程实例id列表
     * @param equipmentId 设备id
     * @return 流程实例id列表
     */
    List<String> getProcessInstanceIds(@Param(value = "equipmentId") Integer equipmentId);
}

    
    
    
    