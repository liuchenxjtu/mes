package com.hvisions.eam.entity;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.util.Date;

/**
 * <p>Title:HvEamSerialNumber</p>
 * <p>Description:流水号</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/15</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Entity
@Data
@Table(uniqueConstraints = {@UniqueConstraint(name = "流水号服务名唯一", columnNames = "service")})
public class HvEamSerialNumber {

    @Id
    private Integer id;

    /**
     * 出库流水号
     */
    private Integer number;

    /**
     * 当天日期
     */
    private Date day;

    /**
     * 服务名
     */
    @Length(max = 200,message = "流水号服务名唯一")
    private String service;

}