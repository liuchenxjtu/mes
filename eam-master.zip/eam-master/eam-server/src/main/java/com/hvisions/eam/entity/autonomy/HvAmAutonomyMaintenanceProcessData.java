package com.hvisions.eam.entity.autonomy;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * <p>
 * 自主维护流程数据
 * </p>
 *
 * @author xiehao
 * @since 2021-06-23
 */
@Entity
@Getter
@Setter
@ToString
public class HvAmAutonomyMaintenanceProcessData {

    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Integer id;

    /**
     * 流程实例数据
     */
    private String processInstanceId;
    private String processDefinitionId;
    private String processDefinitionName;
    private String processDefinitionKey;
    private int processDefinitionVersion;
    private String deploymentId;
    private String businessKey;
    private String tenantId;
    private String name;
    private String description;
    private String localizedName;
    private String localizedDescription;
    private String startTime;
    private String endTime;
    private String startUserId;

    /**
     * 流程参数数据
     */
    private String number;//检查计划编码
    private String taskName;//检查计划名称
    private String typesOfLiability;//责任类型;0-责任人,1-责任组
    private String personLiable;//责任人
    private String responsibilityGroup;//责任组
    private String verifier;//验证人员
    private String foreman;//班组长
    private String leader;//主管领导
    private String descr;//描述
    private Integer timerId;//timerId

    private String hasError;// 0 - 否，1 - 是

}









