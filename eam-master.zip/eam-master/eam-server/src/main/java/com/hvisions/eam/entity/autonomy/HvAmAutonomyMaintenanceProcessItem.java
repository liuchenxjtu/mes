package com.hvisions.eam.entity.autonomy;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * <p>
 * 自主维护流程-项目数据
 * </p>
 *
 * @author xiehao
 * @since 2021-06-23
 */
@Entity
@Getter
@Setter
@ToString
public class HvAmAutonomyMaintenanceProcessItem {

    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Integer id;
    private String number;
    private String name;
    private String testContent;
    private String testCycle;
    private String testMethod;
    private String enableFlag;
    private Integer abnormalTimes;
    private Integer groupId;
    private String groupName;
    private String hasError;// 0 - 否，1 - 是
    private String remark;
    private Integer processDataId;

}









