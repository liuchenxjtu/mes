package com.hvisions.eam.entity.autonomy;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * 检查计划
 * </p>
 *
 * @author xiehao
 * @since 2021-06-11
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = {@UniqueConstraint(name = "检查计划编码唯一", columnNames = "number")})
public class HvAmInspectionPlan extends SysBase{

    /**
     * 检查计划编码
     */
    @NotBlank(message = "检查计划编码不能为空")
    private String number;

    /**
     * 检查计划名称
     */
    @NotBlank(message = "检查计划名称不能为空")
    private String name;

    /**
     * 责任类型;0-责任人,1-责任组
     */
    private String typesOfLiability;

    /**
     * 责任人
     */
    private String personLiable;

    /**
     * 责任组
     */
    private String responsibilityGroup;

    /**
     * 验证人员
     */
    @NotBlank(message = "验证人员不能为空")
    private String verifier;

    /**
     * 班组长
     */
    @NotBlank(message = "班组长不能为空")
    private String foreman;

    /**
     * 主管领导
     */
    @NotBlank(message = "主管领导不能为空")
    private String leader;

    /**
     * timerId
     */
    @NotNull(message = "timerId不能为空")
    private Integer timerId;

}
