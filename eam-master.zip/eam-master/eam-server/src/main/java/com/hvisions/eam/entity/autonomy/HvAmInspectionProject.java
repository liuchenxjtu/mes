package com.hvisions.eam.entity.autonomy;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * <p>
 * 检查项目
 * </p>
 *
 * @author xiehao
 * @since 2021-06-11
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = {@UniqueConstraint(name = "检查项目编号唯一", columnNames = "number")})
public class HvAmInspectionProject extends SysBase{

    /**
     * 检查项目编号
     */
    @NotBlank(message = "检查项目编号不能为空")
    private String number;

    /**
     * 检查项目名称
     */
    @NotBlank(message = "检查项目名称不能为空")
    private String name;

    /**
     * 检测内容
     */
    @NotBlank(message = "检测内容不能为空")
    private String testContent;

    /**
     * 检测周期
     */
    @NotBlank(message = "检测周期不能为空")
    private String testCycle;

    /**
     * 检测方法
     */
    @NotBlank(message = "检测方法不能为空")
    private String testMethod;

    /**
     * 启用标志;0-启用,1-未启用
     */
    @Pattern(regexp = "[0,1]", message = "启用标志只能为0或1")
    private String enableFlag;

    /**
     * 连续异常次数
     */
    @Min(value = 1, message = "连续异常次数不能小于1")
    @NotNull(message = "连续异常次数不能为空")
    private Integer abnormalTimes;

    /**
     * 组ID
     */
    @NotNull(message = "组ID不能为空")
    private Integer groupId;

}
