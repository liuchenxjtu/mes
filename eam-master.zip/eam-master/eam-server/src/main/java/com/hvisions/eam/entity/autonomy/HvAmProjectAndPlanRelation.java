package com.hvisions.eam.entity.autonomy;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * 项目和计划关系表
 * </p>
 *
 * @author xiehao
 * @since 2021-06-11
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
public class HvAmProjectAndPlanRelation extends SysBase{

    /**
     * 检查计划ID
     */
    @NotNull(message = "检查计划ID不能为空")
    private Integer planId;

    /**
     * 检查项目ID
     */
    @NotNull(message = "检查项目ID不能为空")
    private Integer projectId;

}
