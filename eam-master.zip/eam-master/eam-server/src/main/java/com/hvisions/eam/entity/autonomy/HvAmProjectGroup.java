package com.hvisions.eam.entity.autonomy;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;

/**
 * <p>
 * 项目组
 * </p>
 *
 * @author xiehao
 * @since 2021-06-16
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = {@UniqueConstraint(name = "组名称唯一", columnNames = "name")})
public class HvAmProjectGroup  extends SysBase{

    /**
     * 组名称
     */
    @NotBlank(message = "组名称不能为空")
    private String name;

    /**
     * 父级ID
     */
    private Integer parentId;

}
