package com.hvisions.eam.entity.fault;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * <p>Title: HvEmFault</p >
 * <p>Description: 故障实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/27</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(name = "故障代码唯一", columnNames = "faultCode"),
        @UniqueConstraint(name = "故障名称唯一", columnNames = "faultName")})
public class HvEmFault extends SysBase {

    /**
     * 故障代码
     */
    @Length(max = 100,message = "故障编码长度不能超过100")
    @Column(updatable = false)
    @NotBlank(message = "故障代码不能为空")
    private String faultCode;

    /**
     * 故障名称
     */
    @Length(max = 100,message = "故障名称长度不能超过100")
    @NotBlank(message = "故障名称不能为空")
    private String faultName;
    /**
     * 故障现象
     */
    private String description;
    /**
     * 故障类
     */
    @Min(value = 0, message = "故障类必须存在")
    private Integer faultClassId;

}