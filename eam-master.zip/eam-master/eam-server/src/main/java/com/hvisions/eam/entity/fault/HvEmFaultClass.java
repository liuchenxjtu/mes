package com.hvisions.eam.entity.fault;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * <p>Title: HvEmFaultClass</p >
 * <p>Description: 故障类实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/27</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(name = "故障类名称唯一", columnNames = "faultClassName")})
public class HvEmFaultClass extends SysBase {

    /**
     * 故障类名称
     */
    @Length(max = 100,message = "故障类名称长度不能超过100")
    @NotBlank(message = "故障类名称不能为空")
    private String faultClassName;

    /**
     * 故障父类id
     */
    @Min(value = 0, message = "故障父类必须存在")
    private Integer parentId = 0;

    /**
     * 设备类型id
     */
    private Integer equipmentClassId;
}