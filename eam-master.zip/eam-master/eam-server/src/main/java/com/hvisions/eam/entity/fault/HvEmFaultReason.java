package com.hvisions.eam.entity.fault;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * <p>Title: HvEmFaultReason</p >
 * <p>Description: 故障原因</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/27</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(name = "原因编码唯一", columnNames = "reasonCode")})
public class HvEmFaultReason extends SysBase {

    /**
     * 故障原因编码
     */
    @Length(max = 100,message = "原因编码长度不能超过100")
    @Column(updatable = false)
    @NotBlank(message = "原因编码不能为空")
    private String reasonCode;

    /**
     * 故障原因
     */
    private String reason;

    /**
     * 故障id
     */
    @Min(value = 0, message = "故障必须存在")
    private Integer faultId = 0;
}