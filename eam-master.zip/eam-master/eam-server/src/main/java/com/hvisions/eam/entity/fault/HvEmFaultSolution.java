package com.hvisions.eam.entity.fault;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * <p>Title: HvEmFaultSolution</p >
 * <p>Description: 故障解决方案</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/27</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(name = "解决方案编码唯一", columnNames = "solutionCode"),
        @UniqueConstraint(name = "解决方案名称唯一", columnNames = "solutionName")})
public class HvEmFaultSolution extends SysBase {

    /**
     * 解决方案编码
     */
    @Length(max = 100,message = "解决方案编码长度不能超过100")
    @Column(updatable = false)
    @NotBlank(message = "解决方案编码不能为空")
    private String solutionCode;

    /**
     * 解决方案名称
     */
    @Length(max = 100,message = "解决方案名称长度不能超过100")
    @NotBlank(message = "解决方案名称不能为空")
    private String solutionName;

    /**
     * 解决步骤
     */
    private String solution;

    /**
     * 故障原因id
     */
    @Min(value = 0, message = "故障原因必须存在")
    private Integer reasonId = 0;

    /**
     * 备注
     */
    private String remark;
}