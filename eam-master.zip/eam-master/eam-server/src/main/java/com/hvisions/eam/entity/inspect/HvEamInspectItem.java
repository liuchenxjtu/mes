package com.hvisions.eam.entity.inspect;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * <p>Title: HvEamInspectItem</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/27</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = {@UniqueConstraint(name = "点检项目编码唯一", columnNames = "inspectItemCode")})
public class HvEamInspectItem extends SysBase {
    /**
     * 保养项目编号
     */
    @NotBlank(message = "保养项目编号不能为空")
    @Column(updatable = false)
    private String inspectItemCode;
    /**
     * 保养项目名称
     */
    @NotBlank(message = "保养项目名称不能为空")
    private String inspectItemName;

    /**
     * 保养内容
     */
    @NotBlank(message = "保养内容不能为空")
    private String inspectWork;
    /**
     * 是否需要停机
     */
    @NotNull(message = "是否需要停机不能为空")
    private Boolean shutDown;
    /**
     * 是否启用
     */
    @NotNull(message = "是否启用不能为空")
    private Boolean startUsing;

    /**
     * 零部件
     */
    private String parts;

    /**
     * 操作周期
     */
    private String cycle;
    /**
     * 所需工时
     */
    @NotNull(message = "工时信息不能为空")
    @Min(value = 0, message = "工时不能小于0")
    private Float manHour;
}