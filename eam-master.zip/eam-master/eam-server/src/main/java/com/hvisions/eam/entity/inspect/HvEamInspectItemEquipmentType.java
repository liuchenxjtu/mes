package com.hvisions.eam.entity.inspect;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

/**
 * <p>Title: HvEamMaintainItemFile</p >
 * <p>Description: 保养项目与文件关系实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/19</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = @UniqueConstraint(name = "uq_inspect_item_equipment_type",
    columnNames = {"itemId", "equipmentTypeId"}))
public class HvEamInspectItemEquipmentType extends SysBase {
    /**
     * 设备类型id
     */
    @Column(updatable = false)
    @NotNull
    private Integer equipmentTypeId;
    /**
     * 保养项目id
     */
    @Column(updatable = false)
    @NotNull
    private Integer itemId;
    /**
     * 设备类型编码
     */
    private String equipmentTypeCode;
    /**
     * 设备类型名称
     */
    private String equipmentTypeName;
}