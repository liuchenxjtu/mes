package com.hvisions.eam.entity.inspect;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * <p>Title: HvEamInspectItemFile</p >
 * <p>Description: 点检项目与文件关系实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/19</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = @UniqueConstraint(name = "uq_inspect_item_file", columnNames = {"inspectItemId", "fileId"}))
public class HvEamInspectItemFile extends SysBase {
    /**
     * 点检项目id
     */
    private Integer inspectItemId;
    /**
     * 文件id
     */
    private Integer fileId;
}