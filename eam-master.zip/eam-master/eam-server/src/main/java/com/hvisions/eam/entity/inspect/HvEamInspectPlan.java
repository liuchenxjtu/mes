package com.hvisions.eam.entity.inspect;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * <p>Title: HvEamInspectPlan</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/28</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = {@UniqueConstraint(name = "点巡检计划编码唯一", columnNames = "inspectPlanNum")})
public class HvEamInspectPlan extends SysBase {
    /**
     * 点检计划编号
     */
    @Column(updatable = false)
    @Length(max = 100, message = "点巡检计划编码过长")
    private String inspectPlanNum;
    /**
     * 点检计划名称
     */
    @NotBlank(message = "点巡检计划名称不能为空")
    private String inspectPlanName;
    /**
     * 点检计划审批状态id
     */
    @Min(value = 1, message = "状态id不合法：1-待审批，2-审批通过，3-驳回，4-无需审批,5-未启用,6-强制停用")
    @Max(value = 6, message = "状态id不合法：1-待审批，2-审批通过，3-驳回，4-无需审批,5-未启用,6-强制停用")
    private Integer inspectPlanConditionId;
    /**
     * 任务完成期限
     */
    @Min(value = 0, message = "完成期限不能小于0")
    private Integer deadline;
    /**
     * 是否启用
     */
    private Boolean startUsing;
    /**
     * 执行人id
     */
    private Integer transactorId;
    /**
     * 审核人id
     */
    private Integer checkerId;
    /**
     * timer周期id
     */
    private Integer timerId;
    /**
     * 备注
     */
    private String remark;

    /**
     * 驳回原因
     */
    private String rejectReason;

    /**
     * 候选人列表
     */
    private String candidateUsers;
    /**
     * 候选组列表
     */
    private String candidateGroups;

}