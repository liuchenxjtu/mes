package com.hvisions.eam.entity.inspect;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

/**
 * <p>Title: HvEamInspectPlanContent</p >
 * <p>Description: 点巡检计划与内容关系实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/16</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = @UniqueConstraint(name = "idx_plan_item_File", columnNames = {"inspectPlanId", "fileId"}))
public class HvEamInspectPlanFile extends SysBase {
    /**
     * 计划id
     */
    @NotNull(message = "项目计划id不能为空")
    private Integer inspectPlanId;
    /**
     * 点检内容id
     */
    @NotNull(message = "计划项目不能为空")
    private Integer fileId;
}