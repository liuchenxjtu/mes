package com.hvisions.eam.entity.inspect;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

/**
 * Auto-generated: 2021-01-12 9:37:25
 *
 * @author leiming
 */

@Getter
@Setter
@ToString
@Entity
public class HvEamInspectProcessContentItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Integer id;
    private Date createTime;
    private Integer itemId;
    private Integer contentId;
    private String siteNum;
    private String inspectItemName;
    private String inspectItemCode;
    private Integer equipmentTypeId;
    private String inspectPosition;
    private String inspectWork;
    private String inspectTheoreticalValue;
    private Boolean startUsing;
    private Integer manHour;
    private Boolean shutDown;
    private String done;
    private String remark;
    private String parts;
    private String inspectionMethod;
    private String cycle;
    private String personInCharge;
    private String manHourString;
}