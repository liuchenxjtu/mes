package com.hvisions.eam.entity.inspect;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

/**
 * Auto-generated: 2021-01-12 9:37:25
 *
 * @author leiming
 */

@Getter
@Setter
@ToString
@Entity
public class HvEamInspectProcessData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Integer id;
    private String processInstanceId;
    private String processDefinitionId;
    private String processDefinitionName;
    private String processDefinitionKey;
    private String processDefinitionVersion;
    private String deploymentId;
    private String businessKey;
    private String tenantId;
    private String name;
    private String description;
    private String localizedName;
    private String localizedDescription;
    private Date startTime;
    private Date endTime;
    private Integer startUserId;
    private String executorName;
    private String manHourString;
    private Integer checkerId;
    private String checkerName;
    private String taskName;
    private String equipmentName;
    private String category;
    private String taskNum;
    private String hvisionsTaskState;
    private Integer executor_id;
    private Date taskEndTime;
}