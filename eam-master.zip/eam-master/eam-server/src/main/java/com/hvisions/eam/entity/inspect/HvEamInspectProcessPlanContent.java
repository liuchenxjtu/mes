package com.hvisions.eam.entity.inspect;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Auto-generated: 2021-01-12 9:37:25
 *
 * @author leiming
 */

@Getter
@Setter
@ToString
@Entity
public class HvEamInspectProcessPlanContent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer inspectPlanId;
    private Integer equipmentId;
    private Integer contentId;
    private String processInstanceId;
    private Integer inspectContentId;
    private String inspectContentCode;
    private String inspectContentName;
    private Integer priority;
    private String equipmentName;
    private String equipmentCode;
    private String factory;
    private String workShop;
    private String line;
    private String equipmentTypeId;
    private Boolean shutDown;
    private String manHourString;
    private Integer manHour;
}