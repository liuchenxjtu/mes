package com.hvisions.eam.entity.inspect;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import java.util.Date;

/**
 * <p>Title: HvEamInspectStatistical</p >
 * <p>Description: 点检统计实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/8</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class HvEamInspectStatistical extends SysBase {
    /**
     * 设备名称
     */
    private String equipmentName;
    /**
     * 设备id
     */
    private Integer equipmentId;
    /**
     * 设备编码
     */
    private String equipmentCode;
    /**
     * 流程id
     */
    private String processInstanceId;
    /**
     * 工厂
     */
    private String factory;
    /**
     * 车间
     */
    private String workShop;
    /**
     * 设备所在产线
     */
    private String line;
    /**
     * 流程开始时间
     */
    private Date startTime;
    /**
     * 流程结束时间
     */
    private Date endTime;
}