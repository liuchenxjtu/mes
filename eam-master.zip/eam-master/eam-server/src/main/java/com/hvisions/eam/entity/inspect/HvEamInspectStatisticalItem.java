package com.hvisions.eam.entity.inspect;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;

/**
 * <p>Title: HvEamInspectStatisticalItem</p >
 * <p>Description: 报表统计子项实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/7/8</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class HvEamInspectStatisticalItem extends SysBase {
    /**
     * 流程id
     */
    private String processInstanceId;
    /**
     * 设备编码
     */
    private String equipmentCode;
    /**
     * 检查部位
     */
    private String inspectPosition;
    /**
     * 检查工作
     */
    private String inspectWork;
    /**
     * 检查点理论值
     */
    private String inspectTheoreticalValue;
    /**
     * 所需工时
     */
    private Float manHour;
}