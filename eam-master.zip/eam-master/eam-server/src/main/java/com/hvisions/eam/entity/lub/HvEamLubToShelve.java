package com.hvisions.eam.entity.lub;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.math.BigDecimal;

/**
 * <p>Title:SpareToShelve</p>
 * <p>Description:油品关系表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class HvEamLubToShelve extends SysBase {

    public HvEamLubToShelve() {

    }

    public HvEamLubToShelve(Integer lubId, Integer shelveId, BigDecimal number, String batchNumber) {
        this.lubId = lubId;
        this.shelveId = shelveId;
        this.number = number;
        this.batchNumber = batchNumber;
    }

    /**
     * 库位ID
     */
    private Integer shelveId;

    /**
     * 油品ID
     */
    @Column(updatable = false)
    private Integer lubId;

    /**
     * 油品库存数量
     */
    private BigDecimal number;

    /**
     * 架号
     */
    @Column(updatable = false)
    private String rackNumber;

    /**
     * 批次号
     */
    @Column(updatable = false)
    private String batchNumber;

    /**
     * 图片
     */
    private Integer img;
}