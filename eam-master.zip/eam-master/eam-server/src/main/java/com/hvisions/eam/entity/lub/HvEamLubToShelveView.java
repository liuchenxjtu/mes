package com.hvisions.eam.entity.lub;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import java.math.BigDecimal;

/**
 * <p>Title:HvEamSpareToShelveView</p>
 * <p>Description:油品 库房 关系视图</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/4/1</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class HvEamLubToShelveView extends SysBase {

    //--------------------- 油品 ---------------------
    /**
     * 油品ID
     */
    private Integer lubId;
    /**
     * 油品编码
     */
    private String lubCode;

    /**
     * 油品名称
     */
    private String lubName;

    /**
     * 图片
     */
    private Integer img;

    //---------------------- 关系 ----------------------
    /**
     * 库存数量
     */
    private BigDecimal number;

    /**
     * 批次号
     */
    private String batchNumber;

    //---------------------- 库房 ----------------------
    /**
     * 库房ID
     */
    private Integer shelveId;

    /**
     * 库位编码
     */
    private String shelveCode;

    /**
     * 库位名称
     */
    private String shelveName;

}