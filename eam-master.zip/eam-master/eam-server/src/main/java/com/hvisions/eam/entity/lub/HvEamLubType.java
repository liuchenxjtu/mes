package com.hvisions.eam.entity.lub;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * <p>Title:SpareTypeEntityRepository</p>
 * <p>Description:油品型号</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(uniqueConstraints = {@UniqueConstraint(name = "油品类型编码唯一", columnNames = "typeCode"),
        @UniqueConstraint(name = "油品类型名称唯一", columnNames = "typeName")})
public class HvEamLubType extends SysBase {

    /**
     * 类型编码
     */
    @Column(updatable = false)
    @Length(max = 200,message = "类型编码不能超过200")
    private String typeCode;

    /**
     * 类型名称
     */
    @Length(max = 200,message = "类型名称不能超过200")
    private String typeName;

    /**
     * 父级ID
     */
    private Integer parentId;

    /**
     * 是否内置
     */
    private Integer isBuiltIn;
}
