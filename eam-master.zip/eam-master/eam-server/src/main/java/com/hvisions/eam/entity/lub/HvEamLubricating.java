package com.hvisions.eam.entity.lub;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.math.BigDecimal;

/**
 * <p>Title:spare</p>
 * <p>Description:油品</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/19</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(uniqueConstraints = {@UniqueConstraint(name = "油品编码唯一", columnNames = "lubCode")})
public class HvEamLubricating extends SysBase {

    /**
     * 油品编码
     */
    @Column(updatable = false)
    @Length(max = 200,message = "油品编码不能超过200")
    private String lubCode;

    /**
     * 油品名称
     */
    @Length(max = 200,message = "油品名称不能超过200")
    private String lubName;

    /**
     * 油品型号ID
     */
    private Integer lubTypeId;

    /**
     * 单位id
     */
    private Integer unitId;

    /**
     * 单价
     */
    private BigDecimal unitPrice;

    /**
     * 最大库存
     */
    private BigDecimal cargoMax;

    /**
     * 最小库存
     */
    private BigDecimal cargoMin;

    /**
     * 备注
     */
    private String remarks;

    /**
     * 供应商
     */
    private String supplier;

    /**
     * 图片
     */
    private Integer img;
}