package com.hvisions.eam.entity.maintain;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * <p>Title: HvEamContentItem</p >
 * <p>Description:保养内容-项目关系实体 </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/20</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class HvEamContentItem extends SysBase {
    /**
     * 保养内容id
     */
    @Min(value = 1, message = "保养内容id不能小于1")
    @NotNull(message = "保养内容id不能为空")
    private Integer maintainContentId;

    /**
     * 保养项目id
     */
    @Min(value = 1, message = "保养项目id不能小于1")
    @NotNull(message = "保养项目id不能为空")
    private Integer itemId;

}