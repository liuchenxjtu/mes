package com.hvisions.eam.entity.maintain;

import com.hvisions.eam.entity.SysBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * <p>Title: HvEamItemLub</p >
 * <p>Description: 保养项目-油品关系实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/9</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@Entity
@Table(uniqueConstraints = @UniqueConstraint(name = "uq_itemlub_item_lub", columnNames = {"maintainItemId", "lubId"}))
public class HvEamItemLub extends SysBase {
    /**
     * 保养项目id
     */
    @Min(value = 1, message = "保养项目id不能小于1")
    @NotNull(message = "保养项目id不能为空")
    private Integer maintainItemId;
    /**
     * 油品id
     */
    @Min(value = 1, message = "油品id不能小于1")
    @NotNull(message = "油品id不能为空")
    private Integer lubId;
    /**
     * 油品名称
     */
    private String lubName;
    /**
     * 油品数量
     */
    @Min(value = 0, message = "油品数量不能小于0")
    @NotNull(message = "油品数量不能为空")
    private BigDecimal lubNum;
    /**
     * 油品编码
     */
    private String lubCode;
    /**
     * 油品单位
     */
    private String lubUnit;
    /**
     * 油品供应商
     */
    private String lubSupplier;
}