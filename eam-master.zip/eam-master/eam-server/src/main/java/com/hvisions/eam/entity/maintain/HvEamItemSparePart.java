package com.hvisions.eam.entity.maintain;

import com.hvisions.eam.entity.SysBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * <p>Title: HvEamItemSparePart</p >
 * <p>Description: 保养项目-备件关系实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/22</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@Entity
@Table(uniqueConstraints = @UniqueConstraint(name = "uq_itemspare_item_spare", columnNames = {"maintainItemId", "sparePartId"}))
public class HvEamItemSparePart extends SysBase {
    /**
     * 保养项目id
     */
    @Min(value = 1, message = "保养项目id不能小于1")
    @NotNull(message = "保养项目id不能为空")
    private Integer maintainItemId;
    /**
     * 备件id
     */
    @Min(value = 1, message = "备件id不能小于1")
    @NotNull(message = "备件id不能为空")
    private Integer sparePartId;
    /**
     * 备件名称
     */
    private String sparePartName;
    /**
     * 备件数量
     */
    @Min(value = 1, message = "备件数量不能小于1")
    @NotNull(message = "备件数量不能为空")
    private BigDecimal sparePartNum;
    /**
     * 备件编码
     */
    private String sparePartCode;
    /**
     * 备件单位
     */
    private String sparePartUnit;
    /**
     * 备件供应商
     */
    private String sparePartSupplier;

}