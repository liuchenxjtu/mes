package com.hvisions.eam.entity.maintain;

import com.hvisions.eam.entity.SysBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * <p>Title: HvEamMaintainItemFile</p >
 * <p>Description: 保养项目与文件关系实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/19</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@Entity
@Table(uniqueConstraints = @UniqueConstraint(name = "uq_itemspare_item_spare", columnNames = {"maintainItemId", "fileId"}))
public class HvEamMaintainItemFile extends SysBase {
    /**
     * 保养项目id
     */
    @Column(updatable = false)
    private Integer maintainItemId;
    /**
     * 文件id
     */
    @Column(updatable = false)
    private Integer fileId;

}