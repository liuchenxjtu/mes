package com.hvisions.eam.entity.maintain;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * <p>Title: HvEamMaintainPlan</p >
 * <p>Description: 保养计划实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/19</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = {@UniqueConstraint(name = "保养计划编码唯一", columnNames = "maintainPlanNum")})
public class HvEamMaintainPlan extends SysBase {
    /**
     * 保养计划编号
     */
    @Column(updatable = false)
    @Length(max = 100, message = "保养计划编码长度过长")
    private String maintainPlanNum;

    /**
     * 保养计划名称
     */
    @NotBlank(message = "保养计划名称不能为空")
    @Length(max = 100, message = "保养计划编码过长")
    private String maintainPlanName;

    /**
     * 保养计划状态id
     */
    @Min(value = 1, message = "状态id不合法：1-待审批，2-审批通过，3-驳回，4-无需审批,5-未启用,6-强制停用")
    @Max(value = 6, message = "状态id不合法：1-待审批，2-审批通过，3-驳回，4-无需审批，5-未启用，6-强制停用")
    private Integer maintainPlanConditionId;
    /**
     * 任务完成期限
     */
    @Min(value = 0, message = "完成期限不能小于0")
    @NotNull(message = "完成期限不能为空")
    private Integer deadline;
    /**
     * 是否启用
     */
    private Boolean startUsing;
    /**
     * 执行人id
     */
    private Integer transactorId;
    /**
     * 审核人id
     */
    private Integer checkerId;
    /**
     * timerId
     */
    @Min(value = 1, message = "周期id不能小于1")
    private Integer timerId;
    /**
     * 是否自动申请备件
     */
    @NotNull(message = "是否自动申请备件不能为空")
    private Boolean autoSpare;
    /**
     * 是否自动申请油品
     */
    @NotNull(message = "是否自动申请油品不能为空")
    private Boolean autoLub;
    /**
     * 备注
     */
    private String remark;

    /**
     * 驳回原因
     */
    private String rejectReason;
    /**
     * 候选人列表
     */
    private String candidateUsers;
    /**
     * 候选人组列表
     */
    private String candidateGroups;

}