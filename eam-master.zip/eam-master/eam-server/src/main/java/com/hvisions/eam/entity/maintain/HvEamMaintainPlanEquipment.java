package com.hvisions.eam.entity.maintain;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * <p>Title: HvEamMaintainPlanEquipment</p >
 * <p>Description: 保养计划详情</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/6/21</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Entity
@Data
@Table(uniqueConstraints = @UniqueConstraint(name = "uq_plan_equipment", columnNames = {"maintainPlanId", "equipmentId", "maintainItemId"}))
public class HvEamMaintainPlanEquipment {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    /**
     * 保养计划id
     */
    @NotNull(message = "计划id填充错误")
    private Integer maintainPlanId;
    /**
     * 设备id
     */
    @NotNull(message = "设备id不能为空")
    private Integer equipmentId;


    @NotNull(message = "保养项目id不能为空")
    private Integer maintainItemId;
}