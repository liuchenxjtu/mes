package com.hvisions.eam.entity.maintain;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * <p>Title: HvEamItemLub</p >
 * <p>Description: 保养项目-油品关系实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/9</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Entity
@Data
@Table(uniqueConstraints = @UniqueConstraint(name = "uq_plan_lub", columnNames = {"maintainPlanId","equipmentId", "lubId"}))
public class HvEamMaintainPlanLub  {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    /**
     * 保养项目id
     */
    @Min(value = 1, message = "保养项目id不能小于1")
    @NotNull(message = "保养项目id不能为空")
    private Integer maintainPlanId;
    /**
     * 油品id
     */
    @Min(value = 1, message = "油品id不能小于1")
    @NotNull(message = "油品id不能为空")
    private Integer lubId;
    /**
     * 设备id
     */
    @NotNull(message = "备件的设备信息不能为空")
    private Integer equipmentId;
    /**
     * 油品名称
     */
    private String lubName;
    /**
     * 油品数量
     */
    @Min(value = 0, message = "油品数量不能小于0")
    @NotNull(message = "油品数量不能为空")
    private BigDecimal lubNum;
    /**
     * 油品编码
     */
    private String lubCode;
    /**
     * 油品单位
     */
    private String lubUnit;
    /**
     * 油品供应商
     */
    private String lubSupplier;
}