package com.hvisions.eam.entity.maintain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * <p>Title: HvEamMaintainPlan</p >
 * <p>Description: 保养计划实体</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/3/19</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@Entity
@Table(uniqueConstraints = @UniqueConstraint(name = "uq_plan_sparePart", columnNames = {"maintainPlanId", "equipmentId", "sparePartId"}))
public class HvEamMaintainPlanSparePart {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    /**
     * 保养计划id
     */
    @NotNull(message = "计划id填充错误")
    private Integer maintainPlanId;
    /**
     * 备件id
     */
    @NotNull(message = "备件id不能为空")
    private Integer sparePartId;
    /**
     * 设备id
     */
    @NotNull(message = "备件的设备信息不能为空")
    private Integer equipmentId;
    /**
     * 备件名称
     */
    private String sparePartName;
    /**
     * 备件数量
     */
    private BigDecimal sparePartNum;
    /**
     * 备件编码
     */
    private String sparePartCode;
    /**
     * 备件单位
     */
    private String sparePartUnit;
    /**
     * 备件供应商
     */
    private String sparePartSupplier;

}