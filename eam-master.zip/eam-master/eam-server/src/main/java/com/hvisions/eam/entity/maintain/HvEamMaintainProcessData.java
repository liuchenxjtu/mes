package com.hvisions.eam.entity.maintain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

/**
 * <p>Title: HvEamMaintainProcessData</p>
 * <p>Description: 保养流程数据</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/10/14</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Entity
@Getter
@Setter
@ToString
public class HvEamMaintainProcessData {

    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;
    /**
     * 流程实例数据
     */
    private String processInstanceId;
    private String processDefinitionId;
    private String processDefinitionName;
    private String processDefinitionKey;
    private int processDefinitionVersion;
    private String deploymentId;
    private String businessKey;
    private String tenantId;
    private String name;
    private String description;
    private String localizedName;
    private String localizedDescription;
    private Date startTime;
    private Date endTime;
    private String startUserId;
    /**
     * 流程参数数据
     */
    private String equipmentCode;
    private String line;
    private String remark;
    private int equipmentId;
    private String equipmentName;
    private String lubApplyState;
    private String taskNum;
    private Integer lineId;
    private String hvisionsTaskState;
    private String sparePartApplyState;
    private String factory;
    private String manHour;
    private boolean shutDown;
    private String workShop;
    private int checkerId;
    private String checkerName;
    private String taskName;
    private int executor_id;
    private Date taskEndTime;
}









