package com.hvisions.eam.entity.maintain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * <p>Title: HvEamMaintainProcessData</p>
 * <p>Description: 保养流程数据</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/10/14</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Entity
@Getter
@Setter
@ToString
public class HvEamMaintainProcessDataSparepart {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;
    private Long itemId;
    private int maintainItemId;
    private int sparePartId;
    private String sparePartName;
    private int sparePartNum;
    private String sparePartCode;
    private String sparePartUnit;
    private String sparePartSupplier;
}









