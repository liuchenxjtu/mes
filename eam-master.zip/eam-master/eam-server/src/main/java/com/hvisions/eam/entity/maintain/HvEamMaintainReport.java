package com.hvisions.eam.entity.maintain;

import com.hvisions.eam.entity.SysBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import java.util.Date;

/**
 * <p>Title: HvEamMaintainReport</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/6/18</p >
 *
 * @author : bzy
 * @version :1.0.0
 */

@Getter
@Setter
@ToString
@Entity
public class HvEamMaintainReport extends SysBase {


    /**
     * 生产线
     */
    private String cellCode;

    /**
     * 工序号
     */
    private String operationCode;

    /**
     * 设备编码
     */
    private String equipmentCode;

    /**
     * 设备名称
     */
    private String equipmentName;

    /**
     * 日期
     */
    private Date orderTime;

    /**
     * 故障分类
     */
    private String faultType;

    /**
     * 故障描述
     */
    private String faultDesc;

    /**
     * 检修过程
     */
    private String maintainProcess;


    /**
     * 原因分析
     */
    private String causeAnalysis;


    /**
     * 预防措施
     */
    private String precaution;

    /**
     * 报修时间
     */
    private Date repairTime;

    /**
     * 开始检修时间
     */
    private Date startFaultTime;


    /**
     * 检修完工时间
     */
    private Date endFaultTime;


    /**
     * 累计检修时间
     */
    private Integer sumFaultTime;


    /**
     * 累计停线时间
     */
    private Integer lineStopTime;


    /**
     * 恢复生产时间
     */
    private Integer workTime;

    /**
     * 维修人员
     */
    private String userName;

}