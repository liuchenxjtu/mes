package com.hvisions.eam.entity.maintain;

import com.hvisions.eam.entity.SysBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import java.util.Date;

/**
 * <p>Title: HvEamRepairData</p>
 * <p>Description: 维修数据</p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2020/11/6</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Entity
@Getter
@Setter
@ToString
public class HvEamRepairData extends SysBase {

    private String processInstanceId;
    private String processDefinitionId;
    private String processDefinitionName;
    private String processDefinitionKey;
    private Integer processDefinitionVersion;
    private String deploymentId;
    private String businessKey;
    private String tenantId;
    private String name;
    private String description;
    private String localizedName;
    private String localizedDescription;
    private Date startTime;
    private Date endTime;
    private String startUserId;

    private String equipmentCode;
    private String warrantyPhone;
    private Integer equipmentId;
    private Integer applyUserId;
    private String failureLevel;
    private String faultClassApplyName;
    private String describeAssignee;
    private String faultAssigneeName;
    private String equipmentName;
    private String faultClassAssigneeName;
    private String state;
    private String receiptNumber;
    private String hvisionsTaskState;
    private String faultSolutionAssigneeName;
    private String describeApply;
    private Integer faultAssigneeId;
    private Integer faultReasonAssigneeId;
    private String equipmentPlace;
    private String applyUserName;
    private String faultReasonAssigneeName;
    private String faultApplyName;
    private Integer faultSolutionAssigneeId;
    private Integer faultApplyId;
    private Float faultDiagnosisTime;
    private Float waitSparePartTime;
    private Float repairReplaceTime;
    private Float startupTime;
    private Float shutdownTime;
    private Integer lineId;
    private String userIdJoin;
}









