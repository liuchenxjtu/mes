package com.hvisions.eam.entity.publicstore;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import java.math.BigDecimal;

/**
 * <p>Title:HvEamActualUse</p>
 * <p>Description:实际使用</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class HvEamActualUse extends SysBase {

    /**
     * 备件ID
     */
    Integer spareId;

    /**
     * 批次号
     */
    String batchNumber;

    /**
     * 库房号
     */
    Integer shelveId;

    /**
     * 数量
     */
    BigDecimal number;

    /**
     * 流程实例Id
     */
    String processInstanceId;

    /**
     * 使用清单Id
     */
    Integer useListingId;

    /**
     * 类型 1备件 2油品
     */
    Integer type;

    /**
     * 标识符
     */
    String identifierKey;

}
