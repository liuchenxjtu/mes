package com.hvisions.eam.entity.publicstore;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;

/**
 * <p>Title:HvEamMatching</p>
 * <p>Description:正则验证</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/21</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Entity
@Data
@Table(uniqueConstraints = {@UniqueConstraint(name = "正则验证服务名唯一", columnNames = "service")})
public class HvEamMatching {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 索引开始位置
     */
    private Integer start;

    /**
     * 索引结束位置
     */
    @Column(name = "endPlace")
    private Integer end;

    /**
     * 正则表达式
     */
    private String regEx;

    /**
     * 服务名
     */
    @Length(max = 200, message = "服务不能超过200")
    private String service;

    /**
     * 匹配方式 1.位置匹配  2.正则匹配
     */
    private Integer type;

}
