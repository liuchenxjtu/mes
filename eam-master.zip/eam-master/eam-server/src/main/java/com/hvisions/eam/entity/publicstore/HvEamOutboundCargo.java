package com.hvisions.eam.entity.publicstore;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * <p>Title:OutboundCargoRepository</p>
 * <p>Description:出库表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/7/15</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(uniqueConstraints = {@UniqueConstraint(name = "过程ID唯一", columnNames = "processInstanceId")})
public class HvEamOutboundCargo extends SysBase {

    /**
     * 类型 1 备件 2 油品
     */
    private Integer type;

    /**
     * 过程ID
     */
    @Length(max = 200,message = "过程id不能超过200")
    private String processInstanceId;

    /**
     * 是否出库
     */
    private Integer inOut;

}
