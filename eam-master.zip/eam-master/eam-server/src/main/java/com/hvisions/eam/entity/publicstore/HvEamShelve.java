package com.hvisions.eam.entity.publicstore;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * <p>Title:Shelve</p>
 * <p>Description:库房</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(uniqueConstraints = {@UniqueConstraint(name = "库房编码唯一", columnNames = "shelveCode"), @UniqueConstraint(name = "库房名称唯一", columnNames = "shelveName")})
public class HvEamShelve extends SysBase {

    /**
     * 库房编码 不可修改
     */
    @Column(updatable = false)
    @Length(max = 200,message = "库房编码不能超过200")
    private String shelveCode;

    /**
     * 库房名称
     */
    @Length(max = 200,message = "库房名称不能超过200")
    private String shelveName;

    /**
     * 库房地点
     */
    private String shelvePlace;

    /**
     * 库房人员ID
     */
    private Integer shelveUserId;

}