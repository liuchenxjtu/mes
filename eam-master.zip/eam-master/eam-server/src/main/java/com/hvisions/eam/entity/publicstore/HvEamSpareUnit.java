package com.hvisions.eam.entity.publicstore;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * <p>Title:SpareUnit</p>
 * <p>Description:备件单位</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(uniqueConstraints = {@UniqueConstraint(name = "备件单位名称唯一", columnNames = "unitName"), @UniqueConstraint(name = "备件单位符号唯一", columnNames = "unitSymbol")})
public class HvEamSpareUnit extends SysBase {

    /**
     * 单位名称
     */
    @Length(max = 200,message = "单位名称不能超过200")
    private String unitName;

    /**
     * 单位符号
     */
    private String unitSymbol;
}