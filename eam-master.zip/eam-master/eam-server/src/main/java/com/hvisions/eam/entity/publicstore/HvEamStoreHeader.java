package com.hvisions.eam.entity.publicstore;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;

/**
 * <p>Title:HvEamStoreHeader</p>
 * <p>Description: 备件油品出入库 头表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/7/31</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class HvEamStoreHeader extends SysBase {

    public HvEamStoreHeader() {
        this.complete = false;
    }

    public HvEamStoreHeader(String receiptNumber,
                            String title,
                            String processInstanceId,
                            Integer inOut,
                            Integer typeClass,
                            String source) {
        this.complete = false;
        this.receiptNumber = receiptNumber;
        this.title = title;
        this.processInstanceId = processInstanceId;
        this.inOut = inOut;
        this.typeClass = typeClass;
        this.source = source;
    }

    /**
     * 单号
     */
    private String receiptNumber;

    /**
     * 标题
     */
    private String title;

    /**
     * 流程id
     */
    private String processInstanceId;

    /**
     * 出库入库
     */
    private Integer inOut;

    /**
     * 来源
     */
    private String source;

    /**
     * 区别备件油品 备件1 油品2
     */
    private Integer typeClass;

    /**
     * 是否完成出入库操作
     */
    private Boolean complete;

    /**
     * 是否驳回：1：驳回，null 不驳回
     */
    private Integer reject;

    /**
     * 驳回原因
     */
    private String rejectReason;

}
