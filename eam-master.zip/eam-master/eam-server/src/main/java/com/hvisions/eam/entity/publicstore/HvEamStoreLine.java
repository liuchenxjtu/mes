package com.hvisions.eam.entity.publicstore;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * <p>Title:HvEamStoreLine</p>
 * <p>Description:备件油品出入库 行表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/7/31</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class HvEamStoreLine extends SysBase {

    public HvEamStoreLine() {
        //是否完成默认 false
        this.complete = false;
    }

    public HvEamStoreLine(Integer headerId) {
        this.headerId = headerId;
        //是否完成默认 false
        this.complete = false;
    }

    /**
     * 头表id
     */
    @NotNull(message = "头表id不能为空")
    private Integer headerId;

    /**
     * 备件id
     */
    @NotNull(message = "实体id不能为空")
    private Integer spareId;

    /**
     * 库房id
     */
    private Integer shelveId;

    /**
     * 数量
     */
    @NotNull(message = "数量不能为空")
    private BigDecimal number;

    /**
     * 批次号
     */
    private String batchNumber;

    /**
     * 完成
     */
    private Boolean complete;


}
