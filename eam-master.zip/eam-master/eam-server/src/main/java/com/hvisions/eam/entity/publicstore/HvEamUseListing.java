package com.hvisions.eam.entity.publicstore;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import java.math.BigDecimal;

/**
 * <p>Title:HvEamUseListing</p>
 * <p>Description:备件使用清单</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/5/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class HvEamUseListing extends SysBase {

    /**
     * 备件ID
     */
    Integer spareId;

    /**
     * 使用实际数量
     */
    BigDecimal number;

    /**
     * 关联 流程实例ID
     */
    String processInstanceId;

    /**
     * 类型
     */
    Integer type;

}
