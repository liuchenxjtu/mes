package com.hvisions.eam.entity.spare;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import java.math.BigDecimal;

/**
 * <p>Title:spare</p>
 * <p>Description:备件</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/19</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(uniqueConstraints = {@UniqueConstraint(name = "备件编码唯一", columnNames = "spareCode")})
public class HvEamSpare extends SysBase {

    /**
     * 备件编码 不可修改
     */
    @Length(max = 200, message = "备件编码不能超过200")
    @Column(updatable = false)
    private String spareCode;

    /**
     * 备件名称
     */
    @Length(max = 200, message = "备件名称不能超过200")
    private String spareName;

    /**
     * 备件型号ID
     */
    private Integer spareTypeId;

    /**
     * 单位id
     */
    private Integer unitId;

    /**
     * 单价
     */
    @Digits(integer = 8, fraction = 2, message = "单价小数位数为最大2,整数位最大为8")
    private BigDecimal unitPrice;

    /**
     * 最大库存
     */
    @Min(value = 0, message = "最大库存不能小于0")
    private Integer cargoMax;

    /**
     * 最小库存
     */
    @Min(value = 0, message = "最小库存不能小于0")
    private Integer cargoMin;

    /**
     * 备注
     */
    private String remarks;

    /**
     * 供应商
     */
    private String supplier;

    /**
     * 采购工程师
     */
    private Integer purchaseUserId;

    /**
     * 技术工程师
     */
    private Integer skillUserId;

    /**
     * 订单号
     */
    private String orderNum;

    /**
     * 图片
     */
    private Integer img;

    //-----------------------------------------------= 刀具 =----------------------------------


    /**
     * 额定次数
     */
    private Integer expectedNumber;


    /**
     * 报警临界剩余数量
     */
    private Integer alarmRemainingNumber;

    /**
     * 品牌
     */
    private String brand;


    /**
     * 机电类别
     */
    private String metype;

    /**
     * 规格
     */
    private String specifications;

    /**
     * 计划单价
     */
    private BigDecimal planPrice;

}