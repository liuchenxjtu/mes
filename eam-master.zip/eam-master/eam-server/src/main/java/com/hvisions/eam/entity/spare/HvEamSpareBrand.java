package com.hvisions.eam.entity.spare;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;

/**
 * <p>Title: HvEamSpareBrand</p >
 * <p>Description: 备件品牌</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/5/11</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@Table(uniqueConstraints = {@UniqueConstraint(name = "备件品牌编码唯一", columnNames = "spareBrandCode"),
    @UniqueConstraint(name = "备件品牌名称唯一", columnNames = "spareBrandName")
})
public class HvEamSpareBrand extends SysBase {


    /**
     * 备件品牌编码
     */
    @NotBlank(message = "备件品牌编码不能为空")
    private String spareBrandCode;

    /**
     * 备件品牌名称
     */
    @NotBlank(message = "备件品牌名称不能为空")
    private String spareBrandName;
}