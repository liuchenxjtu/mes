package com.hvisions.eam.entity.spare;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * <p>Title:HvEamSpareFile</p>
 * <p>Description:备件文件表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/7/17</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table
public class HvEamSpareFile extends SysBase {

    private Integer spareId;

    private Integer fileId;


}
