package com.hvisions.eam.entity.spare;

import com.hvisions.eam.entity.SysBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * <p>Title:SpareToShelve</p>
 * <p>Description:备件关系表</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/3/20</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table
public class HvEamSpareToShelve extends SysBase {

    public HvEamSpareToShelve() {

    }

    public HvEamSpareToShelve(Integer spareId, Integer shelveId, String batchNumber) {
        this.spareId = spareId;
        this.shelveId = shelveId;
        this.batchNumber = batchNumber;
    }


    /**
     * 库位ID
     */
    private Integer shelveId;

    /**
     * 备件ID
     */
    private Integer spareId;

    /**
     * 备件库存数量
     */
    private Integer number;

    /**
     * 架号
     */
    private String rackNumber;

    /**
     * 批次号
     */
    private String batchNumber;

    /**
     * 备件序号
     */
    private Integer spareNo;


    /**
     * 图片id
     */
    private Integer img;
}