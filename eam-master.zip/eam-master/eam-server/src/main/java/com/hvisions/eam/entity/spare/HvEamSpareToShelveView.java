package com.hvisions.eam.entity.spare;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * <p>Title:HvEamSpareToShelveView</p>
 * <p>Description:备件 库房 关系视图</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/4/1</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
@Data
@Entity
public class HvEamSpareToShelveView {

    @Id
    private Integer id;
    //--------------------- 备件 ---------------------
    /**
     * 备件ID
     */
    private Integer spareId;
    /**
     * 备件编码
     */
    private String spareCode;
    /**
     * 备件名称
     */
    private String spareName;

    //---------------------- 关系 ----------------------
    /**
     * 库存数量
     */
    private Integer number;

    /**
     * 批次号
     */
    private String batchNumber;

    //---------------------- 库房 ----------------------

    /**
     * 库房ID
     */
    private Integer shelveId;

    /**
     * 库位编码
     */
    private String shelveCode;

    /**
     * 库位名称
     */
    private String shelveName;


    //----------------------------= 备件类型 =-----------------------------

    /**
     * 备件类型编码
     */
    private String typeCode;

    /**
     * 备件类型名称
     */
    private String typeName;

}