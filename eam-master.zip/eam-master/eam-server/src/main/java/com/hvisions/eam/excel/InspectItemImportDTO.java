package com.hvisions.eam.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 * <p>Title: InspectItemImportDTO</p >
 * <p>Description: 点巡检项目导入DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2020/12/2</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@Data
public class InspectItemImportDTO {

    /**
     * 点检项目编号
     */
    @ExcelProperty(value = "点巡检项目编号,重复的时候跳过")
    private String inspectItemCode;
    /**
     * 点巡检项目名称
     */
    @ExcelProperty(value = "点巡检项目名称,必填")
    private String inspectItemName;

    /**
     * 点巡检内容
     */
    @ExcelProperty(value = "点巡检内容,必填")
    private String inspectWork;
    /**
     * 是否需要停机
     */
    @ExcelProperty(value = "是否需要停机,必填")
    private Boolean shutDown;
    /**
     * 是否启用
     */
    @ExcelProperty(value = "是否启用,必填")
    private Boolean startUsing;


    /**
     * 零部件
     */
    @ExcelProperty(value = "零部件")
    private String parts;


    /**
     * 操作周期
     */
    @ExcelProperty(value = "操作周期")
    private String cycle;
    /**
     * 所需工时
     */
    @ExcelProperty(value = "所需工时")
    private Float manHour;
    /**
     * 关联的设备编码列表
     */
    @ExcelProperty(value = "关联的设备编码列表，注意使用英文的逗号进行分割")
    private String equipments;
    /**
     * 关联的设备类型编码列表
     */
    @ExcelProperty(value = "关联的设备类型编码列表，注意使用英文的逗号进行分割")
    private String equipmentTypes;
}