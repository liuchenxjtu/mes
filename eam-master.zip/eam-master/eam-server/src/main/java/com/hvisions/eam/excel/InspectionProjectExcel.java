package com.hvisions.eam.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author: xiehao
 * @version: 1.0
 */
@Getter
@Setter
@ToString
public class InspectionProjectExcel {

    /**
     * 检查项目编号
     */
    @ExcelProperty(value = "检查项目编号")
    private String number;

    /**
     * 检查项目名称
     */
    @ExcelProperty(value = "检查项目名称")
    private String name;

    /**
     * 检测内容
     */
    @ExcelProperty(value = "检测内容")
    private String testContent;

    /**
     * 检测周期
     */
    @ExcelProperty(value = "检测周期")
    private String testCycle;

    /**
     * 检测方法
     */
    @ExcelProperty(value = "检测方法")
    private String testMethod;

    /**
     * 启用标志;0-启用,1-未启用
     */
    @ExcelProperty(value = "启用标志;0-启用,1-未启用")
    private String enableFlag;

    /**
     * 连续异常次数
     */
    @ExcelProperty(value = "连续异常次数")
    private Integer abnormalTimes;

    /**
     * 分组名称
     */
    @ExcelProperty(value = "分组名称")
    private String groupName;

}
