package com.hvisions.eam.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 * <p>Title: MaintainItemImportDTO</p >
 * <p>Description: 保养项目导入DTO</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2020/12/2</p >
 *
 * @author :rujiacheng
 * @version :1.0.0
 */
@Data
public class MaintainItemImportDTO {
    /**
     * 保养项目编号
     */
    @ExcelProperty(value = "保养项目编号,重复时候更新")
    private String maintainItemCode;
    /**
     * 保养项目名称
     */
    @ExcelProperty(value = "保养项目名称,必填")
    private String maintainItemName;

    /**
     * 保养内容
     */
    @ExcelProperty(value = "保养内容,必填")
    private String maintainWork;
    /**
     * 是否需要停机
     */
    @ExcelProperty(value = "是否需要停机,必填")
    private Boolean shutDown;
    /**
     * 是否启用
     */
    @ExcelProperty(value = "是否启用,必填")
    private Boolean startUsing;

    /**
     * 零部件
     */
    @ExcelProperty(value = "零部件")
    private String parts;


    /**
     * 操作周期
     */
    @ExcelProperty(value = "操作周期")
    private String cycle;
    /**
     * 所需工时
     */
    @ExcelProperty(value = "所需工时")
    private Float manHour;
    /**
     * 关联的备件编码列表
     */
    @ExcelProperty(value = "关联的备件编码列表，注意使用英文的逗号进行分割,格式为:{spareCode:num},例如：spare001:3")
    private String spares;
    /**
     * 关联的油品编码列表
     */
    @ExcelProperty(value = "关联的油品编码列表，注意使用英文的逗号进行分割,格式为:{lubCode:num},例如：lub001:3")
    private String lubs;
    /**
     * 关联的设备编码列表
     */
    @ExcelProperty(value = "关联的设备编码列表，注意使用英文的逗号进行分割")
    private String equipments;
    /**
     * 关联的设备类型编码列表
     */
    @ExcelProperty(value = "关联的设备类型编码列表，注意使用英文的逗号进行分割")
    private String equipmentTypes;


}