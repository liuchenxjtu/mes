package com.hvisions.eam.repository.fault;

import com.hvisions.eam.entity.HvEamSerialNumber;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <p>Title:SerialNumberRepository</p>
 * <p>Description:</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/7/5</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
public interface SerialNumberRepository extends JpaRepository<HvEamSerialNumber, Integer> {

    /**
     * 通过服务名获取 单号
     * @param service 服务名
     * @return 服务
     */
    HvEamSerialNumber findByService(String service);
}
