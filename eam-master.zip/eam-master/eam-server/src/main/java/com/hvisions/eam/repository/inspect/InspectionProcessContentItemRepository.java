package com.hvisions.eam.repository.inspect;

import com.hvisions.eam.entity.inspect.HvEamInspectProcessContentItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * <p>Title: InspectDataRepository</p>
 * <p>Description: </p>
 * <p>Company: www.h-visions.com</p>
 * <p>create date: 2021/1/12</p>
 *
 * @author :leiming
 * @version :1.0.0
 */
@Repository
public interface InspectionProcessContentItemRepository extends JpaRepository<HvEamInspectProcessContentItem, Integer> {
}

    
    
    
    