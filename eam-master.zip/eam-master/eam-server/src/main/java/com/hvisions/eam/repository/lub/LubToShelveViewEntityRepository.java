package com.hvisions.eam.repository.lub;

import com.hvisions.eam.entity.lub.HvEamLubToShelveView;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <p>Title:SpareToShelveViewEntityRepository</p>
 * <p>Description:联表查询</p>
 * <p>Company:www.h-visions.com</p>
 * <p>create date:2019/4/1</p>
 *
 * @author :yu
 * @version : 1.0.0
 */
public interface LubToShelveViewEntityRepository extends JpaRepository<HvEamLubToShelveView, Integer> {

}
