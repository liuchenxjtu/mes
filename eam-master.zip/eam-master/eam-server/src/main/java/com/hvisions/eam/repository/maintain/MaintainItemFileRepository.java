package com.hvisions.eam.repository.maintain;

import com.hvisions.eam.entity.maintain.HvEamMaintainItemFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>Title: MaintainItemFileRepository</p >
 * <p>Description: 保养项目与文件关系Repository</p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2019/4/19</p >
 *
 * @author :fanjipeng
 * @version :1.0.0
 */
@Repository
public interface MaintainItemFileRepository extends JpaRepository<HvEamMaintainItemFile, Integer> {
    /**
     * 根据保养项目id删除与文件的关系
     *
     * @param maintainItemId 保养项目id
     */
    void deleteAllByMaintainItemId(Integer maintainItemId);

    /**
     * 根据项目id查询
     *
     * @param maintainItemId 保养项目id集合
     * @return 项目—文件实体集合
     */
    List<HvEamMaintainItemFile> findAllByMaintainItemId(Integer maintainItemId);
    /**
     * 根据项目id查询
     *
     * @param maintainItemIdList 保养项目id集合
     * @return 项目—文件实体集合
     */
    List<HvEamMaintainItemFile> findAllByMaintainItemIdIn(List<Integer> maintainItemIdList);
}
