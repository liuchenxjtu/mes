package com.hvisions.eam.repository.maintain;

import com.hvisions.eam.entity.maintain.HvEamMaintainReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * <p>Title: MaintainReportRepository</p >
 * <p>Description: </p >
 * <p>Company: www.h-visions.com</p >
 * <p>create date: 2021/7/31</p >
 *
 * @author : bzy
 * @version :1.0.0
 */
@Repository
public interface MaintainReportRepository extends JpaRepository<HvEamMaintainReport, Integer> {

}